import view.LoginView;
import javax.swing.*;

/**
 * Main — Entry point Sistem Inventaris.
 *
 * Cara menjalankan di VS Code:
 *   1. Pastikan mysql-connector-j-*.jar ada di folder lib/
 *   2. Sesuaikan konfigurasi DB di util/DatabaseUtil.java
 *   3. Jalankan: java -cp "lib/*:src" Main   (Linux/Mac)
 *                java -cp "lib/*;src" Main   (Windows)
 *
 *   Atau gunakan task di .vscode/tasks.json
 */
public class Main {

    public static void main(String[] args) {
        // Gunakan Look & Feel sistem agar tampilan lebih native
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {
            // Fallback ke L&F default jika gagal
        }

        // Semua operasi Swing harus berjalan di Event Dispatch Thread (EDT)
        SwingUtilities.invokeLater(LoginView::new);
    }
}
