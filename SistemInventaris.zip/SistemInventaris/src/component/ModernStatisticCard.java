package component;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.*;

/**
 * ModernStatisticCard — Card komponen untuk menampilkan statistik dashboard.
 * Features:
 *   - Soft shadow depth effect
 *   - Rounded corners
 *   - Gradient background (optional)
 *   - Hover effect
 *   - Icon + Title + Value + Subtitle layout
 */
public class ModernStatisticCard extends JPanel {
    
    private String title;
    private String value;
    private String subtitle;
    private String icon; // emoji atau unicode
    private Color backgroundColor;
    private Color accentColor;
    private boolean isHovered;
    
    private static final int RADIUS = 16;
    private static final int SHADOW_SIZE = 10;
    private static final Color SHADOW_COLOR = new Color(0, 0, 0, 15);
    
    public ModernStatisticCard(String icon, String title, String value, String subtitle, Color accentColor) {
        this.icon = icon;
        this.title = title;
        this.value = value;
        this.subtitle = subtitle;
        this.accentColor = accentColor;
        this.backgroundColor = Color.WHITE;
        this.isHovered = false;
        
        setOpaque(false);
        setLayout(null);
        setPreferredSize(new Dimension(280, 140));
        
        // Mouse listener untuk hover effect
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                isHovered = true;
                repaint();
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                isHovered = false;
                repaint();
            }
        });
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        int width = getWidth();
        int height = getHeight();
        
        // Draw shadow
        drawShadow(g2d, width, height);
        
        // Draw card background
        drawCardBackground(g2d, width, height);
        
        // Draw accent bar di kiri
        drawAccentBar(g2d, height);
        
        // Draw content
        drawContent(g2d, width, height);
    }
    
    private void drawShadow(Graphics2D g2d, int width, int height) {
        // Soft shadow effect
        g2d.setColor(SHADOW_COLOR);
        g2d.fillRoundRect(8, 8, width - 16, height - 16, RADIUS, RADIUS);
    }
    
    private void drawCardBackground(Graphics2D g2d, int width, int height) {
        // Card background
        if (isHovered) {
            g2d.setColor(new Color(255, 255, 255));
        } else {
            g2d.setColor(backgroundColor);
        }
        g2d.fillRoundRect(4, 4, width - 8, height - 8, RADIUS, RADIUS);
        
        // Border
        g2d.setStroke(new BasicStroke(1.5f));
        g2d.setColor(new Color(230, 235, 245));
        g2d.drawRoundRect(4, 4, width - 8, height - 8, RADIUS, RADIUS);
    }
    
    private void drawAccentBar(Graphics2D g2d, int height) {
        // Accent bar di sebelah kiri
        g2d.setColor(accentColor);
        g2d.fillRect(0, 4, 5, height - 8);
    }
    
    private void drawContent(Graphics2D g2d, int width, int height) {
        int padding = 20;
        int iconSize = 40;
        
        // Icon
        g2d.setColor(accentColor);
        g2d.setFont(new Font("SansSerif", Font.PLAIN, 32));
        FontMetrics fm = g2d.getFontMetrics();
        int iconX = padding + iconSize / 2 - fm.stringWidth(icon) / 2;
        int iconY = padding + 20;
        g2d.drawString(icon, iconX, iconY);
        
        // Title
        g2d.setColor(new Color(120, 130, 155));
        g2d.setFont(new Font("SansSerif", Font.PLAIN, 12));
        g2d.drawString(title, padding, padding + 60);
        
        // Value
        g2d.setColor(new Color(28, 32, 50));
        g2d.setFont(new Font("SansSerif", Font.BOLD, 26));
        g2d.drawString(value, padding, padding + 90);
        
        // Subtitle
        g2d.setColor(new Color(180, 190, 210));
        g2d.setFont(new Font("SansSerif", Font.PLAIN, 11));
        g2d.drawString(subtitle, padding, height - 10);
    }
    
    // Getters & Setters
    public void setValue(String value) {
        this.value = value;
        repaint();
    }
    
    public void setTitle(String title) {
        this.title = title;
        repaint();
    }
    
    public void setSubtitle(String subtitle) {
        this.subtitle = subtitle;
        repaint();
    }
    
    public String getValue() {
        return value;
    }
    
    public String getTitle() {
        return title;
    }
}
