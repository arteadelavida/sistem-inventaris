package component;

import java.awt.*;
import javax.swing.*;

/**
 * PremiumHeader — Header profesional untuk dashboard dengan gradient dan branding.
 * Cocok untuk aplikasi enterprise seperti Apple, Google, Petrosea.
 */
public class PremiumHeader extends JPanel {
    
    private String title;
    private String subtitle;
    private Color colorStart;
    private Color colorEnd;
    
    public PremiumHeader(String title, String subtitle, Color colorStart, Color colorEnd) {
        this.title = title;
        this.subtitle = subtitle;
        this.colorStart = colorStart;
        this.colorEnd = colorEnd;
        
        setOpaque(false);
        setPreferredSize(new Dimension(0, 120));
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBorder(BorderFactory.createEmptyBorder(25, 30, 25, 30));
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        Graphics2D g2d = (Graphics2D) g.create();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        
        // Gradient background
        g2d.setPaint(new GradientPaint(0, 0, colorStart, getWidth(), getHeight(), colorEnd));
        g2d.fillRect(0, 0, getWidth(), getHeight());
        
        // Subtle pattern
        g2d.setColor(new Color(255, 255, 255, 5));
        for (int i = 0; i < getWidth(); i += 20) {
            g2d.drawLine(i, 0, i, getHeight());
        }
        
        g2d.dispose();
    }
    
    public void buildUI() {
        removeAll();
        
        JLabel lblTitle = new JLabel(title);
        lblTitle.setFont(new Font("SansSerif", Font.BOLD, 26));
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setAlignmentX(LEFT_ALIGNMENT);
        
        JLabel lblSubtitle = new JLabel(subtitle);
        lblSubtitle.setFont(new Font("SansSerif", Font.PLAIN, 12));
        lblSubtitle.setForeground(new Color(200, 230, 255));
        lblSubtitle.setAlignmentX(LEFT_ALIGNMENT);
        
        add(lblTitle);
        add(Box.createVerticalStrut(5));
        add(lblSubtitle);
        add(Box.createVerticalGlue());
        
        revalidate();
        repaint();
    }
}
