package component;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * LoadingPanel — Panel dengan loading spinner untuk long-running operations.
 * Features:
 *   - Animated spinner
 *   - Loading message
 *   - Optional progress bar
 */
public class LoadingPanel extends JPanel {
    
    private String message;
    private int progress;
    private boolean showProgress;
    private Timer animationTimer;
    private float rotationAngle;
    
    private static final Color SPINNER_COLOR = new Color(0, 105, 140);
    private static final Color TEXT_COLOR = new Color(120, 130, 155);
    
    public LoadingPanel(String message) {
        this(message, false);
    }
    
    public LoadingPanel(String message, boolean showProgress) {
        this.message = message;
        this.showProgress = showProgress;
        this.progress = 0;
        this.rotationAngle = 0;
        
        setOpaque(false);
        setLayout(null);
        setPreferredSize(new Dimension(300, 200));
        
        // Setup animation timer
        animationTimer = new Timer(30, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                rotationAngle = (rotationAngle + 6) % 360;
                repaint();
            }
        });
        animationTimer.start();
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        int width = getWidth();
        int height = getHeight();
        
        // Center X, Y
        int centerX = width / 2;
        int centerY = (height / 2) - 20;
        
        // Draw spinner
        drawSpinner(g2d, centerX, centerY);
        
        // Draw message
        drawMessage(g2d, width, height);
        
        // Draw progress bar if enabled
        if (showProgress) {
            drawProgressBar(g2d, width, height);
        }
    }
    
    private void drawSpinner(Graphics2D g2d, int centerX, int centerY) {
        int spinnerSize = 40;
        
        // Save original transform
        java.awt.geom.AffineTransform originalTransform = g2d.getTransform();
        
        // Rotate around center
        g2d.translate(centerX, centerY);
        g2d.rotate(Math.toRadians(rotationAngle));
        
        // Draw spinner arc
        g2d.setColor(SPINNER_COLOR);
        g2d.setStroke(new BasicStroke(4, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g2d.drawArc(-spinnerSize/2, -spinnerSize/2, spinnerSize, spinnerSize, 0, 270);
        
        // Restore transform
        g2d.setTransform(originalTransform);
    }
    
    private void drawMessage(Graphics2D g2d, int width, int height) {
        g2d.setColor(TEXT_COLOR);
        g2d.setFont(new Font("SansSerif", Font.PLAIN, 14));
        FontMetrics fm = g2d.getFontMetrics();
        
        int messageX = (width - fm.stringWidth(message)) / 2;
        int messageY = (height / 2) + 40;
        
        g2d.drawString(message, messageX, messageY);
    }
    
    private void drawProgressBar(Graphics2D g2d, int width, int height) {
        int barWidth = 200;
        int barHeight = 4;
        int barX = (width - barWidth) / 2;
        int barY = (height / 2) + 70;
        
        // Background
        g2d.setColor(new Color(230, 235, 245));
        g2d.fillRoundRect(barX, barY, barWidth, barHeight, 2, 2);
        
        // Progress
        g2d.setColor(SPINNER_COLOR);
        int progressWidth = (barWidth * progress) / 100;
        g2d.fillRoundRect(barX, barY, progressWidth, barHeight, 2, 2);
    }
    
    public void setMessage(String message) {
        this.message = message;
        repaint();
    }
    
    public void setProgress(int progress) {
        this.progress = Math.max(0, Math.min(100, progress));
        repaint();
    }
    
    public void stop() {
        if (animationTimer != null) {
            animationTimer.stop();
        }
    }
    
    @Override
    public void removeNotify() {
        if (animationTimer != null) {
            animationTimer.stop();
        }
        super.removeNotify();
    }
}
