package component;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;

/**
 * ModernTableStyle — Utility untuk styling table dengan design premium.
 */
public class ModernTableStyle {
    
    // Colors
    private static final Color HEADER_BG = new Color(0, 105, 140);
    private static final Color HEADER_FG = Color.WHITE;
    private static final Color ROW_ODD = new Color(248, 250, 253);
    private static final Color ROW_EVEN = Color.WHITE;
    private static final Color ROW_HOVER = new Color(230, 240, 250);
    private static final Color GRID_LINE = new Color(220, 225, 235);
    private static final Color TEXT_MAIN = new Color(28, 32, 50);
    private static final Color TEXT_SUB = new Color(120, 130, 155);
    
    public static void applyModernStyle(JTable table) {
        // Header styling
        JTableHeader header = table.getTableHeader();
        header.setBackground(HEADER_BG);
        header.setForeground(HEADER_FG);
        header.setFont(new Font("SansSerif", Font.BOLD, 11));
        header.setPreferredSize(new Dimension(0, 32));
        
        // Custom header renderer
        DefaultTableCellRenderer headerRenderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                    boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                c.setBackground(HEADER_BG);
                c.setForeground(HEADER_FG);
                setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));
                return c;
            }
        };
        
        for (int i = 0; i < table.getColumnModel().getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setHeaderRenderer(headerRenderer);
        }
        
        // Row styling
        DefaultTableCellRenderer rowRenderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                    boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                
                if (isSelected) {
                    c.setBackground(new Color(0, 168, 190, 50));
                    c.setForeground(TEXT_MAIN);
                } else {
                    c.setBackground(row % 2 == 0 ? ROW_EVEN : ROW_ODD);
                    c.setForeground(TEXT_MAIN);
                }
                
                setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));
                setFont(new Font("SansSerif", Font.PLAIN, 11));
                
                return c;
            }
        };
        
        for (int i = 0; i < table.getColumnModel().getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setCellRenderer(rowRenderer);
        }
        
        // Table properties
        table.setRowHeight(32);
        table.setGridColor(GRID_LINE);
        table.setShowGrid(true);
        table.setShowHorizontalLines(true);
        table.setShowVerticalLines(true);
        table.setIntercellSpacing(new Dimension(0, 0));
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setFont(new Font("SansSerif", Font.PLAIN, 11));
        table.setForeground(TEXT_MAIN);
        table.setBackground(ROW_EVEN);
    }
    
    public static void styleScrollPane(JScrollPane scrollPane) {
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(220, 225, 235), 1));
        scrollPane.getViewport().setBackground(Color.WHITE);
    }
}
