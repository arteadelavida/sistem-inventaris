package component;

import javax.swing.JPanel;
import java.awt.*;

/** Panel putih semi-transparan dengan sudut membulat. */
public class RoundedPanel extends JPanel {

    public RoundedPanel() {
        setOpaque(false);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setColor(new Color(255, 255, 255, 150));
        g2d.fillRoundRect(0, 0, getWidth(), getHeight(), 30, 30);
    }
}
