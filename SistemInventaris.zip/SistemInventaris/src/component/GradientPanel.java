package component;

import java.awt.*;
import java.awt.geom.RoundRectangle2D;
import javax.swing.*;

/**
 * GradientPanel — Komponen dengan gradient mewah layaknya aplikasi enterprise.
 * Mendukung multiple gradient direction dan rounded corners.
 */
public class GradientPanel extends JPanel {
    
    private Color colorStart;
    private Color colorEnd;
    private int direction; // 0: vertical, 1: horizontal, 2: diagonal
    private int cornerRadius;
    
    public static final int VERTICAL = 0;
    public static final int HORIZONTAL = 1;
    public static final int DIAGONAL = 2;
    
    public GradientPanel() {
        this(new Color(0, 105, 140), new Color(0, 188, 212), VERTICAL, 0);
    }
    
    public GradientPanel(Color start, Color end) {
        this(start, end, VERTICAL, 0);
    }
    
    public GradientPanel(Color start, Color end, int direction, int cornerRadius) {
        this.colorStart = start;
        this.colorEnd = end;
        this.direction = direction;
        this.cornerRadius = cornerRadius;
        setOpaque(false);
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        Graphics2D g2d = (Graphics2D) g.create();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        
        int width = getWidth();
        int height = getHeight();
        
        // Buat gradient sesuai direction
        Paint gradient = null;
        
        switch (direction) {
            case HORIZONTAL:
                gradient = new GradientPaint(0, 0, colorStart, width, 0, colorEnd);
                break;
            case DIAGONAL:
                gradient = new GradientPaint(0, 0, colorStart, width, height, colorEnd);
                break;
            default: // VERTICAL
                gradient = new GradientPaint(0, 0, colorStart, 0, height, colorEnd);
        }
        
        g2d.setPaint(gradient);
        
        // Draw dengan rounded corners jika diperlukan
        if (cornerRadius > 0) {
            RoundRectangle2D.Float rounded = new RoundRectangle2D.Float(
                0, 0, width - 1, height - 1, cornerRadius, cornerRadius);
            g2d.fill(rounded);
            g2d.setColor(new Color(0, 0, 0, 30));
            g2d.setStroke(new BasicStroke(1.5f));
            g2d.draw(rounded);
        } else {
            g2d.fillRect(0, 0, width, height);
        }
        
        g2d.dispose();
    }
    
    public void setGradient(Color start, Color end, int direction) {
        this.colorStart = start;
        this.colorEnd = end;
        this.direction = direction;
        repaint();
    }
    
    public void setCornerRadius(int radius) {
        this.cornerRadius = radius;
        repaint();
    }
}
