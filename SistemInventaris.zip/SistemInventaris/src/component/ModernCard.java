package component;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

/**
 * ModernCard — Professional card component dengan shadow, gradient, dan hover effect.
 * Cocok untuk dashboard perusahaan besar seperti Apple, Google, Petrosea.
 */
public class ModernCard extends JPanel {
    
    private Color bgColor;
    private Color gradientStart, gradientEnd;
    private boolean hasGradient;
    private int cornerRadius = 12;
    private float shadowOpacity = 0.15f;
    private boolean isHovered = false;
    
    public ModernCard() {
        this(Color.WHITE);
    }
    
    public ModernCard(Color bgColor) {
        this.bgColor = bgColor;
        this.hasGradient = false;
        setOpaque(false);
        setLayout(new BorderLayout());
        setBorder(new EmptyBorder(16, 16, 16, 16));
        setupHoverEffect();
    }
    
    public ModernCard(Color gradStart, Color gradEnd) {
        this.gradientStart = gradStart;
        this.gradientEnd = gradEnd;
        this.hasGradient = true;
        setOpaque(false);
        setLayout(new BorderLayout());
        setBorder(new EmptyBorder(16, 16, 16, 16));
        setupHoverEffect();
    }
    
    private void setupHoverEffect() {
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                isHovered = true;
                repaint();
            }

            @Override
            public void mouseExited(MouseEvent e) {
                isHovered = false;
                repaint();
            }
        });
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        Graphics2D g2d = (Graphics2D) g.create();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        
        int width = getWidth();
        int height = getHeight();
        int shadowOffset = isHovered ? 8 : 4;
        
        // Shadow effect
        for (int i = shadowOffset; i > 0; i--) {
            float opacity = shadowOpacity * (1 - (float)i / shadowOffset) * 0.6f;
            g2d.setColor(new Color(0, 0, 0, (int)(255 * opacity)));
            g2d.fillRoundRect(i, i, width - 2*i, height - 2*i, cornerRadius, cornerRadius);
        }
        
        // Background
        if (hasGradient) {
            g2d.setPaint(new GradientPaint(0, 0, gradientStart, 0, height, gradientEnd));
        } else {
            g2d.setColor(bgColor);
        }
        g2d.fillRoundRect(0, 0, width, height, cornerRadius, cornerRadius);
        
        // Border
        g2d.setColor(new Color(0, 0, 0, 8));
        g2d.setStroke(new BasicStroke(1f));
        g2d.drawRoundRect(0, 0, width - 1, height - 1, cornerRadius, cornerRadius);
        
        g2d.dispose();
    }
    
    public void setCornerRadius(int radius) {
        this.cornerRadius = radius;
        repaint();
    }
    
    public void setShadowOpacity(float opacity) {
        this.shadowOpacity = opacity;
        repaint();
    }
}
