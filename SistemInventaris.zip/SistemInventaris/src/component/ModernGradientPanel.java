package component;

import java.awt.*;
import javax.swing.*;

/**
 * ModernGradientPanel — Panel dengan gradient multi-color yang lebih sophisticated.
 * Cocok untuk background dashboard atau header dengan visual yang lebih mewah.
 */
public class ModernGradientPanel extends JPanel {
    
    private Color[] colors;
    private int[] positions; // 0-100, posisi stop gradient
    
    public ModernGradientPanel(Color[] colors, int[] positions) {
        this.colors = colors;
        this.positions = positions;
        setOpaque(false);
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        Graphics2D g2d = (Graphics2D) g.create();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        
        int width = getWidth();
        int height = getHeight();
        
        // Paint gradient segments
        for (int i = 0; i < colors.length - 1; i++) {
            int y1 = (height * positions[i]) / 100;
            int y2 = (height * positions[i + 1]) / 100;
            
            GradientPaint gradient = new GradientPaint(
                0, y1, colors[i],
                0, y2, colors[i + 1]
            );
            
            g2d.setPaint(gradient);
            g2d.fillRect(0, y1, width, y2 - y1);
        }
        
        g2d.dispose();
    }
    
    public void setGradientColors(Color[] colors, int[] positions) {
        this.colors = colors;
        this.positions = positions;
        repaint();
    }
}
