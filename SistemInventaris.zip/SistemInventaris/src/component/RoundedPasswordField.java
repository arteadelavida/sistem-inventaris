package component;

import javax.swing.BorderFactory;
import javax.swing.JPasswordField;
import java.awt.*;

/** Password field dengan sudut membulat dan placeholder support. */
public class RoundedPasswordField extends JPasswordField {

    private String placeholder;

    public RoundedPasswordField(String placeholder) {
        this.placeholder = placeholder;
        setOpaque(false);
        setBorder(BorderFactory.createEmptyBorder(6, 15, 6, 15));
        setFont(new Font("SansSerif", Font.PLAIN, 13));
        setupPlaceholder();
    }

    private void setupPlaceholder() {
        setText(placeholder);
        setEchoChar((char) 0); // Matikan sensor agar placeholder terbaca
        setForeground(Color.GRAY);

        addFocusListener(new java.awt.event.FocusAdapter() {
            @Override
            public void focusGained(java.awt.event.FocusEvent e) {
                if (String.valueOf(getPassword()).equals(placeholder)) {
                    setText("");
                    setEchoChar('•');
                    setForeground(Color.BLACK);
                }
            }

            @Override
            public void focusLost(java.awt.event.FocusEvent e) {
                if (String.valueOf(getPassword()).isEmpty()) {
                    setText(placeholder);
                    setEchoChar((char) 0);
                    setForeground(Color.GRAY);
                }
            }
        });
    }

    /** Mengembalikan password sesungguhnya, atau "" jika masih placeholder. */
    public String getRealPassword() {
        String p = String.valueOf(getPassword());
        return p.equals(placeholder) ? "" : p;
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(Color.WHITE);
        g2.fillRoundRect(0, 0, getWidth(), getHeight(), 30, 30);
        g2.dispose();
        super.paintComponent(g);
    }
}
