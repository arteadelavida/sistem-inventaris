package component;

import javax.swing.BorderFactory;
import javax.swing.JTextField;
import java.awt.*;

/** Text field dengan sudut membulat dan placeholder support. */
public class RoundedTextField extends JTextField {

    private String placeholder;

    public RoundedTextField(String placeholder) {
        this.placeholder = placeholder;
        setOpaque(false);
        setBorder(BorderFactory.createEmptyBorder(6, 15, 6, 15));
        setFont(new Font("SansSerif", Font.PLAIN, 13));
        setupPlaceholder();
    }

    private void setupPlaceholder() {
        setText(placeholder);
        setForeground(Color.GRAY);

        addFocusListener(new java.awt.event.FocusAdapter() {
            @Override
            public void focusGained(java.awt.event.FocusEvent e) {
                if (getText().equals(placeholder)) {
                    setText("");
                    setForeground(Color.BLACK);
                }
            }

            @Override
            public void focusLost(java.awt.event.FocusEvent e) {
                if (getText().isEmpty()) {
                    setText(placeholder);
                    setForeground(Color.GRAY);
                }
            }
        });
    }

    /** Mengembalikan teks sesungguhnya, atau "" jika masih placeholder. */
    public String getRealText() {
        String t = getText();
        return t.equals(placeholder) ? "" : t;
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(Color.WHITE);
        g2.fillRoundRect(0, 0, getWidth(), getHeight(), 30, 30);
        g2.dispose();
        super.paintComponent(g);
    }
}
