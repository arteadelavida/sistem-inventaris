package component;

import java.awt.*;
import javax.swing.*;

/**
 * ModernDivider — Pembatas visual yang elegant untuk memisahkan sections.
 */
public class ModernDivider extends JPanel {
    
    private Color color;
    private float opacity;
    private int height;
    
    public ModernDivider() {
        this(new Color(0, 0, 0), 0.1f, 1);
    }
    
    public ModernDivider(Color color, float opacity, int height) {
        this.color = color;
        this.opacity = opacity;
        this.height = height;
        
        setOpaque(false);
        setMaximumSize(new Dimension(Integer.MAX_VALUE, height));
        setPreferredSize(new Dimension(0, height));
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        Graphics2D g2d = (Graphics2D) g.create();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        int alpha = (int)(255 * opacity);
        g2d.setColor(new Color(
            color.getRed(), 
            color.getGreen(), 
            color.getBlue(), 
            alpha
        ));
        g2d.fillRect(0, getHeight() / 2, getWidth(), height);
        
        g2d.dispose();
    }
}
