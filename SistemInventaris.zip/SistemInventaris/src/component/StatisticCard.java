package component;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.*;

/**
 * StatisticCard — Card untuk menampilkan statistik dengan design yang mewah.
 * Menampilkan icon, value, label, dan trend indicator.
 */
public class StatisticCard extends JPanel {
    
    private String label;
    private String value;
    private String subtitle;
    private String icon;
    private Color iconColor;
    private Color accentColor;
    private boolean isHovered = false;
    
    public StatisticCard(String icon, String label, String value, String subtitle, Color iconColor) {
        this.icon = icon;
        this.label = label;
        this.value = value;
        this.subtitle = subtitle;
        this.iconColor = iconColor;
        this.accentColor = iconColor;
        
        setOpaque(false);
        setPreferredSize(new Dimension(200, 140));
        
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                isHovered = true;
                repaint();
            }

            @Override
            public void mouseExited(MouseEvent e) {
                isHovered = false;
                repaint();
            }
        });
    }
    
    /** Update the main value text and trigger repaint. */
    public void setValue(String newValue) {
        this.value = newValue;
        repaint();
    }

    /** Update the subtitle text and trigger repaint. */
    public void setSubtitle(String newSubtitle) {
        this.subtitle = newSubtitle;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        Graphics2D g2d = (Graphics2D) g.create();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        
        int width = getWidth();
        int height = getHeight();
        int shadowOffset = isHovered ? 6 : 3;
        
        // Shadow
        for (int i = shadowOffset; i > 0; i--) {
            float opacity = (1 - (float)i / shadowOffset) * 0.4f;
            g2d.setColor(new Color(0, 0, 0, (int)(255 * opacity)));
            g2d.fillRoundRect(i, i, width - 2*i, height - 2*i, 12, 12);
        }
        
        // Card background
        g2d.setColor(Color.WHITE);
        g2d.fillRoundRect(0, 0, width, height, 12, 12);
        
        // Top accent bar
        g2d.setColor(accentColor);
        g2d.fillRoundRect(0, 0, width, 4, 12, 12);
        
        // Icon background circle
        int iconSize = 50;
        int iconX = width - iconSize - 15;
        int iconY = 15;
        g2d.setColor(new Color(
            accentColor.getRed(), 
            accentColor.getGreen(), 
            accentColor.getBlue(), 
            20
        ));
        g2d.fillOval(iconX, iconY, iconSize, iconSize);
        
        // Icon
        g2d.setColor(iconColor);
        g2d.setFont(new Font("SansSerif", Font.BOLD, 28));
        FontMetrics fm = g2d.getFontMetrics();
        g2d.drawString(icon, 
            iconX + (iconSize - fm.stringWidth(icon)) / 2,
            iconY + ((iconSize + fm.getAscent() - fm.getDescent()) / 2));
        
        // Text
        g2d.setColor(new Color(28, 32, 50));
        g2d.setFont(new Font("SansSerif", Font.BOLD, 22));
        g2d.drawString(value, 15, 50);
        
        g2d.setColor(new Color(120, 130, 155));
        g2d.setFont(new Font("SansSerif", Font.PLAIN, 11));
        g2d.drawString(label, 15, 68);
        
        if (subtitle != null && !subtitle.isEmpty()) {
            g2d.setColor(new Color(76, 175, 80));
            g2d.setFont(new Font("SansSerif", Font.PLAIN, 10));
            g2d.drawString(subtitle, 15, 85);
        }
        
        g2d.dispose();
    }
}
