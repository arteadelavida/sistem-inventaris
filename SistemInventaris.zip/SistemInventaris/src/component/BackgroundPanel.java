package component;

import java.awt.*;
import javax.swing.*;

/**
 * BackgroundPanel menggambar gradien biru dan awan samar sebagai latar.
 * Dipakai di LoginView sebagai JPanel utama.
 */
public class BackgroundPanel extends JPanel {

    private Image imageAwan;

    public BackgroundPanel() {
        try {
            // Cari gambar dari classpath (letakkan di src/resources/)
            java.net.URL url = getClass().getResource("/resources/cloud.png");
            if (url != null) {
                imageAwan = new ImageIcon(url).getImage();
            }
        } catch (Exception e) {
            System.out.println("[BackgroundPanel] Gambar awan tidak ditemukan, lanjut tanpa gambar.");
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING,   RenderingHints.VALUE_RENDER_QUALITY);
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int w = getWidth(), h = getHeight();

        // Gradien biru langit → biru laut
        GradientPaint gp = new GradientPaint(
            0, 0, new Color(137, 207, 240),
            0, h, new Color(50, 150, 220)
        );
        g2d.setPaint(gp);
        g2d.fillRect(0, 0, w, h);

        // Awan semi-transparan (jika gambar tersedia)
        if (imageAwan != null) {
            g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.4f));
            int aw = 180, ah = 100;
            g2d.drawImage(imageAwan, 50, 30, aw, ah, this);
            g2d.drawImage(imageAwan, w - 250, 50, aw, ah, this);
            g2d.drawImage(imageAwan, 100, h / 2 - 50, aw, ah, this);
            g2d.drawImage(imageAwan, w - 200, h - 150, aw, ah, this);
            g2d.drawImage(imageAwan, w / 2 - 90, h - 100, aw + 50, ah + 30, this);
            g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1.0f));
        }
    }
}
