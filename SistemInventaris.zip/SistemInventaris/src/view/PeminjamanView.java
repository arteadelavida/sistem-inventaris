package view;

import controller.PeminjamanController;
import java.awt.*;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.*;
import model.Peminjaman;

/**
 * PeminjamanView — Admin panel untuk memproses permintaan peminjaman.
 * Menampilkan tenggat kembali + sisa hari dengan warna peringatan.
 * Dialog keterangan muncul saat Setujui MAUPUN Tolak.
 */
public class PeminjamanView extends JFrame {

    private static final Color BG        = new Color(240, 244, 252);
    private static final Color CARD_BG   = Color.WHITE;
    private static final Color TEAL      = new Color(0, 168, 190);
    private static final Color TEXT_MAIN = new Color(28, 32, 50);
    private static final Color TEXT_SUB  = new Color(120, 130, 155);
    private static final Color GREEN     = new Color(56, 176, 80);
    private static final Color RED       = new Color(244, 67, 54);
    private static final Color ORANGE    = new Color(255, 152, 0);

    private final PeminjamanController ctrl = new PeminjamanController();
    private DefaultTableModel modelTabel;
    private JTable            tabel;
    private JLabel            lblStatus;

    public PeminjamanView() {
        setTitle("Permintaan Peminjaman Barang");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setMinimumSize(new Dimension(880, 520));
        buatUI();
        muatData();
        pack();
        setLocationRelativeTo(null);
    }

    private void buatUI() {
        setLayout(new BorderLayout());
        getContentPane().setBackground(BG);

        // ── Header ──────────────────────────────────────────────
        JPanel header = new JPanel(new BorderLayout(12, 0));
        header.setBackground(CARD_BG);
        header.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(225, 230, 240)),
            new EmptyBorder(16, 24, 16, 24)
        ));
        JPanel titleStack = new JPanel();
        titleStack.setOpaque(false);
        titleStack.setLayout(new BoxLayout(titleStack, BoxLayout.Y_AXIS));
        JLabel lblJudul = new JLabel("Permintaan Peminjaman");
        lblJudul.setFont(new Font("SansSerif", Font.BOLD, 18));
        lblJudul.setForeground(TEXT_MAIN);
        JLabel lblSub = new JLabel("Tinjau dan proses permintaan dari pengguna — stok otomatis dikurangi saat disetujui");
        lblSub.setFont(new Font("SansSerif", Font.PLAIN, 12));
        lblSub.setForeground(TEXT_SUB);
        titleStack.add(lblJudul);
        titleStack.add(lblSub);

        JButton btnRefresh = buatTombol("↻ Refresh", TEAL, Color.WHITE);
        btnRefresh.addActionListener(e -> muatData());
        header.add(titleStack, BorderLayout.WEST);
        header.add(btnRefresh, BorderLayout.EAST);

        // ── Table ────────────────────────────────────────────────
        JPanel card = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(0,0,0,8));
                g2.fillRoundRect(3,4,getWidth()-4,getHeight()-4,16,16);
                g2.setColor(CARD_BG);
                g2.fillRoundRect(0,0,getWidth()-2,getHeight()-2,16,16);
                g2.dispose();
            }
        };
        card.setOpaque(false);

        // Kolom: ID, Username, Kode, Nama Barang, Jml, Tgl Pinjam, Tenggat Kembali, Status
        String[] kolom = {"ID","Username","Kode","Nama Barang","Jml","Tgl Pinjam","Tenggat Kembali","Status"};
        modelTabel = new DefaultTableModel(kolom, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };

        tabel = new JTable(modelTabel);
        tabel.setRowHeight(36);
        tabel.setFont(new Font("SansSerif", Font.PLAIN, 13));
        tabel.setShowGrid(false);
        tabel.setIntercellSpacing(new Dimension(0,0));
        tabel.setSelectionBackground(new Color(0,168,190,35));
        tabel.setBackground(CARD_BG);

        JTableHeader th = tabel.getTableHeader();
        th.setFont(new Font("SansSerif", Font.BOLD, 12));
        th.setBackground(new Color(246,249,253));
        th.setForeground(TEXT_SUB);
        th.setBorder(BorderFactory.createMatteBorder(0,0,1,0,new Color(228,232,245)));

        tabel.getColumnModel().getColumn(0).setMaxWidth(45);
        tabel.getColumnModel().getColumn(4).setMaxWidth(50);

        // Base renderer
        tabel.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable t, Object v,
                    boolean sel, boolean foc, int row, int col) {
                super.getTableCellRendererComponent(t,v,sel,foc,row,col);
                setFont(new Font("SansSerif", Font.PLAIN, 13));
                setBorder(new EmptyBorder(4,12,4,12));
                setForeground(TEXT_MAIN);
                if (sel) setBackground(new Color(0,168,190,35));
                else     setBackground(row%2==0 ? CARD_BG : new Color(248,250,254));
                return this;
            }
        });

        // Status renderer
        tabel.getColumnModel().getColumn(7).setCellRenderer(new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable t, Object v,
                    boolean sel, boolean foc, int row, int col) {
                super.getTableCellRendererComponent(t,v,sel,foc,row,col);
                setFont(new Font("SansSerif", Font.BOLD, 11));
                setHorizontalAlignment(CENTER);
                setOpaque(true);
                setBorder(new EmptyBorder(4,8,4,8));
                String s = v==null ? "" : v.toString();
                switch (s) {
                    case "pending":
                        setForeground(ORANGE);
                        setBackground(new Color(255,243,224));
                        break;
                    case "disetujui":
                        setForeground(GREEN);
                        setBackground(new Color(232,245,233));
                        break;
                    case "ditolak":
                        setForeground(RED);
                        setBackground(new Color(255,235,238));
                        break;
                    default:
                        setForeground(TEXT_SUB);
                        setBackground(sel?new Color(0,168,190,35):CARD_BG);
                        break;
                }
                return this;
            }
        });

        // Tenggat renderer — merah jika lewat
        tabel.getColumnModel().getColumn(6).setCellRenderer(new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable t, Object v,
                    boolean sel, boolean foc, int row, int col) {
                super.getTableCellRendererComponent(t,v,sel,foc,row,col);
                setBorder(new EmptyBorder(4,12,4,12));
                setOpaque(true);
                if (v == null) { setText("-"); setForeground(TEXT_SUB); setBackground(CARD_BG); return this; }
                try {
                    LocalDate tgl = LocalDate.parse(v.toString());
                    long sisa = ChronoUnit.DAYS.between(LocalDate.now(), tgl);
                    if (sisa < 0)      { setForeground(RED);    setBackground(new Color(255,235,238)); setFont(new Font("SansSerif",Font.BOLD,12)); }
                    else if (sisa <= 3){ setForeground(ORANGE); setBackground(new Color(255,243,224)); setFont(new Font("SansSerif",Font.BOLD,12)); }
                    else               { setForeground(GREEN);  setBackground(sel?new Color(0,168,190,35):(row%2==0?CARD_BG:new Color(248,250,254))); setFont(new Font("SansSerif",Font.PLAIN,13)); }
                } catch (Exception ex) {
                    setForeground(TEXT_MAIN);
                    setBackground(sel?new Color(0,168,190,35):(row%2==0?CARD_BG:new Color(248,250,254)));
                    setFont(new Font("SansSerif",Font.PLAIN,13));
                }
                return this;
            }
        });

        JScrollPane scroll = new JScrollPane(tabel);
        scroll.setBorder(null);
        scroll.getViewport().setBackground(CARD_BG);
        scroll.setPreferredSize(new Dimension(840, 300));
        card.add(scroll, BorderLayout.CENTER);

        // ── Action bar ───────────────────────────────────────────
        JButton btnSetujui = buatTombol("✔  Setujui", GREEN, Color.WHITE);
        JButton btnTolak   = buatTombol("✕  Tolak",   RED,   Color.WHITE);
        lblStatus = new JLabel("Pilih baris, lalu klik Setujui atau Tolak.");
        lblStatus.setFont(new Font("SansSerif", Font.PLAIN, 11));
        lblStatus.setForeground(TEXT_SUB);

        btnSetujui.addActionListener(e -> prosesSetujui());
        btnTolak.addActionListener(e -> prosesTolak());

        JPanel actionBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 12));
        actionBar.setOpaque(false);
        actionBar.add(btnSetujui);
        actionBar.add(btnTolak);
        actionBar.add(lblStatus);

        JPanel center = new JPanel(new BorderLayout());
        center.setBackground(BG);
        center.setBorder(new EmptyBorder(16,20,10,20));
        center.add(card,      BorderLayout.CENTER);
        center.add(actionBar, BorderLayout.SOUTH);

        add(header, BorderLayout.NORTH);
        add(center, BorderLayout.CENTER);
    }

    // ── Data ──────────────────────────────────────────────────────

    private void muatData() {
        try {
            modelTabel.setRowCount(0);
            List<Peminjaman> list = ctrl.getPending();
            for (Peminjaman p : list) {
                modelTabel.addRow(new Object[]{
                    p.getId(), p.getUsername(), p.getKodeBarang(), p.getNamaBarang(),
                    p.getJumlah(),
                    p.getTanggalPinjam() != null ? p.getTanggalPinjam().toString() : "-",
                    p.getTanggalKembali() != null ? p.getTanggalKembali().toString() : "-",
                    p.getStatus()
                });
            }
            lblStatus.setText("Total " + list.size() + " permintaan pending.");
        } catch (SQLException e) {
            lblStatus.setText("Error: " + e.getMessage());
        }
    }

    // ── Setujui ───────────────────────────────────────────────────

    private void prosesSetujui() {
        int row = tabel.getSelectedRow();
        if (row < 0) { info("Pilih baris terlebih dahulu."); return; }
        int    id      = (int)  modelTabel.getValueAt(row, 0);
        String user    = modelTabel.getValueAt(row, 1).toString();
        String nama    = modelTabel.getValueAt(row, 3).toString();
        int    jml     = (int)  modelTabel.getValueAt(row, 4);
        String tenggat = modelTabel.getValueAt(row, 6).toString();

        JPanel dlg = new JPanel();
        dlg.setLayout(new BoxLayout(dlg, BoxLayout.Y_AXIS));
        dlg.setBorder(new EmptyBorder(6,0,0,0));
        JLabel lblInfo = new JLabel("<html><b>" + user + "</b> meminjam <b>" + jml + "× " + nama + "</b></html>");
        JLabel lblTgl  = new JLabel("Tenggat kembali: " + tenggat);
        lblTgl.setFont(new Font("SansSerif", Font.PLAIN, 12));
        dlg.add(lblInfo);
        dlg.add(Box.createVerticalStrut(4));
        dlg.add(lblTgl);
        dlg.add(Box.createVerticalStrut(12));
        dlg.add(new JLabel("Catatan untuk peminjam (opsional):"));
        dlg.add(Box.createVerticalStrut(4));
        JTextArea ta = buatTextArea();
        dlg.add(new JScrollPane(ta));

        int opt = JOptionPane.showConfirmDialog(this, dlg,
            "Konfirmasi Setujui", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (opt != JOptionPane.OK_OPTION) return;

        try {
            ctrl.setujuiDenganKeterangan(id, ta.getText().trim());
            muatData();
            lblStatus.setText("✔ Peminjaman #" + id + " disetujui — stok dikurangi otomatis.");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Gagal", JOptionPane.ERROR_MESSAGE);
        }
    }

    // ── Tolak ─────────────────────────────────────────────────────

    private void prosesTolak() {
        int row = tabel.getSelectedRow();
        if (row < 0) { info("Pilih baris terlebih dahulu."); return; }
        int    id   = (int)  modelTabel.getValueAt(row, 0);
        String user = modelTabel.getValueAt(row, 1).toString();
        String nama = modelTabel.getValueAt(row, 3).toString();

        JPanel dlg = new JPanel();
        dlg.setLayout(new BoxLayout(dlg, BoxLayout.Y_AXIS));
        dlg.setBorder(new EmptyBorder(6,0,0,0));
        dlg.add(new JLabel("<html>Tolak permintaan <b>" + user + "</b> — <b>" + nama + "</b>?</html>"));
        dlg.add(Box.createVerticalStrut(10));
        dlg.add(new JLabel("Alasan penolakan (opsional):"));
        dlg.add(Box.createVerticalStrut(4));
        JTextArea ta = buatTextArea();
        dlg.add(new JScrollPane(ta));

        int opt = JOptionPane.showConfirmDialog(this, dlg,
            "Konfirmasi Tolak", JOptionPane.OK_CANCEL_OPTION, JOptionPane.WARNING_MESSAGE);
        if (opt != JOptionPane.OK_OPTION) return;

        try {
            ctrl.tolakDenganKeterangan(id, ta.getText().trim());
            muatData();
            lblStatus.setText("✕ Permintaan #" + id + " ditolak.");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Gagal", JOptionPane.ERROR_MESSAGE);
        }
    }

    // ── Helpers ───────────────────────────────────────────────────

    private JTextArea buatTextArea() {
        JTextArea ta = new JTextArea(3, 30);
        ta.setLineWrap(true);
        ta.setWrapStyleWord(true);
        ta.setFont(new Font("SansSerif", Font.PLAIN, 13));
        ta.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(218,225,238)),
            new EmptyBorder(6,8,6,8)
        ));
        return ta;
    }

    private JButton buatTombol(String teks, Color bg, Color fg) {
        JButton btn = new JButton(teks) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isRollover() ? bg.darker() : bg);
                g2.fillRoundRect(0,0,getWidth(),getHeight(),10,10);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setForeground(fg);
        btn.setFont(new Font("SansSerif", Font.BOLD, 12));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(130, 36));
        return btn;
    }

    private void info(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Info", JOptionPane.INFORMATION_MESSAGE);
    }
}
