package view;

import component.RoundedButton;
import controller.PeminjamanController;
import controller.ReturnItemController;
import java.awt.*;
import java.sql.SQLException;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

/**
 * UserReturnItemView — User view untuk request pengembalian barang.
 * User bisa memilih barang dari peminjaman aktif dan request pengembalian.
 */
public class UserReturnItemView extends JPanel {
    
    // Warna
    private static final Color PRIMARY = new Color(0, 105, 140);
    private static final Color PRIMARY_LIGHT = new Color(0, 188, 212);
    private static final Color SUCCESS = new Color(76, 175, 80);
    private static final Color ERROR = new Color(244, 67, 54);
    private static final Color TEXT_LIGHT = new Color(120, 130, 155);
    private static final Color FIELD_BG = new Color(248, 250, 253);

    private JTable tblPeminjaman;
    private JComboBox<String> cbKondisi;
    private JTextArea txtKeterangan;
    private JTextField txtJumlahReturn;  // NEW: quantity field
    private RoundedButton btnRequest;
    private JLabel lblStatus;
    private ReturnItemController controller;
    private String currentUsername;
    private java.util.List<model.Peminjaman> peminjamanList; // Store for reference

    public UserReturnItemView(String username) {
        this.currentUsername = username;
        this.controller = new ReturnItemController();
        this.peminjamanList = new java.util.ArrayList<>();
        buatUI();
    }

    private void buatUI() {
        setLayout(new BorderLayout(15, 15));
        setBorder(new EmptyBorder(20, 20, 20, 20));
        setBackground(Color.WHITE);

        // Header
        JPanel pnlHeader = new JPanel();
        pnlHeader.setOpaque(false);
        pnlHeader.setLayout(new BoxLayout(pnlHeader, BoxLayout.Y_AXIS));
        pnlHeader.setBorder(new EmptyBorder(0, 0, 15, 0));

        JLabel lblTitle = new JLabel("Kembalikan Barang Pinjaman");
        lblTitle.setFont(new Font("SansSerif", Font.BOLD, 18));
        lblTitle.setForeground(new Color(15, 32, 68));

        JLabel lblDesc = new JLabel("Pilih barang yang ingin dikembalikan, isi kondisi dan keterangan");
        lblDesc.setFont(new Font("SansSerif", Font.PLAIN, 11));
        lblDesc.setForeground(TEXT_LIGHT);

        pnlHeader.add(lblTitle);
        pnlHeader.add(Box.createVerticalStrut(5));
        pnlHeader.add(lblDesc);

        // Tabel peminjaman
        tblPeminjaman = buatTablePeminjaman();
        JScrollPane scrollTable = new JScrollPane(tblPeminjaman);
        scrollTable.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));

        // Form return
        JPanel pnlForm = buatFormPanel();

        // Status
        lblStatus = new JLabel(" ");
        lblStatus.setFont(new Font("SansSerif", Font.PLAIN, 11));

        // Button request
        JPanel pnlButton = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        pnlButton.setOpaque(false);

        btnRequest = new RoundedButton("Kirim Request");
        btnRequest.setPreferredSize(new Dimension(150, 35));
        btnRequest.setBackground(SUCCESS);
        btnRequest.setForeground(Color.WHITE);
        btnRequest.addActionListener(e -> submitReturnRequest());

        pnlButton.add(btnRequest);

        // Assemble
        add(pnlHeader, BorderLayout.NORTH);
        
        JPanel pnlCenter = new JPanel(new BorderLayout(10, 10));
        pnlCenter.setOpaque(false);
        pnlCenter.add(new JLabel("Daftar Peminjaman Aktif:"), BorderLayout.NORTH);
        pnlCenter.add(scrollTable, BorderLayout.CENTER);
        
        JSplitPane split = new JSplitPane(JSplitPane.VERTICAL_SPLIT, pnlCenter, pnlForm);
        split.setOpaque(false);
        split.setDividerLocation(250);
        
        JPanel pnlContent = new JPanel(new BorderLayout(10, 10));
        pnlContent.setOpaque(false);
        pnlContent.add(split, BorderLayout.CENTER);
        pnlContent.add(lblStatus, BorderLayout.SOUTH);

        add(pnlContent, BorderLayout.CENTER);
        add(pnlButton, BorderLayout.SOUTH);

        // Load data
        loadPeminjaman();
    }

    private JTable buatTablePeminjaman() {
        DefaultTableModel model = new DefaultTableModel(
            new String[]{"Barang", "Jumlah", "Tanggal Pinjam", "Target Kembali"}, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        JTable table = new JTable(model);
        table.setFont(new Font("SansSerif", Font.PLAIN, 10));
        table.setRowHeight(22);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setGridColor(new Color(230, 230, 230));

        JTableHeader header = table.getTableHeader();
        header.setBackground(PRIMARY);
        header.setForeground(Color.WHITE);
        header.setFont(new Font("SansSerif", Font.BOLD, 10));

        return table;
    }

    private JPanel buatFormPanel() {
        JPanel panel = new JPanel();
        panel.setOpaque(false);
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(new EmptyBorder(15, 15, 15, 15));

        JLabel lblFormTitle = new JLabel("Detail Pengembalian");
        lblFormTitle.setFont(new Font("SansSerif", Font.BOLD, 13));
        lblFormTitle.setAlignmentX(LEFT_ALIGNMENT);

        // Jumlah dikembalikan
        JLabel lblJumlah = new JLabel("Jumlah Dikembalikan:");
        lblJumlah.setFont(new Font("SansSerif", Font.PLAIN, 10));
        lblJumlah.setAlignmentX(LEFT_ALIGNMENT);

        JTextField txtJumlah = new JTextField();
        txtJumlah.setFont(new Font("SansSerif", Font.PLAIN, 10));
        txtJumlah.setMaximumSize(new Dimension(300, 30));
        txtJumlah.setAlignmentX(LEFT_ALIGNMENT);
        txtJumlah.setToolTipText("Masukkan jumlah barang yang dikembalikan");

        // Kondisi
        JLabel lblKondisi = new JLabel("Kondisi Barang:");
        lblKondisi.setFont(new Font("SansSerif", Font.PLAIN, 10));
        lblKondisi.setAlignmentX(LEFT_ALIGNMENT);

        cbKondisi = new JComboBox<>(new String[]{"Baik", "Rusak Ringan", "Rusak Berat", "Hilang"});
        cbKondisi.setMaximumSize(new Dimension(300, 30));
        cbKondisi.setAlignmentX(LEFT_ALIGNMENT);

        // Keterangan
        JLabel lblKeterangan = new JLabel("Keterangan:");
        lblKeterangan.setFont(new Font("SansSerif", Font.PLAIN, 10));
        lblKeterangan.setAlignmentX(LEFT_ALIGNMENT);

        txtKeterangan = new JTextArea(3, 40);
        txtKeterangan.setFont(new Font("SansSerif", Font.PLAIN, 10));
        txtKeterangan.setBackground(FIELD_BG);
        txtKeterangan.setLineWrap(true);
        txtKeterangan.setWrapStyleWord(true);
        txtKeterangan.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));

        JScrollPane scrollKeterangan = new JScrollPane(txtKeterangan);
        scrollKeterangan.setMaximumSize(new Dimension(300, 80));
        scrollKeterangan.setAlignmentX(LEFT_ALIGNMENT);

        // Store txtJumlah as instance variable for submitReturnRequest to use
        this.txtJumlahReturn = txtJumlah;

        // Assemble
        panel.add(lblFormTitle);
        panel.add(Box.createVerticalStrut(10));
        panel.add(lblJumlah);
        panel.add(Box.createVerticalStrut(5));
        panel.add(txtJumlah);
        panel.add(Box.createVerticalStrut(15));
        panel.add(lblKondisi);
        panel.add(Box.createVerticalStrut(5));
        panel.add(cbKondisi);
        panel.add(Box.createVerticalStrut(15));
        panel.add(lblKeterangan);
        panel.add(Box.createVerticalStrut(5));
        panel.add(scrollKeterangan);
        panel.add(Box.createVerticalGlue());

        return panel;
    }

    private void loadPeminjaman() {
        DefaultTableModel model = (DefaultTableModel) tblPeminjaman.getModel();
        model.setRowCount(0);
        peminjamanList.clear();

        try {
            controller.getPendingReturnRequests(); // Initialize database if needed
            
            // Get all active peminjaman for this user (status = 'disetujui')
            PeminjamanController pctrl = new PeminjamanController();
            java.util.List<model.Peminjaman> allPeminjaman = pctrl.getByUser(currentUsername);
            
            java.time.format.DateTimeFormatter dtf = java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy");
            
            for (model.Peminjaman p : allPeminjaman) {
                // Only show approved peminjaman that haven't been returned yet
                // status = 'disetujui' AND status_return != 'dikembalikan'
                if ("disetujui".equalsIgnoreCase(p.getStatus()) && 
                    !"dikembalikan".equalsIgnoreCase(p.getStatusReturn())) {
                    model.addRow(new Object[]{
                        p.getNamaBarang(),
                        p.getJumlah(),
                        p.getTanggalPinjam().format(dtf),
                        p.getTanggalKembali().format(dtf)
                    });
                    peminjamanList.add(p);
                }
            }
            
            if (peminjamanList.isEmpty()) {
                lblStatus.setText("Anda tidak memiliki barang yang sedang dipinjam.");
                lblStatus.setForeground(new Color(100, 100, 100));
            } else {
                lblStatus.setText("Pilih barang untuk dikembalikan.");
                lblStatus.setForeground(new Color(0, 105, 140));
            }
        } catch (SQLException e) {
            lblStatus.setText("Error memuat data: " + e.getMessage());
            lblStatus.setForeground(ERROR);
            e.printStackTrace();
        }
    }

    private void submitReturnRequest() {
        int selectedRow = tblPeminjaman.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this, "Pilih barang yang ingin dikembalikan!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (selectedRow >= peminjamanList.size()) {
            JOptionPane.showMessageDialog(this, "Data tidak valid!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        model.Peminjaman selected = peminjamanList.get(selectedRow);
        
        // Validate quantity
        String jumlahStr = txtJumlahReturn.getText().trim();
        if (jumlahStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Masukkan jumlah barang yang dikembalikan!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int jumlahDikembalikan;
        try {
            jumlahDikembalikan = Integer.parseInt(jumlahStr);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Jumlah harus berupa angka!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        if (jumlahDikembalikan <= 0) {
            JOptionPane.showMessageDialog(this, "Jumlah harus lebih dari 0!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        if (jumlahDikembalikan > selected.getJumlah()) {
            JOptionPane.showMessageDialog(this, 
                "Jumlah dikembalikan tidak boleh melebihi jumlah pinjam (" + selected.getJumlah() + ")!", 
                "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        String kondisi = ((String) cbKondisi.getSelectedItem()).toLowerCase();
        String keterangan = txtKeterangan.getText().trim();

        if (keterangan.isEmpty()) {
            keterangan = "-";
        }

        // Validate kondisi mapping
        String kondisiDb = kondisi;
        if ("baik".equalsIgnoreCase(kondisi)) kondisiDb = "baik";
        else if ("rusak ringan".equalsIgnoreCase(kondisi)) kondisiDb = "rusak ringan";
        else if ("rusak berat".equalsIgnoreCase(kondisi)) kondisiDb = "rusak berat";
        else if ("hilang".equalsIgnoreCase(kondisi)) kondisiDb = "hilang";
        
        // Submit return request with specified quantity
        try {
            int returnId = controller.createReturnRequest(
                selected.getId(), 
                currentUsername, 
                jumlahDikembalikan,  // Use input quantity, not total
                kondisiDb, 
                keterangan
            );

            if (returnId > 0) {
                JOptionPane.showMessageDialog(this, 
                    "✓ Request pengembalian telah dikirim!\nJumlah: " + jumlahDikembalikan + " unit\nAdmin akan mereview dalam 24 jam.",
                    "Sukses", JOptionPane.INFORMATION_MESSAGE);

                // Reset form
                cbKondisi.setSelectedIndex(0);
                txtKeterangan.setText("");
                txtJumlahReturn.setText("");
                loadPeminjaman();
            } else {
                JOptionPane.showMessageDialog(this, 
                    "✗ Gagal mengirim request. Periksa apakah barang sudah dikembalikan sebelumnya.",
                    "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, 
                "✗ Error: " + e.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
