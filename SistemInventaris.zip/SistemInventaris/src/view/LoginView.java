package view;

import controller.AuthController;
import java.awt.*;
import java.awt.event.*;
import java.sql.SQLException;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import model.User;

/**
 * LoginView — Elegant split-panel login.
 * Kiri : Deep gradient dengan branding sistem inventaris
 * Kanan: Form bersih dengan hover effect pada input field
 */
public class LoginView extends JFrame {

    // ── Warna global (dibagi dengan RegisterView) ──────────────────
    static final Color DEEP_1  = new Color(15, 32, 68);     // very dark navy
    static final Color DEEP_2  = new Color(0, 105, 140);    // mid teal
    static final Color DEEP_3  = new Color(0, 188, 212);    // bright teal
    static final Color TEAL    = new Color(0, 168, 190);
    static final Color BORDER_IDLE   = new Color(212, 218, 230);
    static final Color BORDER_HOVER  = new Color(0, 168, 190);
    static final Color BORDER_FOCUS  = new Color(0, 140, 168);
    static final Color TEXT_MAIN     = new Color(28, 32, 50);
    static final Color TEXT_SUB      = new Color(120, 130, 155);
    static final Color FIELD_BG      = new Color(248, 250, 253);

    private ElegantField fldUsername;
    private ElegantField fldPassword;
    private final AuthController auth = new AuthController();

    public LoginView() {
        setTitle("Sistem Inventaris – Login");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        buatUI();
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void buatUI() {
        JPanel root = new JPanel(new GridLayout(1, 2));
        root.setPreferredSize(new Dimension(900, 560));
        root.add(buatPanelKiri());
        root.add(buatPanelKanan());
        setContentPane(root);
    }

    // ─── KIRI: branding ───────────────────────────────────────────

    private JPanel buatPanelKiri() {
        JPanel panel = new DeepPanel();
        panel.setLayout(new GridBagLayout());

        JPanel content = new JPanel();
        content.setOpaque(false);
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setBorder(new EmptyBorder(0, 30, 0, 30));

        // Ikon inventaris (digambar)
        JPanel iconBox = buatIconBulat("☰", 52, new Color(255,255,255,40), Color.WHITE);
        iconBox.setAlignmentX(CENTER_ALIGNMENT);

        JLabel lblBrand = new JLabel("SISTEM INVENTARIS");
        lblBrand.setFont(new Font("SansSerif", Font.BOLD, 11));
        lblBrand.setForeground(new Color(0, 220, 240));
        lblBrand.setAlignmentX(CENTER_ALIGNMENT);
        lblBrand.setBorder(new EmptyBorder(14, 0, 2, 0));

        JLabel lblWelcome1 = new JLabel("Welcome to");
        lblWelcome1.setFont(new Font("SansSerif", Font.PLAIN, 28));
        lblWelcome1.setForeground(new Color(200, 230, 255));
        lblWelcome1.setAlignmentX(CENTER_ALIGNMENT);

        JLabel lblWelcome2 = new JLabel("Sistem Inventaris");
        lblWelcome2.setFont(new Font("SansSerif", Font.BOLD, 28));
        lblWelcome2.setForeground(Color.WHITE);
        lblWelcome2.setAlignmentX(CENTER_ALIGNMENT);

        JLabel lblTagline = buatLabel("Kelola aset perusahaan dengan mudah,\ncepat, dan terpercaya.", 12, Font.PLAIN, new Color(180, 210, 240));
        lblTagline.setAlignmentX(CENTER_ALIGNMENT);

        // Divider
        JSeparator sep = new JSeparator();
        sep.setForeground(new Color(255, 255, 255, 40));
        sep.setMaximumSize(new Dimension(240, 1));
        sep.setAlignmentX(CENTER_ALIGNMENT);

        JLabel lblPrompt = buatLabel("Belum punya akun?", 12, Font.PLAIN, new Color(180, 210, 240));
        lblPrompt.setAlignmentX(CENTER_ALIGNMENT);

        JButton btnDaftar = buatOutlineButton("Daftar Sekarang");
        btnDaftar.setAlignmentX(CENTER_ALIGNMENT);
        btnDaftar.addActionListener(e -> { new RegisterView(); dispose(); });

        content.add(iconBox);
        content.add(Box.createVerticalStrut(8));
        content.add(lblBrand);
        content.add(Box.createVerticalStrut(16));
        content.add(lblWelcome1);
        content.add(lblWelcome2);
        content.add(Box.createVerticalStrut(14));
        content.add(lblTagline);
        content.add(Box.createVerticalStrut(28));
        content.add(sep);
        content.add(Box.createVerticalStrut(20));
        content.add(lblPrompt);
        content.add(Box.createVerticalStrut(12));
        content.add(btnDaftar);

        panel.add(content);
        return panel;
    }

    // ─── KANAN: form ──────────────────────────────────────────────

    private JPanel buatPanelKanan() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.WHITE);

        JPanel form = new JPanel();
        form.setOpaque(false);
        form.setLayout(new BoxLayout(form, BoxLayout.Y_AXIS));
        form.setPreferredSize(new Dimension(340, 440));

        JLabel lblSub = buatLabel("SELAMAT DATANG", 10, Font.BOLD, DEEP_3);
        lblSub.setAlignmentX(CENTER_ALIGNMENT);

        JLabel lblTitle = buatLabel("Masuk ke Akun", 30, Font.BOLD, TEXT_MAIN);
        lblTitle.setAlignmentX(CENTER_ALIGNMENT);

        JLabel lblDesc = buatLabel("Masukkan kredensial Anda untuk melanjutkan", 12, Font.PLAIN, TEXT_SUB);
        lblDesc.setAlignmentX(CENTER_ALIGNMENT);

        fldUsername = new ElegantField("Nama Pengguna", false);
        fldUsername.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));

        fldPassword = new ElegantField("Kata Sandi", true);
        fldPassword.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));

        JLabel lblForgot = buatLabel("Lupa kata sandi?", 11, Font.PLAIN, TEAL);
        lblForgot.setAlignmentX(RIGHT_ALIGNMENT);
        lblForgot.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        JButton btnLogin = buatGradientButton("Masuk  →");
        btnLogin.setAlignmentX(CENTER_ALIGNMENT);
        btnLogin.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));
        btnLogin.addActionListener(e -> prosesLogin());
        fldPassword.setEnterAction(e -> prosesLogin());

        JLabel lblOrReg = buatLabel("Belum terdaftar? ", 12, Font.PLAIN, TEXT_SUB);
        JLabel lblRegLink = buatLabel("Buat akun baru", 12, Font.BOLD, TEAL);
        lblRegLink.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        lblRegLink.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) { new RegisterView(); dispose(); }
        });

        JPanel regRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 2, 0));
        regRow.setOpaque(false);
        regRow.add(lblOrReg);
        regRow.add(lblRegLink);
        regRow.setAlignmentX(CENTER_ALIGNMENT);

        form.add(lblSub);
        form.add(Box.createVerticalStrut(6));
        form.add(lblTitle);
        form.add(Box.createVerticalStrut(6));
        form.add(lblDesc);
        form.add(Box.createVerticalStrut(30));
        
        // Field wrapper dengan label sejajar
        form.add(buatFieldWithLabel("Username", fldUsername));
        form.add(Box.createVerticalStrut(16));
        form.add(buatFieldWithLabel("Password", fldPassword));
        form.add(Box.createVerticalStrut(8));
        
        // Lupa kata sandi - centered
        JPanel forgotRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
        forgotRow.setOpaque(false);
        forgotRow.setAlignmentX(CENTER_ALIGNMENT);
        forgotRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 22));
        forgotRow.add(lblForgot);
        lblForgot.setAlignmentX(CENTER_ALIGNMENT);
        lblForgot.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        lblForgot.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) { bukaLupaKataSandi(); }
        });
        form.add(forgotRow);
        
        form.add(Box.createVerticalStrut(24));
        form.add(btnLogin);
        form.add(Box.createVerticalStrut(20));
        form.add(regRow);

        panel.add(form);
        return panel;
    }

    // ─── Helper: Wrapper label + field ────────────────────────────
    private JPanel buatFieldWithLabel(String labelText, JComponent field) {
        JPanel wrapper = new JPanel();
        wrapper.setOpaque(false);
        wrapper.setLayout(new BoxLayout(wrapper, BoxLayout.Y_AXIS));
        wrapper.setAlignmentX(CENTER_ALIGNMENT);
        wrapper.setMaximumSize(new Dimension(Integer.MAX_VALUE, 70));
        
        JLabel label = buatFormLabel(labelText);
        label.setAlignmentX(LEFT_ALIGNMENT);
        
        wrapper.add(label);
        wrapper.add(Box.createVerticalStrut(6));
        wrapper.add(field);
        
        return wrapper;
    }

    // ─── Dialog: Lupa Kata Sandi ──────────────────────────────────
    private void bukaLupaKataSandi() {
        ForgotPasswordDialog dialog = new ForgotPasswordDialog(this);
        dialog.setVisible(true);
    }

    // ─── Logika ───────────────────────────────────────────────────

    private void prosesLogin() {
        String username = fldUsername.getValue().trim();
        String password = fldPassword.getValue();
        if (username.isEmpty() || password.isEmpty()) {
            showErr("Username dan Password harus diisi!"); return;
        }
        try {
            User user = auth.login(username, password);
            if (user == null) { showErr("Username atau Password salah!"); return; }
            new BarangView().setVisible(true);
            dispose();
        } catch (AuthController.PendingAccountException ex) {
            showErr(ex.getMessage());
        } catch (SQLException ex) {
            showErr("Koneksi database gagal:\n" + ex.getMessage());
        }
    }

    private void showErr(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Perhatian", JOptionPane.WARNING_MESSAGE);
    }

    // ─── Shared helpers ───────────────────────────────────────────

    static JLabel buatLabel(String teks, int size, int style, Color color) {
        JLabel lbl = new JLabel(teks);
        lbl.setFont(new Font("SansSerif", style, size));
        lbl.setForeground(color);
        return lbl;
    }

    static JLabel buatFormLabel(String teks) {
        JLabel lbl = new JLabel(teks);
        lbl.setFont(new Font("SansSerif", Font.BOLD, 12));
        lbl.setForeground(TEXT_MAIN);
        lbl.setAlignmentX(LEFT_ALIGNMENT);
        return lbl;
    }

    static JButton buatGradientButton(String teks) {
        JButton btn = new JButton(teks) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                Color c1 = getModel().isRollover() ? new Color(0, 148, 175) : TEAL;
                Color c2 = getModel().isRollover() ? new Color(0, 100, 130) : DEEP_2;
                g2.setPaint(new GradientPaint(0, 0, c1, getWidth(), 0, c2));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 14, 14);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("SansSerif", Font.BOLD, 14));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return btn;
    }

    static JButton buatOutlineButton(String teks) {
        JButton btn = new JButton(teks) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (getModel().isRollover()) {
                    g2.setColor(new Color(255, 255, 255, 30));
                    g2.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);
                }
                g2.setColor(Color.WHITE);
                g2.setStroke(new BasicStroke(1.5f));
                g2.drawRoundRect(1, 1, getWidth()-3, getHeight()-3, 12, 12);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("SansSerif", Font.BOLD, 13));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(200, 42));
        btn.setMaximumSize(new Dimension(200, 42));
        return btn;
    }

    static JPanel buatIconBulat(String icon, int size, Color bg, Color fg) {
        JPanel p = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(bg);
                g2.fillOval(0, 0, getWidth(), getHeight());
                g2.setColor(fg);
                g2.setFont(new Font("SansSerif", Font.BOLD, size / 2));
                FontMetrics fm = g2.getFontMetrics();
                g2.drawString(icon,
                    (getWidth()  - fm.stringWidth(icon)) / 2,
                    (getHeight() + fm.getAscent() - fm.getDescent()) / 2);
                g2.dispose();
            }
        };
        p.setOpaque(false);
        p.setPreferredSize(new Dimension(size, size));
        p.setMaximumSize(new Dimension(size, size));
        return p;
    }

    // ─── Inner: Deep gradient background panel ────────────────────

    static class DeepPanel extends JPanel {
        @Override protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
            // Base gradient
            g2.setPaint(new GradientPaint(0, 0, DEEP_1, getWidth(), getHeight(), new Color(0, 80, 110)));
            g2.fillRect(0, 0, getWidth(), getHeight());
            // Decorative circles
            g2.setColor(new Color(255, 255, 255, 12));
            g2.fillOval(-60, -60, 220, 220);
            g2.fillOval(getWidth()-120, getHeight()-120, 260, 260);
            g2.setColor(new Color(0, 220, 240, 15));
            g2.fillOval(getWidth()-80, -40, 180, 180);
            g2.fillOval(-40, getHeight()-80, 160, 160);
        }
    }

    // ─── Inner: Elegant input field with hover effect ─────────────

    static class ElegantField extends JPanel {
        private final JTextField field;
        private Color borderColor = BORDER_IDLE;
        private final String placeholder;
        private final boolean isPassword;

        ElegantField(String placeholder, boolean isPassword) {
            this.placeholder = placeholder;
            this.isPassword  = isPassword;
            setOpaque(false);
            setLayout(new BorderLayout());
            setBorder(new EmptyBorder(2, 2, 2, 2));

            if (isPassword) {
                JPasswordField pf = new JPasswordField();
                pf.setEchoChar('•');
                pf.setFont(new Font("SansSerif", Font.PLAIN, 14));
                pf.setBorder(new EmptyBorder(2, 14, 10, 14));
                pf.setOpaque(false);
                pf.setForeground(TEXT_MAIN);
                setupFocus(pf);
                field = pf;
            } else {
                JTextField tf = new JTextField();
                tf.setFont(new Font("SansSerif", Font.PLAIN, 14));
                tf.setBorder(new EmptyBorder(2, 14, 10, 14));
                tf.setOpaque(false);
                tf.setForeground(TEXT_MAIN);
                setupFocus(tf);
                field = tf;
            }

            // Set placeholder
            field.setText(placeholder);
            field.setForeground(new Color(180, 185, 200));

            addMouseListener(new MouseAdapter() {
                public void mouseEntered(MouseEvent e) {
                    if (!field.isFocusOwner()) { borderColor = BORDER_HOVER; repaint(); }
                }
                public void mouseExited(MouseEvent e) {
                    if (!field.isFocusOwner()) { borderColor = BORDER_IDLE; repaint(); }
                }
            });

            field.addMouseListener(new MouseAdapter() {
                public void mouseEntered(MouseEvent e) {
                    if (!field.isFocusOwner()) { borderColor = BORDER_HOVER; repaint(); }
                }
                @Override
                public void mouseExited(MouseEvent e) {
                    if (!field.isFocusOwner()) { borderColor = BORDER_IDLE; repaint(); }
                }
            });

            add(field, BorderLayout.CENTER);
        }

        private void setupFocus(JTextField tf) {
            tf.addFocusListener(new FocusAdapter() {
                public void focusGained(FocusEvent e) {
                    borderColor = BORDER_FOCUS;
                    if (tf.getText().equals(placeholder)) {
                        tf.setText("");
                        tf.setForeground(TEXT_MAIN);
                        if (isPassword && tf instanceof JPasswordField)
                            ((JPasswordField) tf).setEchoChar('•');
                    }
                    repaint();
                }
                public void focusLost(FocusEvent e) {
                    borderColor = BORDER_IDLE;
                    if (tf.getText().isEmpty()) {
                        tf.setText(placeholder);
                        tf.setForeground(new Color(180, 185, 200));
                        if (isPassword && tf instanceof JPasswordField)
                            ((JPasswordField) tf).setEchoChar((char)0);
                    }
                    repaint();
                }
            });
        }

        public void setEnterAction(java.awt.event.ActionListener al) {
            field.addActionListener(al);
        }

        public String getValue() {
            String val = field.getText();
            return val.equals(placeholder) ? "" : val;
        }

        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            // Shadow effect
            g2.setColor(new Color(0, 0, 0, 8));
            g2.fillRoundRect(2, 3, getWidth()-4, getHeight()-2, 14, 14);
            // Field background
            g2.setColor(FIELD_BG);
            g2.fillRoundRect(0, 0, getWidth()-1, getHeight()-2, 12, 12);
            // Border
            g2.setColor(borderColor);
            g2.setStroke(new BasicStroke(borderColor.equals(BORDER_IDLE) ? 1.0f : 1.8f));
            g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-2, 12, 12);
            g2.dispose();
        }
    }
}
