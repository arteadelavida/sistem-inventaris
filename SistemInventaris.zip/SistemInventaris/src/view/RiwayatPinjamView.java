package view;

import controller.PeminjamanController;
import model.Peminjaman;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.*;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;
import java.time.temporal.ChronoUnit;

/**
 * RiwayatPinjamView — Tampilan riwayat peminjaman milik user tertentu.
 * Dipanggil dari BarangView (user side).
 */
public class RiwayatPinjamView extends JFrame {

    private static final Color BG       = new Color(240, 244, 252);
    private static final Color CARD_BG  = Color.WHITE;
    private static final Color TEAL     = new Color(0, 168, 190);
    private static final Color TEXT_MAIN= new Color(28, 32, 50);
    private static final Color TEXT_SUB = new Color(120, 130, 155);
    private static final Color GREEN    = new Color(56, 176, 80);
    private static final Color RED      = new Color(244, 67, 54);
    private static final Color ORANGE   = new Color(255, 152, 0);

    private final String                username;
    private final PeminjamanController  ctrl = new PeminjamanController();
    private DefaultTableModel           modelTabel;
    private JLabel                      lblRingkasan;

    public RiwayatPinjamView(String username) {
        this.username = username;
        setTitle("Riwayat Peminjaman — " + username);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setMinimumSize(new Dimension(680, 460));
        buatUI();
        muatData();
        pack();
        setLocationRelativeTo(null);
    }

    private void buatUI() {
        setLayout(new BorderLayout());
        getContentPane().setBackground(BG);

        // ── Top bar ──────────────────────────────────────────────
        JPanel topBar = new JPanel(new BorderLayout(12, 0));
        topBar.setBackground(CARD_BG);
        topBar.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(225, 230, 240)),
            new EmptyBorder(16, 24, 16, 24)
        ));

        JPanel titleStack = new JPanel();
        titleStack.setOpaque(false);
        titleStack.setLayout(new BoxLayout(titleStack, BoxLayout.Y_AXIS));

        JLabel lblJudul = new JLabel("Riwayat Peminjaman Saya");
        lblJudul.setFont(new Font("SansSerif", Font.BOLD, 18));
        lblJudul.setForeground(TEXT_MAIN);

        lblRingkasan = new JLabel("Memuat data...");
        lblRingkasan.setFont(new Font("SansSerif", Font.PLAIN, 12));
        lblRingkasan.setForeground(TEXT_SUB);

        titleStack.add(lblJudul);
        titleStack.add(lblRingkasan);

        JButton btnRefresh = buatTombol("↻ Refresh", TEAL, Color.WHITE);
        btnRefresh.addActionListener(e -> muatData());

        topBar.add(titleStack,  BorderLayout.WEST);
        topBar.add(btnRefresh,  BorderLayout.EAST);

        // ── Status badges row ─────────────────────────────────────
        JPanel badgesRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 0));
        badgesRow.setBackground(BG);
        badgesRow.setBorder(new EmptyBorder(14, 20, 6, 20));

        badgesRow.add(buatBadge("● Pending",   new Color(255, 243, 224), ORANGE));
        badgesRow.add(buatBadge("● Disetujui", new Color(232, 245, 233), GREEN));
        badgesRow.add(buatBadge("● Ditolak",   new Color(255, 235, 238), RED));

        // ── Table card ────────────────────────────────────────────
        JPanel cardWrap = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(0,0,0,8));
                g2.fillRoundRect(3, 4, getWidth()-4, getHeight()-4, 16, 16);
                g2.setColor(CARD_BG);
                g2.fillRoundRect(0, 0, getWidth()-2, getHeight()-2, 16, 16);
                g2.dispose();
            }
        };
        cardWrap.setOpaque(false);
        cardWrap.setBorder(new EmptyBorder(0, 0, 0, 0));

        String[] kolom = {"#", "Kode Barang", "Nama Barang", "Jumlah", "Status", "Tgl Pinjam", "Tgl Kembali", "Sisa Hari"};
        modelTabel = new DefaultTableModel(kolom, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };

        JTable tabel = new JTable(modelTabel);
        tabel.setRowHeight(38);
        tabel.setFont(new Font("SansSerif", Font.PLAIN, 13));
        tabel.setShowGrid(false);
        tabel.setIntercellSpacing(new Dimension(0, 0));
        tabel.setSelectionBackground(new Color(0, 168, 190, 35));
        tabel.setBackground(CARD_BG);

        // Header styling
        JTableHeader th = tabel.getTableHeader();
        th.setFont(new Font("SansSerif", Font.BOLD, 12));
        th.setBackground(new Color(246, 249, 253));
        th.setForeground(TEXT_SUB);
        th.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(228, 232, 245)));

        // Column widths
        tabel.getColumnModel().getColumn(0).setMaxWidth(45);
        tabel.getColumnModel().getColumn(3).setMaxWidth(70);
        tabel.getColumnModel().getColumn(5).setMaxWidth(100);
        tabel.getColumnModel().getColumn(6).setMaxWidth(100);
        tabel.getColumnModel().getColumn(7).setMaxWidth(80);

        // Base renderer (alternating)
        tabel.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(JTable t, Object v,
                    boolean sel, boolean foc, int row, int col) {
                super.getTableCellRendererComponent(t, v, sel, foc, row, col);
                setFont(new Font("SansSerif", Font.PLAIN, 13));
                setBorder(new EmptyBorder(4, 14, 4, 14));
                setForeground(TEXT_MAIN);
                if (sel) setBackground(new Color(0, 168, 190, 35));
                else     setBackground(row % 2 == 0 ? CARD_BG : new Color(248, 250, 254));
                return this;
            }
        });

        // Sisa hari column - with warning colors
        tabel.getColumnModel().getColumn(7).setCellRenderer(new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable t, Object v,
                    boolean sel, boolean foc, int row, int col) {
                super.getTableCellRendererComponent(t, v, sel, foc, row, col);
                if (v != null && v instanceof Integer) {
                    int sisaHari = (Integer) v;
                    setText(sisaHari + " hari");
                    setHorizontalAlignment(CENTER);
                    setFont(new Font("SansSerif", Font.BOLD, 12));
                    if (sisaHari < 0) {
                        setForeground(Color.WHITE);
                        setBackground(RED);
                    } else if (sisaHari <= 3) {
                        setForeground(new Color(255, 152, 0));
                        setBackground(new Color(255, 243, 224));
                    } else {
                        setForeground(TEXT_MAIN);
                        setBackground(sel ? new Color(0,168,190,35) : (row % 2 == 0 ? CARD_BG : new Color(248,250,254)));
                    }
                }
                return this;
            }
        });

        // Status column — colored pill
        tabel.getColumnModel().getColumn(4).setCellRenderer(new TableCellRenderer() {
            public Component getTableCellRendererComponent(JTable t, Object v,
                    boolean sel, boolean foc, int row, int col) {
                String status = v == null ? "" : v.toString();
                JPanel pill = new JPanel(new GridBagLayout()) {
                    @Override protected void paintComponent(Graphics g) {
                        Graphics2D g2 = (Graphics2D) g.create();
                        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                        Color bg2;
                        switch (status) {
                            case "pending":
                                bg2 = new Color(255, 243, 224);
                                break;
                            case "disetujui":
                                bg2 = new Color(232, 245, 233);
                                break;
                            case "ditolak":
                                bg2 = new Color(255, 235, 238);
                                break;
                            default:
                                bg2 = new Color(245, 246, 250);
                                break;
                        }
                        Color fg2;
                        switch (status) {
                            case "pending":
                                fg2 = ORANGE;
                                break;
                            case "disetujui":
                                fg2 = GREEN;
                                break;
                            case "ditolak":
                                fg2 = RED;
                                break;
                            default:
                                fg2 = TEXT_SUB;
                                break;
                        }
                        setBackground(sel ? new Color(0,168,190,35) : (row % 2 == 0 ? CARD_BG : new Color(248,250,254)));
                        super.paintComponent(g);
                        int pw = 90, ph = 22;
                        int px = (getWidth()-pw)/2, py = (getHeight()-ph)/2;
                        g2.setColor(bg2);
                        g2.fillRoundRect(px, py, pw, ph, 12, 12);
                        g2.setColor(fg2);
                        g2.setFont(new Font("SansSerif", Font.BOLD, 11));
                        FontMetrics fm = g2.getFontMetrics();
                        g2.drawString(status.toUpperCase(), px + (pw-fm.stringWidth(status.toUpperCase()))/2, py + ph/2 + fm.getAscent()/2 - 1);
                        g2.dispose();
                    }
                };
                pill.setPreferredSize(new Dimension(100, 38));
                return pill;
            }
        });

        JScrollPane scroll = new JScrollPane(tabel);
        scroll.setBorder(null);
        scroll.getViewport().setBackground(CARD_BG);
        cardWrap.add(scroll, BorderLayout.CENTER);

        // ── Empty state ───────────────────────────────────────────
        // Handled by table being empty

        // ── Layout ───────────────────────────────────────────────
        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.setBackground(BG);
        centerPanel.setBorder(new EmptyBorder(0, 20, 20, 20));
        centerPanel.add(badgesRow, BorderLayout.NORTH);
        centerPanel.add(cardWrap,  BorderLayout.CENTER);

        add(topBar,      BorderLayout.NORTH);
        add(centerPanel, BorderLayout.CENTER);
    }

    private void muatData() {
        try {
            modelTabel.setRowCount(0);
            List<Peminjaman> list = ctrl.getByUser(username);
            int pending = 0, disetujui = 0, ditolak = 0;
            for (Peminjaman p : list) {
                // Hitung sisa hari
                int sisaHari = 0;
                if (p.getTanggalKembali() != null) {
                    sisaHari = (int) java.time.temporal.ChronoUnit.DAYS.between(java.time.LocalDate.now(), p.getTanggalKembali());
                }
                modelTabel.addRow(new Object[]{
                    p.getId(), p.getKodeBarang(), p.getNamaBarang(),
                    p.getJumlah(), p.getStatus(), p.getTanggalPinjam(), p.getTanggalKembali(), sisaHari
                });
                switch (p.getStatus()) {
                    case "pending":
                        pending++;
                        break;
                    case "disetujui":
                        disetujui++;
                        break;
                    case "ditolak":
                        ditolak++;
                        break;
                }
            }
            lblRingkasan.setText(String.format(
                "Total %d permintaan  |  %d pending  |  %d disetujui  |  %d ditolak",
                list.size(), pending, disetujui, ditolak));
        } catch (SQLException e) {
            lblRingkasan.setText("Gagal memuat data: " + e.getMessage());
        }
    }

    // ── Helpers ───────────────────────────────────────────────────

    private JButton buatTombol(String teks, Color bg, Color fg) {
        JButton btn = new JButton(teks) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isRollover() ? bg.darker() : bg);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setForeground(fg);
        btn.setFont(new Font("SansSerif", Font.BOLD, 12));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(120, 36));
        return btn;
    }

    private JPanel buatBadge(String teks, Color bg, Color fg) {
        JPanel badge = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4)) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(bg);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        badge.setOpaque(false);
        JLabel lbl = new JLabel(teks);
        lbl.setFont(new Font("SansSerif", Font.BOLD, 11));
        lbl.setForeground(fg);
        badge.add(lbl);
        return badge;
    }
}
