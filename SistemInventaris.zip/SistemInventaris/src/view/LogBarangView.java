package view;

import controller.LogBarangController;
import model.LogBarang;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.*;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

/**
 * LogBarangView — Riwayat pergerakan barang masuk / keluar.
 * Filter: Semua | MASUK | KELUAR.
 */
public class LogBarangView extends JFrame {

    private static final Color BG        = new Color(240, 244, 252);
    private static final Color CARD_BG   = Color.WHITE;
    private static final Color TEAL      = new Color(0, 168, 190);
    private static final Color TEXT_MAIN = new Color(28, 32, 50);
    private static final Color TEXT_SUB  = new Color(120, 130, 155);
    private static final Color GREEN     = new Color(56, 176, 80);
    private static final Color RED       = new Color(244, 67, 54);
    private static final Color BLUE      = new Color(33, 150, 243);

    private final LogBarangController ctrl = new LogBarangController();
    private DefaultTableModel modelTabel;
    private JLabel lblStatus;

    public LogBarangView() {
        setTitle("Riwayat Barang Masuk / Keluar");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setMinimumSize(new Dimension(900, 540));
        buatUI();
        muatData();
        pack();
        setLocationRelativeTo(null);
    }

    private void buatUI() {
        setLayout(new BorderLayout());
        getContentPane().setBackground(BG);

        // ── Header ──────────────────────────────────────────────
        JPanel header = new JPanel(new BorderLayout(12, 0));
        header.setBackground(CARD_BG);
        header.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(225, 230, 240)),
            new EmptyBorder(16, 24, 16, 24)
        ));
        JPanel titleStack = new JPanel();
        titleStack.setOpaque(false);
        titleStack.setLayout(new BoxLayout(titleStack, BoxLayout.Y_AXIS));
        JLabel lblJudul = new JLabel("Riwayat Barang Masuk / Keluar");
        lblJudul.setFont(new Font("SansSerif", Font.BOLD, 18));
        lblJudul.setForeground(TEXT_MAIN);
        JLabel lblSub = new JLabel("Tracking seluruh pergerakan stok inventaris");
        lblSub.setFont(new Font("SansSerif", Font.PLAIN, 12));
        lblSub.setForeground(TEXT_SUB);
        titleStack.add(lblJudul);
        titleStack.add(lblSub);

        JButton btnRefresh = buatTombol("↻ Refresh", TEAL, Color.WHITE);
        btnRefresh.addActionListener(e -> muatData());
        header.add(titleStack, BorderLayout.WEST);
        header.add(btnRefresh, BorderLayout.EAST);

        // ── Filter Row ──────────────────────────────────────────
        JPanel filterRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        filterRow.setOpaque(false);
        filterRow.setBorder(new EmptyBorder(14, 4, 6, 4));

        JButton btnSemua  = buatTombol("Semua",  BLUE,  Color.WHITE);
        JButton btnMasuk  = buatTombol("MASUK",  GREEN, Color.WHITE);
        JButton btnKeluar = buatTombol("KELUAR", RED,   Color.WHITE);
        btnSemua.addActionListener (e -> muatData());
        btnMasuk.addActionListener (e -> muatByTipe("MASUK"));
        btnKeluar.addActionListener(e -> muatByTipe("KELUAR"));
        filterRow.add(btnSemua);
        filterRow.add(btnMasuk);
        filterRow.add(btnKeluar);

        // ── Table card ──────────────────────────────────────────
        JPanel card = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(0,0,0,8));
                g2.fillRoundRect(3,4,getWidth()-4,getHeight()-4,16,16);
                g2.setColor(CARD_BG);
                g2.fillRoundRect(0,0,getWidth()-2,getHeight()-2,16,16);
                g2.dispose();
            }
        };
        card.setOpaque(false);

        String[] kolom = {"ID","Kode","Nama Barang","Tipe","Jml","Keterangan","Operator","Tanggal"};
        modelTabel = new DefaultTableModel(kolom, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };

        JTable tabel = new JTable(modelTabel);
        tabel.setRowHeight(34);
        tabel.setFont(new Font("SansSerif", Font.PLAIN, 13));
        tabel.setShowGrid(false);
        tabel.setIntercellSpacing(new Dimension(0, 0));
        tabel.setSelectionBackground(new Color(0, 168, 190, 35));
        tabel.setBackground(CARD_BG);

        JTableHeader th = tabel.getTableHeader();
        th.setFont(new Font("SansSerif", Font.BOLD, 12));
        th.setBackground(new Color(246,249,253));
        th.setForeground(TEXT_SUB);
        th.setBorder(BorderFactory.createMatteBorder(0,0,1,0,new Color(228,232,245)));

        // Base renderer
        tabel.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable t, Object v,
                    boolean sel, boolean foc, int row, int col) {
                super.getTableCellRendererComponent(t,v,sel,foc,row,col);
                setFont(new Font("SansSerif", Font.PLAIN, 13));
                setBorder(new EmptyBorder(4,12,4,12));
                setForeground(TEXT_MAIN);
                if (sel) setBackground(new Color(0,168,190,35));
                else     setBackground(row%2==0 ? CARD_BG : new Color(248,250,254));
                return this;
            }
        });

        // Tipe renderer — colored pill
        tabel.getColumnModel().getColumn(3).setCellRenderer(new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable t, Object v,
                    boolean sel, boolean foc, int row, int col) {
                super.getTableCellRendererComponent(t,v,sel,foc,row,col);
                setFont(new Font("SansSerif", Font.BOLD, 11));
                setHorizontalAlignment(CENTER);
                setOpaque(true);
                setBorder(new EmptyBorder(4,8,4,8));
                String s = v==null ? "" : v.toString();
                if      ("MASUK" .equals(s)) { setForeground(GREEN); setBackground(new Color(232,245,233)); }
                else if ("KELUAR".equals(s)) { setForeground(RED);   setBackground(new Color(255,235,238)); }
                else                         { setForeground(TEXT_SUB); setBackground(sel?new Color(0,168,190,35):CARD_BG); }
                return this;
            }
        });

        tabel.getColumnModel().getColumn(0).setMaxWidth(45);
        tabel.getColumnModel().getColumn(3).setMaxWidth(75);
        tabel.getColumnModel().getColumn(4).setMaxWidth(55);

        JScrollPane scroll = new JScrollPane(tabel);
        scroll.setBorder(null);
        scroll.getViewport().setBackground(CARD_BG);
        scroll.setPreferredSize(new Dimension(860, 360));
        card.add(scroll, BorderLayout.CENTER);

        // ── Status ──────────────────────────────────────────────
        lblStatus = new JLabel("Memuat data...");
        lblStatus.setFont(new Font("SansSerif", Font.PLAIN, 11));
        lblStatus.setForeground(TEXT_SUB);
        lblStatus.setBorder(new EmptyBorder(8,4,0,0));

        // ── Center wrapper ───────────────────────────────────────
        JPanel center = new JPanel(new BorderLayout(0,10));
        center.setBackground(BG);
        center.setBorder(new EmptyBorder(4, 20, 16, 20));
        center.add(filterRow, BorderLayout.NORTH);
        center.add(card,      BorderLayout.CENTER);
        center.add(lblStatus, BorderLayout.SOUTH);

        add(header, BorderLayout.NORTH);
        add(center, BorderLayout.CENTER);
    }

    // ── Data ──────────────────────────────────────────────────────

    private void muatData() {
        try {
            List<LogBarang> list = ctrl.getAll();
            tampilkanList(list, "Semua");
        } catch (SQLException e) {
            lblStatus.setText("Error: " + e.getMessage());
        }
    }

    private void muatByTipe(String tipe) {
        try {
            List<LogBarang> list = ctrl.getByTipeAksi(tipe);
            tampilkanList(list, tipe);
        } catch (SQLException e) {
            lblStatus.setText("Error: " + e.getMessage());
        }
    }

    private void tampilkanList(List<LogBarang> list, String filter) {
        modelTabel.setRowCount(0);
        for (LogBarang log : list) {
            modelTabel.addRow(new Object[]{
                log.getId(), log.getKodeBarang(), log.getNamaBarang(),
                log.getTipeAksi(), log.getJumlah(), log.getKeterangan(),
                log.getUsername(), log.getTanggalFormatted()
            });
        }
        lblStatus.setText("Filter: " + filter + "  —  " + list.size() + " baris.");
    }

    // ── Helpers ──────────────────────────────────────────────────

    private JButton buatTombol(String teks, Color bg, Color fg) {
        JButton btn = new JButton(teks) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isRollover() ? bg.darker() : bg);
                g2.fillRoundRect(0,0,getWidth(),getHeight(),10,10);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setForeground(fg);
        btn.setFont(new Font("SansSerif", Font.BOLD, 12));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(110, 34));
        return btn;
    }
}
