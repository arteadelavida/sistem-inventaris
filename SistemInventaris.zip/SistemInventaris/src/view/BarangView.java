package view;

import component.*;
import controller.BarangController;
import controller.PeminjamanController;
import java.awt.*;
import java.awt.event.*;
import java.sql.SQLException;
import java.time.*;
import java.util.List;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.*;
import model.Barang;
import model.Peminjaman;
import util.SessionManager;

/**
 * BarangView — Dashboard utama Sistem Inventaris.
 *
 * ADMIN  : CRUD barang + kelola akun + terima peminjaman
 * USER   : Lihat barang + ajukan peminjaman + lihat riwayat pinjam
 */
public class BarangView extends JFrame {

    // ── Palet warna ───────────────────────────────────────────────
    private static final Color SIDEBAR_BG    = new Color(15, 32, 68);
    private static final Color SIDEBAR_HOVER = new Color(0, 60, 90);
    private static final Color SIDEBAR_ACTIVE = new Color(0, 168, 190);
    private static final Color MAIN_BG       = new Color(240, 244, 252);
    private static final Color CARD_BG       = Color.WHITE;
    private static final Color TEAL          = new Color(0, 168, 190);
    private static final Color TEAL_DARK     = new Color(0, 105, 140);
    private static final Color TEXT_MAIN     = new Color(28, 32, 50);
    private static final Color TEXT_SUB      = new Color(120, 130, 155);
    private static final Color GREEN         = new Color(56, 176, 80);
    private static final Color ORANGE        = new Color(255, 152, 0);
    private static final Color RED           = new Color(244, 67, 54);
    private static final Color PURPLE        = new Color(103, 58, 183);

    // ── Controllers ───────────────────────────────────────────────
    private final BarangController      ctrlBarang     = new BarangController();
    private final PeminjamanController  ctrlPeminjaman = new PeminjamanController();

    // ── Tabel ─────────────────────────────────────────────────────
    private JTable            tabelBarang;
    private DefaultTableModel modelTabel;

    // ── Form fields (admin only) ───────────────────────────────────
    private JTextField txtKode, txtNama, txtHarga, txtStok;
    private JTextArea  txtKeterangan;

    // ── Tombol ────────────────────────────────────────────────────
    private JButton btnTambah, btnSimpan, btnHapus, btnBersihkan;
    private JButton btnPinjam; // user

    // ── Stat cards (keep references so values can be updated) ─────
    private StatisticCard statCard1, statCard2, statCard3, statCard4;
    private JLabel lblStatus;

    // ── Pinjam form fields (user) ─────────────────────────────────
    private JTextField txtJumlahPinjam;

    public BarangView() {
        setTitle("Sistem Inventaris – Dashboard");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(1150, 700));
        buatUI();
        muatDataTabel();
        pack();
        setLocationRelativeTo(null);
    }

    // ═════════════════════════════════════════════════════════════
    // BUILD UI
    // ═════════════════════════════════════════════════════════════

    private void buatUI() {
        setLayout(new BorderLayout());
        getContentPane().setBackground(MAIN_BG);
        add(buatSidebar(),    BorderLayout.WEST);
        add(buatMainPanel(),  BorderLayout.CENTER);
        add(buatRightPanel(), BorderLayout.EAST);
    }

    // ═══════════════════════════════════════════
    // SIDEBAR
    // ═══════════════════════════════════════════

    private JPanel buatSidebar() {
        JPanel sidebar = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setPaint(new GradientPaint(0, 0, SIDEBAR_BG, 0, getHeight(), new Color(0, 20, 50)));
                g2.fillRect(0, 0, getWidth(), getHeight());
                // subtle right border
                g2.setColor(new Color(255,255,255,12));
                g2.fillRect(getWidth()-1, 0, 1, getHeight());
            }
        };
        sidebar.setOpaque(false);
        sidebar.setPreferredSize(new Dimension(210, 0));
        sidebar.setLayout(new BorderLayout());

        // ── Logo ──
        JPanel logoPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 16, 20));
        logoPanel.setOpaque(false);
        JPanel logoIcon = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setPaint(new GradientPaint(0, 0, TEAL, getWidth(), getHeight(), TEAL_DARK));
                g2.fillRoundRect(0, 0, 34, 34, 10, 10);
                g2.setColor(Color.WHITE);
                g2.setFont(new Font("SansSerif", Font.BOLD, 16));
                g2.drawString("SI", 6, 23);
                g2.dispose();
            }
            public Dimension getPreferredSize() { return new Dimension(34, 34); }
        };
        logoIcon.setOpaque(false);
        JLabel lblLogoText = new JLabel("Inventaris");
        lblLogoText.setFont(new Font("SansSerif", Font.BOLD, 15));
        lblLogoText.setForeground(Color.WHITE);
        logoPanel.add(logoIcon);
        logoPanel.add(lblLogoText);

        // Separator under logo
        JPanel logoBorder = new JPanel(new BorderLayout());
        logoBorder.setOpaque(false);
        logoBorder.add(logoPanel, BorderLayout.CENTER);
        JSeparator sepLogo = new JSeparator();
        sepLogo.setForeground(new Color(255,255,255,18));
        logoBorder.add(sepLogo, BorderLayout.SOUTH);

        // ── Navigation ──
        JPanel navPanel = new JPanel();
        navPanel.setOpaque(false);
        navPanel.setLayout(new BoxLayout(navPanel, BoxLayout.Y_AXIS));
        navPanel.setBorder(new EmptyBorder(16, 0, 0, 0));

        JLabel lblSection = navLabelSection("MENU UTAMA");
        navPanel.add(lblSection);
        navPanel.add(Box.createVerticalStrut(6));

        if (SessionManager.isAdmin()) {
            JPanel navDashboard = buatNavItem("⊞", "Dashboard", true);
            navDashboard.addMouseListener(new MouseAdapter() {
                public void mouseClicked(MouseEvent e) { bukaDashboard(); }
            });
            navPanel.add(navDashboard);
            navPanel.add(buatNavItem("≡", "Data Barang",   false));
            navPanel.add(navLabelSection("MANAJEMEN"));
            navPanel.add(Box.createVerticalStrut(6));
            JPanel navUser = buatNavItem("◉", "Kelola Akun",  false);
            navUser.addMouseListener(new MouseAdapter() {
                public void mouseClicked(MouseEvent e) { bukaUserManagement(); }
            });
            navPanel.add(navUser);
            JPanel navPinjam = buatNavItem("↗", "Peminjaman",   false);
            navPinjam.addMouseListener(new MouseAdapter() {
                public void mouseClicked(MouseEvent e) { bukaPeminjaman(); }
            });
            navPanel.add(navPinjam);
            JPanel navLogBarang = buatNavItem("📊", "Riwayat Barang", false);
            navLogBarang.addMouseListener(new MouseAdapter() {
                public void mouseClicked(MouseEvent e) { bukaLogBarang(); }
            });
            navPanel.add(navLogBarang);
            
            // ── NEW: Approval Section ──
            navPanel.add(navLabelSection("PERSETUJUAN"));
            navPanel.add(Box.createVerticalStrut(6));
            JPanel navPasswordReset = buatNavItem("🔑", "Reset Password", false);
            navPasswordReset.addMouseListener(new MouseAdapter() {
                public void mouseClicked(MouseEvent e) { bukaPasswordResetApproval(); }
            });
            navPanel.add(navPasswordReset);
            JPanel navReturnApproval = buatNavItem("📥", "Pengembalian Barang", false);
            navReturnApproval.addMouseListener(new MouseAdapter() {
                public void mouseClicked(MouseEvent e) { bukaReturnItemApproval(); }
            });
            navPanel.add(navReturnApproval);
        } else {
            JPanel navDashboardUser = buatNavItem("⊞", "Dashboard", true);
            navDashboardUser.addMouseListener(new MouseAdapter() {
                public void mouseClicked(MouseEvent e) { bukaDashboard(); }
            });
            navPanel.add(navDashboardUser);
            navPanel.add(buatNavItem("≡", "Lihat Barang",  false));
            navPanel.add(navLabelSection("PEMINJAMAN"));
            navPanel.add(Box.createVerticalStrut(6));
            JPanel navRiwayat = buatNavItem("↺", "Riwayat Pinjam", false);
            navRiwayat.addMouseListener(new MouseAdapter() {
                public void mouseClicked(MouseEvent e) { bukaRiwayatPinjam(); }
            });
            navPanel.add(navRiwayat);
            
            // ── NEW: Return Item untuk user ──
            JPanel navReturnItem = buatNavItem("📤", "Kembalikan Barang", false);
            navReturnItem.addMouseListener(new MouseAdapter() {
                public void mouseClicked(MouseEvent e) { bukaUserReturnItem(); }
            });
            navPanel.add(navReturnItem);
        }

        // ── Bottom user card ──
        JPanel bottomCard = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(255,255,255,12));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);
                g2.dispose();
            }
        };
        bottomCard.setOpaque(false);
        bottomCard.setLayout(new BorderLayout(0, 8));
        bottomCard.setBorder(new EmptyBorder(12, 14, 12, 14));

        // Avatar
        String initial = SessionManager.getUsername() != null && !SessionManager.getUsername().isEmpty()
            ? String.valueOf(SessionManager.getUsername().charAt(0)).toUpperCase() : "U";
        JPanel avatar = buatAvatar(initial, 36, TEAL);

        JPanel nameStack = new JPanel();
        nameStack.setOpaque(false);
        nameStack.setLayout(new BoxLayout(nameStack, BoxLayout.Y_AXIS));
        JLabel lblUname = new JLabel(SessionManager.getUsername() != null ? SessionManager.getUsername() : "User");
        lblUname.setFont(new Font("SansSerif", Font.BOLD, 13));
        lblUname.setForeground(Color.WHITE);
        JLabel lblRole = new JLabel(SessionManager.isAdmin() ? "Administrator" : "Pengguna");
        lblRole.setFont(new Font("SansSerif", Font.PLAIN, 11));
        lblRole.setForeground(new Color(0, 200, 220));
        nameStack.add(lblUname);
        nameStack.add(lblRole);

        JPanel userRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        userRow.setOpaque(false);
        userRow.add(avatar);
        userRow.add(nameStack);

        JButton btnLogout = new JButton("⏻  Keluar") {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isRollover() ? RED.darker() : new Color(200, 30, 50));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        btnLogout.setContentAreaFilled(false);
        btnLogout.setBorderPainted(false);
        btnLogout.setFocusPainted(false);
        btnLogout.setForeground(Color.WHITE);
        btnLogout.setFont(new Font("SansSerif", Font.BOLD, 12));
        btnLogout.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnLogout.setPreferredSize(new Dimension(170, 34));
        btnLogout.addActionListener(e -> prosesLogout());

        JPanel logoutWrap = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
        logoutWrap.setOpaque(false);
        logoutWrap.add(btnLogout);

        bottomCard.add(userRow,    BorderLayout.CENTER);
        bottomCard.add(logoutWrap, BorderLayout.SOUTH);

        JPanel bottomWrap = new JPanel(new BorderLayout());
        bottomWrap.setOpaque(false);
        bottomWrap.setBorder(new EmptyBorder(0, 10, 16, 10));
        bottomWrap.add(bottomCard, BorderLayout.CENTER);

        sidebar.add(logoBorder,  BorderLayout.NORTH);
        sidebar.add(navPanel,    BorderLayout.CENTER);
        sidebar.add(bottomWrap,  BorderLayout.SOUTH);
        return sidebar;
    }

    private JPanel buatNavItem(String icon, String label, boolean active) {
        JPanel item = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 0)) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (active) {
                    g2.setColor(new Color(0, 168, 190, 35));
                    g2.fillRoundRect(6, 2, getWidth()-12, getHeight()-4, 10, 10);
                    g2.setColor(TEAL);
                    g2.fillRoundRect(1, 8, 4, getHeight()-16, 4, 4);
                } else if (getModel().isArmed()) {
                    g2.setColor(new Color(255,255,255,10));
                    g2.fillRoundRect(6, 2, getWidth()-12, getHeight()-4, 10, 10);
                }
                g2.dispose();
                super.paintComponent(g);
            }
            ButtonModel getModel() { return new DefaultButtonModel(); }
        };
        item.setOpaque(false);
        item.setPreferredSize(new Dimension(210, 40));
        item.setMaximumSize(new Dimension(210, 40));
        item.setBorder(new EmptyBorder(0, 14, 0, 0));
        item.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        JLabel lblIcon = new JLabel(icon);
        lblIcon.setFont(new Font("SansSerif", Font.PLAIN, 15));
        lblIcon.setForeground(active ? TEAL : new Color(160, 175, 200));

        JLabel lblText = new JLabel(label);
        lblText.setFont(new Font("SansSerif", active ? Font.BOLD : Font.PLAIN, 13));
        lblText.setForeground(active ? Color.WHITE : new Color(160, 175, 200));

        // hover effect
        MouseAdapter hov = new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                if (!active) { lblText.setForeground(Color.WHITE); lblIcon.setForeground(new Color(0,200,220)); }
            }
            public void mouseExited(MouseEvent e) {
                if (!active) { lblText.setForeground(new Color(160,175,200)); lblIcon.setForeground(new Color(160,175,200)); }
            }
        };
        item.addMouseListener(hov);

        item.add(lblIcon);
        item.add(lblText);
        return item;
    }

    private JLabel navLabelSection(String teks) {
        JLabel lbl = new JLabel(teks);
        lbl.setFont(new Font("SansSerif", Font.BOLD, 10));
        lbl.setForeground(new Color(100, 120, 160));
        lbl.setBorder(new EmptyBorder(14, 18, 4, 0));
        return lbl;
    }

    // ═══════════════════════════════════════════
    // MAIN PANEL
    // ═══════════════════════════════════════════

    private JPanel buatMainPanel() {
        JPanel main = new JPanel(new BorderLayout(0, 0));
        main.setBackground(MAIN_BG);
        main.add(buatTopBar(),     BorderLayout.NORTH);
        main.add(buatContentArea(), BorderLayout.CENTER);
        return main;
    }

    private JPanel buatTopBar() {
        JPanel bar = new JPanel(new BorderLayout(12, 0));
        bar.setBackground(Color.WHITE);
        bar.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(225, 230, 240)),
            new EmptyBorder(14, 24, 14, 24)
        ));

        // Greeting
        JPanel greetStack = new JPanel();
        greetStack.setOpaque(false);
        greetStack.setLayout(new BoxLayout(greetStack, BoxLayout.Y_AXIS));

        String roleLabel = SessionManager.isAdmin() ? "Administrator" : "Pengguna";
        JLabel lblGreet = new JLabel("Halo, " + SessionManager.getUsername() + " 👋");
        lblGreet.setFont(new Font("SansSerif", Font.BOLD, 18));
        lblGreet.setForeground(TEXT_MAIN);

        JLabel lblSub = new JLabel("Anda masuk sebagai " + roleLabel + " — " +
            (SessionManager.isAdmin() ? "Kelola inventaris dengan mudah!" : "Lihat dan pinjam barang tersedia."));
        lblSub.setFont(new Font("SansSerif", Font.PLAIN, 12));
        lblSub.setForeground(TEXT_SUB);

        greetStack.add(lblGreet);
        greetStack.add(lblSub);

        // Right: search + avatar
        JPanel rightBar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 0));
        rightBar.setOpaque(false);

        JTextField searchBox = new JTextField("  ⌕  Cari barang...");
        searchBox.setFont(new Font("SansSerif", Font.PLAIN, 12));
        searchBox.setForeground(new Color(160, 165, 185));
        searchBox.setPreferredSize(new Dimension(200, 34));
        searchBox.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(218, 225, 238), 1, true),
            new EmptyBorder(4, 6, 4, 6)
        ));
        searchBox.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                if (searchBox.getText().contains("Cari barang...")) { searchBox.setText(""); searchBox.setForeground(TEXT_MAIN); }
            }
            public void focusLost(FocusEvent e) {
                if (searchBox.getText().trim().isEmpty()) { searchBox.setText("  ⌕  Cari barang..."); searchBox.setForeground(new Color(160,165,185)); }
            }
        });

        // ── Filter tabel real-time ──
        searchBox.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) {
                String keyword = searchBox.getText().trim().toLowerCase();
                // Abaikan placeholder
                if (keyword.contains("cari barang...") || keyword.isEmpty()) {
                    muatDataTabel(); // tampilkan semua
                    return;
                }
                // Filter baris berdasarkan kode atau nama barang
                modelTabel.setRowCount(0);
                try {
                    for (model.Barang b : ctrlBarang.getAllBarang()) {
                        boolean cocok =
                            b.getKodeBarang().toLowerCase().contains(keyword) ||
                            b.getNamaBarang().toLowerCase().contains(keyword) ||
                            b.getKeterangan().toLowerCase().contains(keyword);
                        if (cocok) {
                            modelTabel.addRow(new Object[]{
                                b.getKodeBarang(), b.getNamaBarang(),
                                String.format("%,d", b.getHarga()),
                                b.getStok(), b.getKeterangan()
                            });
                        }
                    }
                    setStatus("Ditemukan " + modelTabel.getRowCount() + " barang untuk \"" + keyword + "\".");
                } catch (java.sql.SQLException ex) {
                    setStatus("Error saat mencari: " + ex.getMessage());
                }
            }
        });

        String init2 = SessionManager.getUsername() != null && !SessionManager.getUsername().isEmpty()
            ? String.valueOf(SessionManager.getUsername().charAt(0)).toUpperCase() : "U";
        JPanel avatarTop = buatAvatar(init2, 34, TEAL);

        rightBar.add(searchBox);
        rightBar.add(avatarTop);

        bar.add(greetStack, BorderLayout.WEST);
        bar.add(rightBar,   BorderLayout.EAST);
        return bar;
    }

    private JPanel buatContentArea() {
        JPanel outer = new JPanel(new BorderLayout());
        outer.setBackground(MAIN_BG);
        outer.setBorder(new EmptyBorder(22, 22, 12, 12));

        JPanel content = new JPanel();
        content.setOpaque(false);
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));

        content.add(buatStatsRow());
        content.add(Box.createVerticalStrut(22));
        content.add(buatTabelPanel());

        lblStatus = new JLabel("Siap.");
        lblStatus.setFont(new Font("SansSerif", Font.PLAIN, 11));
        lblStatus.setForeground(TEXT_SUB);
        lblStatus.setBorder(new EmptyBorder(8, 0, 0, 0));
        content.add(lblStatus);

        outer.add(content, BorderLayout.CENTER);
        return outer;
    }

    // ═══════════════════════════════════════════
    // STAT CARDS
    // ═══════════════════════════════════════════

    private JPanel buatStatsRow() {
        JPanel row = new JPanel(new GridLayout(1, 4, 16, 0));
        row.setOpaque(false);
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 140));

        if (SessionManager.isAdmin()) {
            statCard1 = new StatisticCard("⊞", "Total Barang",  "0",    "Jenis item inventaris",     TEAL);
            statCard2 = new StatisticCard("≡", "Total Stok",    "0",    "Unit tersedia",              GREEN);
            statCard3 = new StatisticCard("₹", "Total Nilai",   "Rp 0", "Estimasi nilai",             ORANGE);
            statCard4 = new StatisticCard("↗", "Req. Pinjam",   "0",    "Menunggu persetujuan",       PURPLE);
        } else {
            statCard1 = new StatisticCard("⊞", "Barang Tersedia", "0",     "Jenis item",              TEAL);
            statCard2 = new StatisticCard("≡", "Total Stok",      "0",     "Unit tersedia",            GREEN);
            statCard3 = new StatisticCard("↗", "Pinjaman Saya",   "0",     "Permintaan diajukan",      ORANGE);
            statCard4 = new StatisticCard("◉", "Status Akun",     "Aktif", "Akun terverifikasi",       PURPLE);
        }

        row.add(statCard1);
        row.add(statCard2);
        row.add(statCard3);
        row.add(statCard4);
        return row;
    }

    private void updateStatsDisplay() {
        // Called from muatDataTabel — kept for compatibility
    }

    // ═══════════════════════════════════════════
    // TABEL
    // ═══════════════════════════════════════════

    private JPanel buatTabelPanel() {
        ModernCard card = new ModernCard(Color.WHITE);
        card.setLayout(new BorderLayout(0, 12));
        card.setBorder(new EmptyBorder(16, 18, 18, 18));

        // Section header
        JPanel secHeader = new JPanel(new BorderLayout());
        secHeader.setOpaque(false);
        JLabel lblSec = new JLabel("📊 Daftar Barang Inventaris");
        lblSec.setFont(new Font("SansSerif", Font.BOLD, 16));
        lblSec.setForeground(TEXT_MAIN);

        JButton btnRefresh = buatTombolIcon("↻ Refresh");
        btnRefresh.addActionListener(e -> muatDataTabel());
        secHeader.add(lblSec,     BorderLayout.WEST);
        secHeader.add(btnRefresh, BorderLayout.EAST);

        String[] kolom = {"Kode", "Nama Barang", "Harga (Rp)", "Stok", "Keterangan"};
        modelTabel = new DefaultTableModel(kolom, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };

        tabelBarang = new JTable(modelTabel);
        tabelBarang.setRowHeight(36);
        tabelBarang.setFont(new Font("SansSerif", Font.PLAIN, 13));
        tabelBarang.setShowGrid(false);
        tabelBarang.setIntercellSpacing(new Dimension(0, 0));
        tabelBarang.setSelectionBackground(new Color(0, 168, 190, 35));
        tabelBarang.setSelectionForeground(TEXT_MAIN);
        tabelBarang.setBackground(CARD_BG);

        JTableHeader header = tabelBarang.getTableHeader();
        header.setFont(new Font("SansSerif", Font.BOLD, 12));
        header.setBackground(new Color(246, 249, 253));
        header.setForeground(TEXT_SUB);
        header.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(228, 232, 245)));

        tabelBarang.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean foc, int row, int col) {
                super.getTableCellRendererComponent(t, v, sel, foc, row, col);
                setFont(new Font("SansSerif", Font.PLAIN, 13));
                setBorder(new EmptyBorder(4, 12, 4, 12));
                if (sel) setBackground(new Color(0, 168, 190, 35));
                else     setBackground(row % 2 == 0 ? CARD_BG : new Color(248, 250, 254));
                setForeground(TEXT_MAIN);
                // Stok rendah = merah
                if (col == 3 && v != null) {
                    try {
                        int stok = Integer.parseInt(v.toString());
                        if (stok == 0) setForeground(RED);
                        else if (stok <= 5) setForeground(ORANGE);
                    } catch (NumberFormatException ignored) {}
                }
                return this;
            }
        });

        tabelBarang.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) { isiFormDariTabel(); }
        });

        JScrollPane scroll = new JScrollPane(tabelBarang);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(228, 232, 245), 1, true));
        scroll.getViewport().setBackground(CARD_BG);
        scroll.setPreferredSize(new Dimension(0, 320));

        card.add(secHeader, BorderLayout.NORTH);
        card.add(scroll,    BorderLayout.CENTER);
        return card;
    }

    // ═══════════════════════════════════════════
    // RIGHT PANEL
    // ═══════════════════════════════════════════

    private JPanel buatRightPanel() {
        JPanel outer = new JPanel(new BorderLayout());
        outer.setPreferredSize(new Dimension(260, 0));
        outer.setBackground(MAIN_BG);
        outer.setBorder(new EmptyBorder(22, 8, 22, 20));

        if (SessionManager.isAdmin()) {
            outer.add(buatFormAdmin(), BorderLayout.CENTER);
        } else {
            outer.add(buatFormUser(), BorderLayout.CENTER);
        }
        return outer;
    }

    // ── RIGHT PANEL: ADMIN ────────────────────────────────────────

    private JPanel buatFormAdmin() {
        ModernCard card = new ModernCard(Color.WHITE);
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(new EmptyBorder(18, 18, 18, 18));

        JLabel lblJudul = new JLabel("⚙️  Kelola Barang");
        lblJudul.setFont(new Font("SansSerif", Font.BOLD, 16));
        lblJudul.setForeground(TEXT_MAIN);
        lblJudul.setAlignmentX(LEFT_ALIGNMENT);

        txtKode = buatInput(); txtNama = buatInput();
        txtHarga = buatInput(); txtStok = buatInput();
        txtKeterangan = new JTextArea(3, 1);
        txtKeterangan.setFont(new Font("SansSerif", Font.PLAIN, 12));
        txtKeterangan.setLineWrap(true);
        txtKeterangan.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(218, 225, 238), 1, true),
            new EmptyBorder(6, 10, 6, 10)
        ));
        JScrollPane scrollKet = new JScrollPane(txtKeterangan);
        scrollKet.setBorder(null);
        scrollKet.setAlignmentX(LEFT_ALIGNMENT);
        scrollKet.setMaximumSize(new Dimension(Integer.MAX_VALUE, 68));

        btnTambah    = buatTombolForm("+ Tambah Baru",  TEAL,   Color.WHITE);
        btnSimpan    = buatTombolForm("✎ Simpan Ubahan",GREEN,  Color.WHITE);
        btnHapus     = buatTombolForm("✕ Hapus Barang", RED,    Color.WHITE);
        btnBersihkan = buatTombolForm("↺ Bersihkan",    new Color(150,158,175), Color.WHITE);

        btnTambah.addActionListener(e -> prosesTambah());
        btnSimpan.addActionListener(e -> prosesSimpan());
        btnHapus.addActionListener(e -> prosesHapus());
        btnBersihkan.addActionListener(e -> bersihkanForm());

        // Admin extra buttons
        JButton btnKelolaAkun  = buatTombolForm("◉ Kelola Akun",     new Color(103,58,183), Color.WHITE);
        JButton btnPeminjaman  = buatTombolForm("↗ Permintaan Pinjam",ORANGE,               Color.WHITE);
        btnKelolaAkun.addActionListener(e -> bukaUserManagement());
        btnPeminjaman.addActionListener(e -> bukaPeminjaman());

        JSeparator sep = new JSeparator();
        sep.setForeground(new Color(228, 232, 245));
        sep.setAlignmentX(LEFT_ALIGNMENT);
        sep.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1));

        card.add(lblJudul);
        card.add(Box.createVerticalStrut(16));
        card.add(formRow("Kode Barang", txtKode));
        card.add(formRow("Nama Barang", txtNama));
        card.add(formRow("Harga (Rp)",  txtHarga));
        card.add(formRow("Stok",        txtStok));
        card.add(formRowArea("Keterangan", scrollKet));
        card.add(Box.createVerticalStrut(14));
        card.add(btnTambah);    card.add(Box.createVerticalStrut(6));
        card.add(btnSimpan);    card.add(Box.createVerticalStrut(6));
        card.add(btnHapus);     card.add(Box.createVerticalStrut(6));
        card.add(btnBersihkan);
        card.add(Box.createVerticalStrut(14));
        card.add(sep);
        card.add(Box.createVerticalStrut(12));
        card.add(btnKelolaAkun);  card.add(Box.createVerticalStrut(6));
        card.add(btnPeminjaman);

        aturStatusTombolAdmin(false);
        return card;
    }

    // ── RIGHT PANEL: USER ─────────────────────────────────────────

    private JPanel buatFormUser() {
        ModernCard card = new ModernCard(Color.WHITE);
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(new EmptyBorder(18, 18, 18, 18));

        JLabel lblJudul = new JLabel("📦 Pinjam Barang");
        lblJudul.setFont(new Font("SansSerif", Font.BOLD, 16));
        lblJudul.setForeground(TEXT_MAIN);
        lblJudul.setAlignmentX(LEFT_ALIGNMENT);

        JLabel lblInfo = new JLabel("<html><body style='color:#788096;font-size:11px'>" +
            "Pilih barang dari tabel, lalu isi<br>jumlah dan ajukan permintaan pinjam.</body></html>");
        lblInfo.setAlignmentX(LEFT_ALIGNMENT);

        // Read-only preview fields
        JTextField previewKode = buatInput(); previewKode.setEditable(false); previewKode.setBackground(new Color(246,248,252));
        JTextField previewNama = buatInput(); previewNama.setEditable(false); previewNama.setBackground(new Color(246,248,252));
        JTextField previewStok = buatInput(); previewStok.setEditable(false); previewStok.setBackground(new Color(246,248,252));

        txtJumlahPinjam = buatInput();

        btnPinjam = buatTombolForm("↗ Ajukan Peminjaman", TEAL, Color.WHITE);
        btnPinjam.setEnabled(false);
        btnPinjam.addActionListener(e -> {
            String kode = previewKode.getText().trim();
            String nama = previewNama.getText().trim();
            String jmlStr = txtJumlahPinjam.getText().trim();
            if (kode.isEmpty()) { showErr("Pilih barang dari tabel terlebih dahulu."); return; }
            if (jmlStr.isEmpty()) { showErr("Isi jumlah yang ingin dipinjam."); return; }
            int jml;
            try { jml = Integer.parseInt(jmlStr); } catch (NumberFormatException ex) { showErr("Jumlah harus angka."); return; }
            int stok;
            try { stok = Integer.parseInt(previewStok.getText().trim()); } catch (NumberFormatException ex) { stok = 0; }
            if (jml <= 0) { showErr("Jumlah harus lebih dari 0."); return; }
            if (jml > stok) { showErr("Jumlah melebihi stok tersedia (" + stok + ")."); return; }
            
            // Tanya user: berapa hari tenggat?
            String inputHari = JOptionPane.showInputDialog(BarangView.this, 
                "Berapa hari tenggat waktu peminjaman?\n(minimal 1 hari, default 7 hari)", "7");
            if (inputHari == null) return; // cancel
            
            int hariTenggat;
            try { 
                hariTenggat = Integer.parseInt(inputHari.trim()); 
                if (hariTenggat < 1) { showErr("Hari harus minimal 1."); return; }
            } catch (NumberFormatException ex) { 
                showErr("Hari harus berupa angka."); 
                return; 
            }
            
            try {
                Peminjaman p = new Peminjaman(SessionManager.getUsername(), kode, nama, jml, LocalDate.now().plusDays(hariTenggat));
                ctrlPeminjaman.ajukanPeminjaman(p);
                JOptionPane.showMessageDialog(BarangView.this,
                    "Permintaan peminjaman berhasil diajukan!\nTenggat: " + hariTenggat + " hari\nTunggu persetujuan admin.", "Berhasil",
                    JOptionPane.INFORMATION_MESSAGE);
                previewKode.setText(""); previewNama.setText(""); previewStok.setText(""); txtJumlahPinjam.setText("");
                btnPinjam.setEnabled(false);
                updateStatUser();
                setStatus("Peminjaman '" + nama + "' diajukan untuk " + hariTenggat + " hari.");
            } catch (SQLException ex) {
                showErr("Gagal mengajukan peminjaman:\n" + ex.getMessage());
            }
        });

        JButton btnRiwayat = buatTombolForm("↺ Lihat Riwayat Pinjam", new Color(103,58,183), Color.WHITE);
        btnRiwayat.addActionListener(e -> bukaRiwayatPinjam());

        // Inject preview field refs into table listener
        tabelBarang.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int row = tabelBarang.getSelectedRow();
                if (row < 0) return;
                previewKode.setText(modelTabel.getValueAt(row, 0).toString());
                previewNama.setText(modelTabel.getValueAt(row, 1).toString());
                previewStok.setText(modelTabel.getValueAt(row, 3).toString());
                txtJumlahPinjam.setText("");
                btnPinjam.setEnabled(true);
            }
        });

        card.add(lblJudul);
        card.add(Box.createVerticalStrut(8));
        card.add(lblInfo);
        card.add(Box.createVerticalStrut(16));
        card.add(formRow("Kode Barang (terpilih)", previewKode));
        card.add(formRow("Nama Barang",             previewNama));
        card.add(formRow("Stok Tersedia",           previewStok));
        card.add(formRow("Jumlah Pinjam",           txtJumlahPinjam));
        card.add(Box.createVerticalStrut(16));
        card.add(btnPinjam);
        card.add(Box.createVerticalStrut(10));

        JSeparator sep = new JSeparator();
        sep.setForeground(new Color(228, 232, 245));
        sep.setAlignmentX(LEFT_ALIGNMENT);
        sep.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1));
        card.add(sep);
        card.add(Box.createVerticalStrut(10));
        card.add(btnRiwayat);

        return card;
    }

    // ═══════════════════════════════════════════
    // HELPERS UI
    // ═══════════════════════════════════════════

    private JTextField buatInput() {
        JTextField tf = new JTextField();
        tf.setFont(new Font("SansSerif", Font.PLAIN, 13));
        tf.setAlignmentX(LEFT_ALIGNMENT);
        tf.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        tf.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(218, 225, 238), 1, true),
            new EmptyBorder(6, 10, 6, 10)
        ));
        tf.setBackground(new Color(252, 253, 255));
        return tf;
    }

    private JPanel formRow(String label, JComponent comp) {
        JPanel p = new JPanel();
        p.setOpaque(false);
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setAlignmentX(LEFT_ALIGNMENT);
        p.setMaximumSize(new Dimension(Integer.MAX_VALUE, 60));
        JLabel lbl = new JLabel(label);
        lbl.setFont(new Font("SansSerif", Font.BOLD, 11));
        lbl.setForeground(TEXT_SUB);
        lbl.setAlignmentX(LEFT_ALIGNMENT);
        comp.setAlignmentX(LEFT_ALIGNMENT);
        p.add(lbl);
        p.add(Box.createVerticalStrut(4));
        p.add(comp);
        p.add(Box.createVerticalStrut(10));
        return p;
    }

    private JPanel formRowArea(String label, JComponent comp) {
        JPanel p = new JPanel();
        p.setOpaque(false);
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setAlignmentX(LEFT_ALIGNMENT);
        JLabel lbl = new JLabel(label);
        lbl.setFont(new Font("SansSerif", Font.BOLD, 11));
        lbl.setForeground(TEXT_SUB);
        lbl.setAlignmentX(LEFT_ALIGNMENT);
        comp.setAlignmentX(LEFT_ALIGNMENT);
        p.add(lbl);
        p.add(Box.createVerticalStrut(4));
        p.add(comp);
        p.add(Box.createVerticalStrut(10));
        return p;
    }

    private JButton buatTombolForm(String teks, Color bg, Color fg) {
        JButton btn = new JButton(teks) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                Color c = getModel().isRollover() ? bg.darker() : bg;
                if (!isEnabled()) c = new Color(200, 204, 212);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                g2.setColor(c);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setForeground(fg);
        btn.setFont(new Font("SansSerif", Font.BOLD, 12));
        btn.setAlignmentX(LEFT_ALIGNMENT);
        btn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return btn;
    }

    private JButton buatTombolIcon(String teks) {
        JButton btn = new JButton(teks) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (getModel().isRollover()) {
                    g2.setColor(new Color(0, 168, 190, 20));
                    g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                }
                g2.dispose();
                super.paintComponent(g);
            }
        };
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setForeground(TEAL);
        btn.setFont(new Font("SansSerif", Font.BOLD, 12));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return btn;
    }

    private JPanel buatAvatar(String initial, int size, Color bg) {
        JPanel av = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setPaint(new GradientPaint(0, 0, bg.brighter(), size, size, bg.darker()));
                g2.fillOval(0, 0, size, size);
                g2.setColor(Color.WHITE);
                g2.setFont(new Font("SansSerif", Font.BOLD, size / 2 - 2));
                FontMetrics fm = g2.getFontMetrics();
                g2.drawString(initial, (size - fm.stringWidth(initial))/2, (size + fm.getAscent() - fm.getDescent())/2);
                g2.dispose();
            }
            public Dimension getPreferredSize() { return new Dimension(size, size); }
        };
        av.setOpaque(false);
        return av;
    }

    // ═══════════════════════════════════════════
    // LOGIKA DATA
    // ═══════════════════════════════════════════

    private void muatDataTabel() {
        try {
            modelTabel.setRowCount(0);
            List<Barang> list = ctrlBarang.getAllBarang();
            long totalStok = 0, totalNilai = 0;
            for (Barang b : list) {
                modelTabel.addRow(new Object[]{
                    b.getKodeBarang(), b.getNamaBarang(),
                    String.format("%,d", b.getHarga()), b.getStok(), b.getKeterangan()
                });
                totalStok  += b.getStok();
                totalNilai += (long) b.getHarga() * b.getStok();
            }

            // Update StatisticCard values (cards are always created in buatStatsRow)
            if (statCard1 != null) statCard1.setValue(String.valueOf(list.size()));
            if (statCard2 != null) statCard2.setValue(String.valueOf(totalStok));
            if (statCard3 != null) statCard3.setValue(formatRp(totalNilai));

            if (SessionManager.isAdmin()) {
                int pending = ctrlPeminjaman.countPending();
                if (statCard4 != null) statCard4.setValue(String.valueOf(pending));
            } else {
                updateStatUser();
            }
            setStatus("Data dimuat — " + list.size() + " barang.");
        } catch (SQLException e) {
            showErr("Gagal memuat data: " + e.getMessage());
        }
    }

    private void updateStatUser() {
        try {
            List<Peminjaman> myReq = ctrlPeminjaman.getByUser(SessionManager.getUsername());
            if (statCard3 != null) statCard3.setValue(String.valueOf(myReq.size()));
        } catch (SQLException ignored) {}
    }

    private void isiFormDariTabel() {
        if (!SessionManager.isAdmin()) return; // user punya listener sendiri
        int row = tabelBarang.getSelectedRow();
        if (row < 0) return;
        txtKode.setText(modelTabel.getValueAt(row, 0).toString());
        txtNama.setText(modelTabel.getValueAt(row, 1).toString());
        // harga mungkin formatted, hilangkan koma
        txtHarga.setText(modelTabel.getValueAt(row, 2).toString().replaceAll("[^0-9]", ""));
        txtStok.setText(modelTabel.getValueAt(row, 3).toString());
        txtKeterangan.setText(modelTabel.getValueAt(row, 4).toString());
        txtKode.setEditable(false);
        aturStatusTombolAdmin(true);
    }

    // ── Admin CRUD ────────────────────────────────────────────────

    private void prosesTambah() {
        Barang b = bacaFormAdmin();
        if (b == null) return;
        try {
            ctrlBarang.tambahBarang(b);
            muatDataTabel(); bersihkanForm();
            setStatus("Barang '" + b.getNamaBarang() + "' ditambahkan.");
        } catch (SQLException e) {
            if (e.getMessage().toLowerCase().contains("duplicate"))
                showErr("Kode barang sudah ada!");
            else showErr("Gagal menambah: " + e.getMessage());
        }
    }

    private void prosesSimpan() {
        Barang b = bacaFormAdmin();
        if (b == null) return;
        try {
            ctrlBarang.updateBarang(b);
            muatDataTabel(); bersihkanForm();
            setStatus("Barang '" + b.getNamaBarang() + "' diperbarui.");
        } catch (SQLException e) { showErr("Gagal memperbarui: " + e.getMessage()); }
    }

    private void prosesHapus() {
        if (txtKode == null || txtKode.getText().trim().isEmpty()) { showErr("Pilih barang dari tabel."); return; }
        String kode = txtKode.getText().trim();
        int c = JOptionPane.showConfirmDialog(this, "Hapus barang kode '" + kode + "'?", "Konfirmasi", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (c == JOptionPane.YES_OPTION) {
            try {
                ctrlBarang.hapusBarang(kode);
                muatDataTabel(); bersihkanForm();
                setStatus("Barang '" + kode + "' dihapus.");
            } catch (SQLException e) { showErr("Gagal menghapus: " + e.getMessage()); }
        }
    }

    private void bersihkanForm() {
        if (txtKode == null) return;
        txtKode.setText(""); txtNama.setText(""); txtHarga.setText("");
        txtStok.setText(""); txtKeterangan.setText("");
        txtKode.setEditable(true);
        tabelBarang.clearSelection();
        aturStatusTombolAdmin(false);
    }

    private Barang bacaFormAdmin() {
        String kode = txtKode.getText().trim(), nama = txtNama.getText().trim();
        String hStr = txtHarga.getText().trim(), sStr = txtStok.getText().trim();
        String ket  = txtKeterangan.getText().trim();
        if (kode.isEmpty() || nama.isEmpty() || hStr.isEmpty() || sStr.isEmpty()) {
            showErr("Kode, Nama, Harga, dan Stok wajib diisi!"); return null;
        }
        try {
            int h = Integer.parseInt(hStr), s = Integer.parseInt(sStr);
            if (h < 0 || s < 0) { showErr("Harga dan Stok tidak boleh negatif."); return null; }
            return new Barang(kode, nama, h, s, ket);
        } catch (NumberFormatException e) {
            showErr("Harga dan Stok harus angka!"); return null;
        }
    }

    private void aturStatusTombolAdmin(boolean dipilih) {
        if (btnTambah == null) return;
        btnTambah.setEnabled(!dipilih);
        btnSimpan.setEnabled(dipilih);
        btnHapus.setEnabled(dipilih);
    }

    // ── Navigation ────────────────────────────────────────────────

    private void prosesLogout() {
        int c = JOptionPane.showConfirmDialog(this, "Yakin ingin keluar?", "Logout", JOptionPane.YES_NO_OPTION);
        if (c == JOptionPane.YES_OPTION) {
            SessionManager.logout();
            new LoginView(); dispose();
        }
    }

    private void bukaDashboard() {
        JFrame dashFrame = new JFrame("Dashboard – Sistem Inventaris");
        dashFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        dashFrame.setMinimumSize(new Dimension(900, 650));
        dashFrame.add(new ModernDashboardView());
        dashFrame.pack();
        dashFrame.setLocationRelativeTo(this);
        dashFrame.setVisible(true);
    }

    private void bukaUserManagement() {
        // HANYA admin yang bisa
        if (!SessionManager.isAdmin()) {
            showErr("Akses ditolak. Fitur ini hanya untuk Administrator."); return;
        }
        new UserManagementView().setVisible(true);
    }

    private void bukaPeminjaman() {
        if (!SessionManager.isAdmin()) {
            showErr("Akses ditolak. Fitur ini hanya untuk Administrator."); return;
        }
        new PeminjamanView().setVisible(true);
    }

    private void bukaRiwayatPinjam() {
        // User melihat riwayat pinjamnya sendiri
        new RiwayatPinjamView(SessionManager.getUsername()).setVisible(true);
    }

    private void bukaLogBarang() {
        // Admin melihat riwayat masuk/keluar barang
        if (!SessionManager.isAdmin()) {
            showErr("Akses ditolak. Fitur ini hanya untuk Administrator."); return;
        }
        new LogBarangView().setVisible(true);
    }

    // ── NEW: Password Reset Approval ──────────────────────────────

    private void bukaPasswordResetApproval() {
        if (!SessionManager.isAdmin()) {
            showErr("Akses ditolak. Fitur ini hanya untuk Administrator."); return;
        }
        JFrame frame = new JFrame("Persetujuan Reset Password");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(1000, 600);
        frame.setLocationRelativeTo(this);
        frame.add(new PasswordResetApprovalView());
        frame.setVisible(true);
    }

    // ── NEW: Return Items Approval ────────────────────────────────

    private void bukaReturnItemApproval() {
        if (!SessionManager.isAdmin()) {
            showErr("Akses ditolak. Fitur ini hanya untuk Administrator."); return;
        }
        JFrame frame = new JFrame("Persetujuan Pengembalian Barang");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(1000, 600);
        frame.setLocationRelativeTo(this);
        frame.add(new ReturnItemApprovalView());
        frame.setVisible(true);
    }

    // ── NEW: User Return Items ────────────────────────────────────

    private void bukaUserReturnItem() {
        JFrame frame = new JFrame("Kembalikan Barang Pinjaman");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(1000, 600);
        frame.setLocationRelativeTo(this);
        frame.add(new UserReturnItemView(SessionManager.getUsername()));
        frame.setVisible(true);
    }

    // ── Helpers ───────────────────────────────────────────────────

    private String formatRp(long v) {
        if (v >= 1_000_000_000) return String.format("Rp%.1fM", v/1_000_000.0);
        if (v >= 1_000_000)     return String.format("Rp%.1fjt", v/1_000_000.0);
        if (v >= 1_000)         return String.format("Rp%.0frb", v/1_000.0);
        return "Rp" + v;
    }

    private void showErr(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Perhatian", JOptionPane.WARNING_MESSAGE);
    }

    private void setStatus(String msg) {
        if (lblStatus != null) lblStatus.setText(msg);
    }
}
