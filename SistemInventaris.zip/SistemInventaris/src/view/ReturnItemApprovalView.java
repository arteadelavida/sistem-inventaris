package view;

import component.GradientPanel;
import component.RoundedButton;
import java.awt.*;
import java.sql.SQLException;
import java.time.format.DateTimeFormatter;
import java.util.List;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import model.dto.ReturnItemDTO;
import service.ReturnItemService;
import util.exception.ValidationException;
import util.notification.NotificationUtil;

/**
 * ReturnItemApprovalView — Admin view untuk approve/reject pengembalian barang.
 */
public class ReturnItemApprovalView extends JPanel {
    
    // Warna
    private static final Color PRIMARY = new Color(0, 105, 140);
    private static final Color PRIMARY_LIGHT = new Color(0, 188, 212);
    private static final Color DARK = new Color(15, 32, 68);
    private static final Color TEXT_MAIN = new Color(28, 32, 50);
    private static final Color TEXT_LIGHT = new Color(120, 130, 155);
    private static final Color SUCCESS = new Color(76, 175, 80);
    private static final Color ERROR = new Color(244, 67, 54);
    private static final Color WARNING = new Color(255, 193, 7);
    private static final Color FIELD_BG = new Color(248, 250, 253);

    private JTable tblReturns;
    private RoundedButton btnRefresh;
    private RoundedButton btnApprove;
    private RoundedButton btnReject;
    private JLabel lblStatus;
    private ReturnItemService returnItemService;

    public ReturnItemApprovalView() {
        returnItemService = new ReturnItemService();
        buatUI();
    }

    private void buatUI() {
        setLayout(new BorderLayout(15, 15));
        setBorder(new EmptyBorder(20, 20, 20, 20));
        setBackground(Color.WHITE);

        // Header dengan gradient
        JPanel pnlHeader = new GradientPanel(PRIMARY, PRIMARY_LIGHT, GradientPanel.HORIZONTAL, 15);
        pnlHeader.setLayout(new BorderLayout(10, 10));
        pnlHeader.setBorder(new EmptyBorder(20, 20, 20, 20));
        pnlHeader.setPreferredSize(new Dimension(0, 100));

        JLabel lblTitle = new JLabel("Persetujuan Pengembalian Barang");
        lblTitle.setFont(new Font("SansSerif", Font.BOLD, 20));
        lblTitle.setForeground(Color.WHITE);

        JLabel lblDesc = new JLabel("Review dan approve/reject pengembalian barang dari user");
        lblDesc.setFont(new Font("SansSerif", Font.PLAIN, 12));
        lblDesc.setForeground(new Color(200, 230, 255));

        JPanel pnlTitleDesc = new JPanel();
        pnlTitleDesc.setOpaque(false);
        pnlTitleDesc.setLayout(new BoxLayout(pnlTitleDesc, BoxLayout.Y_AXIS));
        pnlTitleDesc.add(lblTitle);
        pnlTitleDesc.add(lblDesc);

        btnRefresh = new RoundedButton("🔄 Refresh");
        btnRefresh.setPreferredSize(new Dimension(120, 35));
        btnRefresh.setBackground(new Color(255, 255, 255, 80));
        btnRefresh.setForeground(Color.WHITE);
        btnRefresh.addActionListener(e -> loadReturns());

        pnlHeader.add(pnlTitleDesc, BorderLayout.CENTER);
        pnlHeader.add(btnRefresh, BorderLayout.EAST);

        // Table
        tblReturns = buatTable();
        JScrollPane scrollTable = new JScrollPane(tblReturns);
        scrollTable.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        scrollTable.getViewport().setBackground(Color.WHITE);

        // Bottom panel
        JPanel pnlBottom = new JPanel(new BorderLayout(10, 0));
        pnlBottom.setOpaque(false);

        lblStatus = new JLabel("Memuat data...");
        lblStatus.setFont(new Font("SansSerif", Font.PLAIN, 11));
        lblStatus.setForeground(TEXT_LIGHT);

        JPanel pnlButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        pnlButtons.setOpaque(false);

        btnApprove = new RoundedButton("✓ Terima");
        btnApprove.setPreferredSize(new Dimension(110, 35));
        btnApprove.setBackground(SUCCESS);
        btnApprove.setForeground(Color.WHITE);
        btnApprove.addActionListener(e -> approveSelected());

        btnReject = new RoundedButton("✗ Tolak");
        btnReject.setPreferredSize(new Dimension(110, 35));
        btnReject.setBackground(ERROR);
        btnReject.setForeground(Color.WHITE);
        btnReject.addActionListener(e -> rejectSelected());

        pnlButtons.add(btnApprove);
        pnlButtons.add(btnReject);

        pnlBottom.add(lblStatus, BorderLayout.WEST);
        pnlBottom.add(pnlButtons, BorderLayout.EAST);

        // Assemble
        add(pnlHeader, BorderLayout.NORTH);
        add(scrollTable, BorderLayout.CENTER);
        add(pnlBottom, BorderLayout.SOUTH);

        // Load data
        loadReturns();
    }

    private JTable buatTable() {
        DefaultTableModel model = new DefaultTableModel(
            new String[]{"User", "Barang", "Jumlah", "Tanggal Return", "Kondisi", "Keterangan"}, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        JTable table = new JTable(model);
        table.setFont(new Font("SansSerif", Font.PLAIN, 11));
        table.setRowHeight(25);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setGridColor(new Color(230, 230, 230));

        JTableHeader header = table.getTableHeader();
        header.setBackground(PRIMARY);
        header.setForeground(Color.WHITE);
        header.setFont(new Font("SansSerif", Font.BOLD, 11));
        header.setPreferredSize(new Dimension(0, 30));

        table.getColumnModel().getColumn(0).setPreferredWidth(80);
        table.getColumnModel().getColumn(1).setPreferredWidth(100);
        table.getColumnModel().getColumn(2).setPreferredWidth(60);
        table.getColumnModel().getColumn(3).setPreferredWidth(100);
        table.getColumnModel().getColumn(4).setPreferredWidth(100);
        table.getColumnModel().getColumn(5).setPreferredWidth(200);

        return table;
    }

    private void loadReturns() {
        DefaultTableModel model = (DefaultTableModel) tblReturns.getModel();
        model.setRowCount(0);

        try {
            List<ReturnItemDTO> returns = returnItemService.getPendingReturnsWithDetails();
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");

            for (ReturnItemDTO item : returns) {
                String keterangan = item.getKeterangan();
                if (keterangan != null && keterangan.length() > 30) {
                    keterangan = keterangan.substring(0, 30) + "...";
                }

                model.addRow(new Object[]{
                    item.getUsername(),
                    item.getNamaBarang(),
                    item.getJumlahDikembalikan(),
                    item.getTanggalKembaliAktual().format(dtf),
                    item.getKondisiBarang(),
                    keterangan != null ? keterangan : "-"
                });
            }

            if (returns.isEmpty()) {
                lblStatus.setText("✓ Tidak ada pengembalian yang pending");
                lblStatus.setForeground(SUCCESS);
            } else {
                lblStatus.setText(returns.size() + " pengembalian menunggu persetujuan");
                lblStatus.setForeground(WARNING);
            }
        } catch (SQLException ex) {
            JFrame parent = (JFrame) SwingUtilities.getWindowAncestor(this);
            NotificationUtil.showError(parent, "Gagal memuat data pengembalian: " + ex.getMessage());
        }
    }

    private void approveSelected() {
        int selectedRow = tblReturns.getSelectedRow();
        JFrame parent = (JFrame) SwingUtilities.getWindowAncestor(this);
        
        if (selectedRow < 0) {
            NotificationUtil.showWarning(parent, "Pilih pengembalian yang ingin disetujui!");
            return;
        }

        String username = (String) tblReturns.getValueAt(selectedRow, 0);
        String namaBarang = (String) tblReturns.getValueAt(selectedRow, 1);

        if (!NotificationUtil.showConfirm(parent, 
            "Setujui pengembalian " + namaBarang + " dari " + username + "?",
            "Konfirmasi")) {
            return;
        }

        try {
            List<ReturnItemDTO> items = returnItemService.getPendingReturnsWithDetails();
            ReturnItemDTO selected = items.stream()
                .filter(r -> r.getUsername().equals(username) && r.getNamaBarang().equals(namaBarang))
                .findFirst()
                .orElse(null);

            if (selected != null) {
                returnItemService.approveReturn(selected.getId(), "admin");
                NotificationUtil.showSuccess(parent, "✓ Pengembalian disetujui!");
                loadReturns();
            } else {
                NotificationUtil.showWarning(parent, "Data pengembalian tidak ditemukan!");
            }
        } catch (ValidationException ex) {
            NotificationUtil.showWarning(parent, ex.getMessage());
        } catch (SQLException ex) {
            NotificationUtil.showError(parent, "Gagal memproses pengembalian: " + ex.getMessage());
        }
    }

    private void rejectSelected() {
        int selectedRow = tblReturns.getSelectedRow();
        JFrame parent = (JFrame) SwingUtilities.getWindowAncestor(this);
        
        if (selectedRow < 0) {
            NotificationUtil.showWarning(parent, "Pilih pengembalian yang ingin ditolak!");
            return;
        }

        String username = (String) tblReturns.getValueAt(selectedRow, 0);
        String namaBarang = (String) tblReturns.getValueAt(selectedRow, 1);

        if (!NotificationUtil.showConfirm(parent,
            "Tolak pengembalian " + namaBarang + " dari " + username + "?",
            "Konfirmasi")) {
            return;
        }

        try {
            List<ReturnItemDTO> items = returnItemService.getPendingReturnsWithDetails();
            ReturnItemDTO selected = items.stream()
                .filter(r -> r.getUsername().equals(username) && r.getNamaBarang().equals(namaBarang))
                .findFirst()
                .orElse(null);

            if (selected != null) {
                returnItemService.rejectReturn(selected.getId(), "admin");
                NotificationUtil.showSuccess(parent, "✓ Pengembalian ditolak!");
                loadReturns();
            } else {
                NotificationUtil.showWarning(parent, "Data pengembalian tidak ditemukan!");
            }
        } catch (ValidationException ex) {
            NotificationUtil.showWarning(parent, ex.getMessage());
        } catch (SQLException ex) {
            NotificationUtil.showError(parent, "Gagal menolak pengembalian: " + ex.getMessage());
        }
    }
}
