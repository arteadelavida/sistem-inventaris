package view;

import controller.UserController;
import model.User;
import util.SessionManager;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.*;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

/**
 * UserManagementView — Admin panel untuk menyetujui / menolak akun pending.
 * Hanya bisa diakses oleh admin (dicek dua lapis: di sini + di BarangView).
 */
public class UserManagementView extends JFrame {

    private static final Color BG        = new Color(240, 244, 252);
    private static final Color CARD_BG   = Color.WHITE;
    private static final Color TEAL      = new Color(0, 168, 190);
    private static final Color TEXT_MAIN = new Color(28, 32, 50);
    private static final Color TEXT_SUB  = new Color(120, 130, 155);
    private static final Color GREEN     = new Color(56, 176, 80);
    private static final Color RED       = new Color(244, 67, 54);
    private static final Color PURPLE    = new Color(103, 58, 183);

    private final UserController  ctrl = new UserController();
    private DefaultTableModel     modelTabel;
    private JTable                tabel;
    private JLabel                lblStatus;

    public UserManagementView() {
        // Guard: hanya admin
        if (!SessionManager.isAdmin()) {
            JOptionPane.showMessageDialog(null,
                "Akses ditolak. Fitur ini hanya untuk Administrator.",
                "Akses Ditolak", JOptionPane.ERROR_MESSAGE);
            dispose();
            return;
        }

        setTitle("Kelola Permintaan Akun");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setMinimumSize(new Dimension(580, 460));
        buatUI();
        muatData();
        pack();
        setLocationRelativeTo(null);
    }

    private void buatUI() {
        setLayout(new BorderLayout());
        getContentPane().setBackground(BG);

        // ── Header ──────────────────────────────────────────────
        JPanel header = new JPanel(new BorderLayout(12, 0));
        header.setBackground(CARD_BG);
        header.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(225, 230, 240)),
            new EmptyBorder(16, 24, 16, 24)
        ));
        JPanel titleStack = new JPanel();
        titleStack.setOpaque(false);
        titleStack.setLayout(new BoxLayout(titleStack, BoxLayout.Y_AXIS));
        JLabel lblJudul = new JLabel("Kelola Permintaan Akun");
        lblJudul.setFont(new Font("SansSerif", Font.BOLD, 18));
        lblJudul.setForeground(TEXT_MAIN);
        JLabel lblSub = new JLabel("Setujui atau tolak akun yang masih berstatus pending");
        lblSub.setFont(new Font("SansSerif", Font.PLAIN, 12));
        lblSub.setForeground(TEXT_SUB);
        titleStack.add(lblJudul);
        titleStack.add(lblSub);

        JButton btnRefresh = buatTombol("↻ Refresh", TEAL, Color.WHITE);
        btnRefresh.addActionListener(e -> muatData());
        header.add(titleStack, BorderLayout.WEST);
        header.add(btnRefresh, BorderLayout.EAST);

        // ── Table card ───────────────────────────────────────────
        JPanel card = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(0,0,0,8));
                g2.fillRoundRect(3,4,getWidth()-4,getHeight()-4,16,16);
                g2.setColor(CARD_BG);
                g2.fillRoundRect(0,0,getWidth()-2,getHeight()-2,16,16);
                g2.dispose();
            }
        };
        card.setOpaque(false);

        String[] kolom = {"Username","Role","Status"};
        modelTabel = new DefaultTableModel(kolom, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };

        tabel = new JTable(modelTabel);
        tabel.setRowHeight(36);
        tabel.setFont(new Font("SansSerif", Font.PLAIN, 13));
        tabel.setShowGrid(false);
        tabel.setIntercellSpacing(new Dimension(0,0));
        tabel.setSelectionBackground(new Color(0,168,190,35));
        tabel.setBackground(CARD_BG);

        JTableHeader th = tabel.getTableHeader();
        th.setFont(new Font("SansSerif", Font.BOLD, 12));
        th.setBackground(new Color(246,249,253));
        th.setForeground(TEXT_SUB);
        th.setBorder(BorderFactory.createMatteBorder(0,0,1,0,new Color(228,232,245)));

        // Base renderer + role pill
        tabel.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable t, Object v,
                    boolean sel, boolean foc, int row, int col) {
                super.getTableCellRendererComponent(t,v,sel,foc,row,col);
                setFont(new Font("SansSerif", Font.PLAIN, 13));
                setBorder(new EmptyBorder(4,14,4,14));
                setForeground(TEXT_MAIN);
                if (sel) setBackground(new Color(0,168,190,35));
                else     setBackground(row%2==0 ? CARD_BG : new Color(248,250,254));
                // Role column
                if (col == 1 && v != null) {
                    String r = v.toString();
                    setFont(new Font("SansSerif", Font.BOLD, 11));
                    setHorizontalAlignment(CENTER);
                    setOpaque(true);
                    if ("admin".equalsIgnoreCase(r)) { setForeground(PURPLE); setBackground(new Color(237,231,246)); }
                    else                             { setForeground(TEAL);   setBackground(new Color(224,247,250)); }
                }
                return this;
            }
        });

        // Status renderer
        tabel.getColumnModel().getColumn(2).setCellRenderer(new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable t, Object v,
                    boolean sel, boolean foc, int row, int col) {
                super.getTableCellRendererComponent(t,v,sel,foc,row,col);
                setFont(new Font("SansSerif", Font.BOLD, 11));
                setHorizontalAlignment(CENTER);
                setOpaque(true);
                setBorder(new EmptyBorder(4,8,4,8));
                String s = v==null ? "" : v.toString();
                if ("pending".equalsIgnoreCase(s)) { setForeground(new Color(255,152,0)); setBackground(new Color(255,243,224)); }
                else                               { setForeground(GREEN); setBackground(new Color(232,245,233)); }
                return this;
            }
        });

        JScrollPane scroll = new JScrollPane(tabel);
        scroll.setBorder(null);
        scroll.getViewport().setBackground(CARD_BG);
        scroll.setPreferredSize(new Dimension(540, 280));
        card.add(scroll, BorderLayout.CENTER);

        // ── Action row ───────────────────────────────────────────
        JButton btnSetujui = buatTombol("✔  Setujui Akun",  GREEN, Color.WHITE);
        JButton btnTolak   = buatTombol("✕  Tolak Akun",    RED,   Color.WHITE);
        lblStatus = new JLabel("Pilih akun dari tabel.");
        lblStatus.setFont(new Font("SansSerif", Font.PLAIN, 11));
        lblStatus.setForeground(TEXT_SUB);

        btnSetujui.addActionListener(e -> prosesSetujui());
        btnTolak.addActionListener(e -> prosesTolak());

        JPanel actionRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 12));
        actionRow.setOpaque(false);
        actionRow.add(btnSetujui);
        actionRow.add(btnTolak);
        actionRow.add(lblStatus);

        JPanel center = new JPanel(new BorderLayout());
        center.setBackground(BG);
        center.setBorder(new EmptyBorder(16,20,10,20));
        center.add(card,      BorderLayout.CENTER);
        center.add(actionRow, BorderLayout.SOUTH);

        add(header, BorderLayout.NORTH);
        add(center, BorderLayout.CENTER);
    }

    // ── Data & Logic ──────────────────────────────────────────────

    private void muatData() {
        try {
            modelTabel.setRowCount(0);
            List<User> list = ctrl.getPendingUsers();
            for (User u : list)
                modelTabel.addRow(new Object[]{u.getUsername(), u.getRole(), u.getStatus()});
            lblStatus.setText(list.isEmpty()
                ? "Tidak ada akun yang menunggu persetujuan."
                : list.size() + " akun pending ditemukan.");
        } catch (SQLException e) {
            lblStatus.setText("Error: " + e.getMessage());
        }
    }

    private void prosesSetujui() {
        String username = getSelected();
        if (username == null) return;
        int c = JOptionPane.showConfirmDialog(this,
            "Setujui akun '" + username + "'?", "Konfirmasi", JOptionPane.YES_NO_OPTION);
        if (c == JOptionPane.YES_OPTION) {
            try {
                ctrl.setujuiAkun(username);
                muatData();
                lblStatus.setText("✔ Akun '" + username + "' disetujui.");
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void prosesTolak() {
        String username = getSelected();
        if (username == null) return;
        int c = JOptionPane.showConfirmDialog(this,
            "Tolak dan hapus akun '" + username + "'?", "Konfirmasi Tolak",
            JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (c == JOptionPane.YES_OPTION) {
            try {
                ctrl.tolakAkun(username);
                muatData();
                lblStatus.setText("✕ Akun '" + username + "' ditolak.");
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private String getSelected() {
        int row = tabel.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Pilih akun dari tabel terlebih dahulu.",
                "Info", JOptionPane.INFORMATION_MESSAGE);
            return null;
        }
        return modelTabel.getValueAt(row, 0).toString();
    }

    private JButton buatTombol(String teks, Color bg, Color fg) {
        JButton btn = new JButton(teks) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isRollover() ? bg.darker() : bg);
                g2.fillRoundRect(0,0,getWidth(),getHeight(),10,10);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setForeground(fg);
        btn.setFont(new Font("SansSerif", Font.BOLD, 12));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(150, 36));
        return btn;
    }
}
