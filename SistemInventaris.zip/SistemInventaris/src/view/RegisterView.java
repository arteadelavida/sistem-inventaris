package view;

import controller.AuthController;
import java.awt.*;
import java.awt.event.*;
import java.sql.SQLException;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

/**
 * RegisterView — Mirror dari LoginView.
 * Kiri: form registrasi putih dengan ElegantField
 * Kanan: deep panel branding dengan tombol kembali login
 */
public class RegisterView extends JFrame {

    private LoginView.ElegantField fldUsername;
    private LoginView.ElegantField fldPassword;
    private LoginView.ElegantField fldConfirm;
    private JComboBox<String>      cmbRole;
    private final AuthController   auth = new AuthController();

    public RegisterView() {
        setTitle("Sistem Inventaris – Daftar Akun");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        buatUI();
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void buatUI() {
        JPanel root = new JPanel(new GridLayout(1, 2));
        root.setPreferredSize(new Dimension(900, 580));
        root.add(buatPanelKiri());
        root.add(buatPanelKanan());
        setContentPane(root);
    }

    // ── KIRI: form ────────────────────────────────────────────────

    private JPanel buatPanelKiri() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.WHITE);

        JPanel form = new JPanel();
        form.setOpaque(false);
        form.setLayout(new BoxLayout(form, BoxLayout.Y_AXIS));
        form.setPreferredSize(new Dimension(350, 500));

        JLabel lblSub   = LoginView.buatLabel("BUAT AKUN BARU", 10, Font.BOLD, LoginView.DEEP_3);
        lblSub.setAlignmentX(CENTER_ALIGNMENT);

        JLabel lblTitle = LoginView.buatLabel("Daftar Sekarang", 30, Font.BOLD, LoginView.TEXT_MAIN);
        lblTitle.setAlignmentX(CENTER_ALIGNMENT);

        JLabel lblDesc  = LoginView.buatLabel("Isi data di bawah untuk membuat akun", 12, Font.PLAIN, LoginView.TEXT_SUB);
        lblDesc.setAlignmentX(CENTER_ALIGNMENT);

        fldUsername = new LoginView.ElegantField("Nama Pengguna", false);
        fldUsername.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));

        fldPassword = new LoginView.ElegantField("Kata Sandi", true);
        fldPassword.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));

        fldConfirm  = new LoginView.ElegantField("Ulangi Kata Sandi", true);
        fldConfirm.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));

        // Role combo
        JPanel roleWrap = new JPanel(new BorderLayout());
        roleWrap.setOpaque(false);
        roleWrap.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));
        roleWrap.setAlignmentX(LEFT_ALIGNMENT);
        cmbRole = new JComboBox<>(new String[]{"user", "admin"});
        cmbRole.setFont(new Font("SansSerif", Font.PLAIN, 13));
        cmbRole.setBackground(LoginView.FIELD_BG);
        cmbRole.setBorder(BorderFactory.createLineBorder(LoginView.BORDER_IDLE, 1, true));
        roleWrap.add(cmbRole, BorderLayout.CENTER);

        JButton btnDaftar = LoginView.buatGradientButton("Daftar  →");
        btnDaftar.setAlignmentX(CENTER_ALIGNMENT);
        btnDaftar.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));
        btnDaftar.addActionListener(e -> prosesDaftar());

        // Footer link
        JLabel lblSudah  = LoginView.buatLabel("Sudah punya akun? ", 12, Font.PLAIN, LoginView.TEXT_SUB);
        JLabel lblLogin  = LoginView.buatLabel("Masuk", 12, Font.BOLD, LoginView.TEAL);
        lblLogin.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        lblLogin.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) { new LoginView(); dispose(); }
        });

        JPanel loginRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 2, 0));
        loginRow.setOpaque(false);
        loginRow.setAlignmentX(CENTER_ALIGNMENT);
        loginRow.add(lblSudah);
        loginRow.add(lblLogin);

        form.add(lblSub);
        form.add(Box.createVerticalStrut(6));
        form.add(lblTitle);
        form.add(Box.createVerticalStrut(6));
        form.add(lblDesc);
        form.add(Box.createVerticalStrut(22));
        
        // Field wrappers
        form.add(buatFieldWithLabel("Username", fldUsername));
        form.add(Box.createVerticalStrut(12));
        form.add(buatFieldWithLabel("Password", fldPassword));
        form.add(Box.createVerticalStrut(12));
        form.add(buatFieldWithLabel("Konfirmasi Password", fldConfirm));
        form.add(Box.createVerticalStrut(12));
        form.add(buatFieldWithLabel("Role", roleWrap));
        form.add(Box.createVerticalStrut(22));
        form.add(btnDaftar);
        form.add(Box.createVerticalStrut(16));
        form.add(loginRow);

        panel.add(form);
        return panel;
    }

    // ── KANAN: branding ───────────────────────────────────────────

    private JPanel buatPanelKanan() {
        JPanel panel = new LoginView.DeepPanel();
        panel.setLayout(new GridBagLayout());

        JPanel content = new JPanel();
        content.setOpaque(false);
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setBorder(new EmptyBorder(0, 30, 0, 30));

        JPanel iconBox = LoginView.buatIconBulat("◉", 52, new Color(255,255,255,40), Color.WHITE);
        iconBox.setAlignmentX(CENTER_ALIGNMENT);

        JLabel lblBrand = LoginView.buatLabel("SISTEM INVENTARIS", 11, Font.BOLD, new Color(0,220,240));
        lblBrand.setAlignmentX(CENTER_ALIGNMENT);
        lblBrand.setBorder(new EmptyBorder(14, 0, 2, 0));

        JLabel lbl1 = LoginView.buatLabel("Selamat datang", 26, Font.PLAIN, new Color(200,230,255));
        lbl1.setAlignmentX(CENTER_ALIGNMENT);
        JLabel lbl2 = LoginView.buatLabel("di platform kami", 26, Font.BOLD, Color.WHITE);
        lbl2.setAlignmentX(CENTER_ALIGNMENT);

        JLabel lblDesc = LoginView.buatLabel("Kelola barang, pantau stok, dan\nkelola pengguna dengan mudah.", 12, Font.PLAIN, new Color(180,210,240));
        lblDesc.setAlignmentX(CENTER_ALIGNMENT);

        JSeparator sep = new JSeparator();
        sep.setForeground(new Color(255,255,255,40));
        sep.setMaximumSize(new Dimension(240, 1));
        sep.setAlignmentX(CENTER_ALIGNMENT);

        JLabel lblPrompt = LoginView.buatLabel("Sudah punya akun?", 12, Font.PLAIN, new Color(180,210,240));
        lblPrompt.setAlignmentX(CENTER_ALIGNMENT);

        JButton btnLogin = LoginView.buatOutlineButton("Masuk Sekarang");
        btnLogin.setAlignmentX(CENTER_ALIGNMENT);
        btnLogin.addActionListener(e -> { new LoginView(); dispose(); });

        content.add(iconBox);
        content.add(Box.createVerticalStrut(8));
        content.add(lblBrand);
        content.add(Box.createVerticalStrut(16));
        content.add(lbl1);
        content.add(lbl2);
        content.add(Box.createVerticalStrut(14));
        content.add(lblDesc);
        content.add(Box.createVerticalStrut(28));
        content.add(sep);
        content.add(Box.createVerticalStrut(20));
        content.add(lblPrompt);
        content.add(Box.createVerticalStrut(12));
        content.add(btnLogin);

        panel.add(content);
        return panel;
    }

    // ── Helper: Wrapper label + field ──────────────────────────
    private JPanel buatFieldWithLabel(String labelText, JComponent field) {
        JPanel wrapper = new JPanel();
        wrapper.setOpaque(false);
        wrapper.setLayout(new BoxLayout(wrapper, BoxLayout.Y_AXIS));
        wrapper.setAlignmentX(CENTER_ALIGNMENT);
        wrapper.setMaximumSize(new Dimension(Integer.MAX_VALUE, 70));
        
        JLabel label = LoginView.buatFormLabel(labelText);
        label.setAlignmentX(LEFT_ALIGNMENT);
        
        wrapper.add(label);
        wrapper.add(Box.createVerticalStrut(6));
        wrapper.add(field);
        
        return wrapper;
    }

    // ── Logika ────────────────────────────────────────────────────

    private void prosesDaftar() {
        String username = fldUsername.getValue().trim();
        String password = fldPassword.getValue();
        String confirm  = fldConfirm.getValue();
        String role     = (String) cmbRole.getSelectedItem();

        if (username.isEmpty() || password.isEmpty() || confirm.isEmpty()) {
            showErr("Semua kolom harus diisi!"); return;
        }
        if (username.length() < 3) { showErr("Username minimal 3 karakter."); return; }
        if (!password.equals(confirm)) { showErr("Kata sandi tidak cocok!"); return; }
        if (password.length() < 4) { showErr("Kata sandi minimal 4 karakter."); return; }

        try {
            auth.register(username, password, role);
            JOptionPane.showMessageDialog(this,
                "Registrasi berhasil!\nAkun Anda akan aktif setelah disetujui Admin.",
                "Berhasil", JOptionPane.INFORMATION_MESSAGE);
            new LoginView(); dispose();
        } catch (AuthController.DuplicateUsernameException ex) {
            showErr(ex.getMessage());
        } catch (SQLException ex) {
            showErr("Koneksi database gagal:\n" + ex.getMessage());
        }
    }

    private void showErr(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Perhatian", JOptionPane.WARNING_MESSAGE);
    }
}
