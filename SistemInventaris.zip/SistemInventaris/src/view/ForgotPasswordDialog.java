package view;

import component.RoundedButton;
import component.RoundedTextField;
import controller.PasswordResetController;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

/**
 * ForgotPasswordDialog — Dialog untuk request password reset.
 * User mengisi username, email, dan alasan, lalu submit untuk approval admin.
 */
public class ForgotPasswordDialog extends JDialog {
    
    // Warna profesional
    private static final Color PRIMARY = new Color(0, 105, 140);
    private static final Color PRIMARY_LIGHT = new Color(0, 188, 212);
    private static final Color DARK = new Color(15, 32, 68);
    private static final Color TEXT_MAIN = new Color(28, 32, 50);
    private static final Color TEXT_LIGHT = new Color(120, 130, 155);
    private static final Color SUCCESS = new Color(76, 175, 80);
    private static final Color ERROR = new Color(244, 67, 54);
    private static final Color FIELD_BG = new Color(248, 250, 253);

    private RoundedTextField fldUsername;
    private JTextArea txtAlasan;
    private JLabel lblStatus;
    private RoundedButton btnSubmit;
    private RoundedButton btnBatal;

    public ForgotPasswordDialog(JFrame parent) {
        super(parent, "Lupa Password - Request Reset", true);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setResizable(false);
        buatUI();
        pack();
        setLocationRelativeTo(parent);
    }

    private void buatUI() {
        JPanel root = new JPanel();
        root.setBackground(Color.WHITE);
        root.setLayout(new BorderLayout());
        root.setBorder(new EmptyBorder(30, 30, 30, 30));

        // Header
        JPanel pnlHeader = new JPanel();
        pnlHeader.setOpaque(false);
        pnlHeader.setLayout(new BoxLayout(pnlHeader, BoxLayout.Y_AXIS));
        pnlHeader.setBorder(new EmptyBorder(0, 0, 20, 0));

        JLabel lblTitle = new JLabel("Lupa Password?");
        lblTitle.setFont(new Font("SansSerif", Font.BOLD, 24));
        lblTitle.setForeground(DARK);

        JLabel lblDesc = new JLabel("Ajukan permohonan reset password. Admin akan mereview dan menyetujui permintaan Anda.");
        lblDesc.setFont(new Font("SansSerif", Font.PLAIN, 12));
        lblDesc.setForeground(TEXT_LIGHT);

        pnlHeader.add(lblTitle);
        pnlHeader.add(Box.createVerticalStrut(5));
        pnlHeader.add(lblDesc);

        // Form
        JPanel pnlForm = buatFormPanel();

        // Status message
        lblStatus = new JLabel(" ");
        lblStatus.setFont(new Font("SansSerif", Font.PLAIN, 11));
        lblStatus.setForeground(ERROR);

        // Buttons
        JPanel pnlButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        pnlButtons.setOpaque(false);
        pnlButtons.setBorder(new EmptyBorder(20, 0, 0, 0));

        btnBatal = new RoundedButton("Batal");
        btnBatal.setPreferredSize(new Dimension(100, 40));
        btnBatal.setBackground(new Color(200, 200, 200));
        btnBatal.setForeground(Color.WHITE);
        btnBatal.addActionListener(e -> dispose());

        btnSubmit = new RoundedButton("Submit Request");
        btnSubmit.setPreferredSize(new Dimension(140, 40));
        btnSubmit.setBackground(SUCCESS);
        btnSubmit.setForeground(Color.WHITE);
        btnSubmit.addActionListener(e -> submitRequest());

        pnlButtons.add(btnBatal);
        pnlButtons.add(btnSubmit);

        // Assemble
        JPanel pnlContent = new JPanel();
        pnlContent.setOpaque(false);
        pnlContent.setLayout(new BoxLayout(pnlContent, BoxLayout.Y_AXIS));
        pnlContent.add(pnlHeader);
        pnlContent.add(pnlForm);
        pnlContent.add(Box.createVerticalStrut(10));
        pnlContent.add(lblStatus);
        pnlContent.add(pnlButtons);

        root.add(pnlContent, BorderLayout.CENTER);

        setContentPane(root);
        setPreferredSize(new Dimension(500, 450));
    }

    private JPanel buatFormPanel() {
        JPanel panel = new JPanel();
        panel.setOpaque(false);
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(new EmptyBorder(0, 0, 0, 0));

        // Username
        JLabel lblUsername = new JLabel("Username:");
        lblUsername.setFont(new Font("SansSerif", Font.PLAIN, 11));
        lblUsername.setForeground(TEXT_MAIN);
        lblUsername.setAlignmentX(LEFT_ALIGNMENT);

        fldUsername = new RoundedTextField("Masukkan username Anda");
        fldUsername.setPreferredSize(new Dimension(400, 35));
        fldUsername.setMaximumSize(new Dimension(400, 35));
        fldUsername.setBackground(FIELD_BG);
        fldUsername.setAlignmentX(LEFT_ALIGNMENT);

        // Alasan
        JLabel lblAlasan = new JLabel("Alasan Lupa Password:");
        lblAlasan.setFont(new Font("SansSerif", Font.PLAIN, 11));
        lblAlasan.setForeground(TEXT_MAIN);
        lblAlasan.setAlignmentX(LEFT_ALIGNMENT);

        txtAlasan = new JTextArea(4, 40);
        txtAlasan.setFont(new Font("SansSerif", Font.PLAIN, 11));
        txtAlasan.setBackground(FIELD_BG);
        txtAlasan.setForeground(TEXT_MAIN);
        txtAlasan.setLineWrap(true);
        txtAlasan.setWrapStyleWord(true);
        txtAlasan.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));

        JScrollPane scrollAlasan = new JScrollPane(txtAlasan);
        scrollAlasan.setPreferredSize(new Dimension(400, 80));
        scrollAlasan.setMaximumSize(new Dimension(400, 80));
        scrollAlasan.setAlignmentX(LEFT_ALIGNMENT);

        // Add components
        panel.add(lblUsername);
        panel.add(Box.createVerticalStrut(5));
        panel.add(fldUsername);
        panel.add(Box.createVerticalStrut(15));
        panel.add(lblAlasan);
        panel.add(Box.createVerticalStrut(5));
        panel.add(scrollAlasan);

        return panel;
    }

    private void submitRequest() {
        String username = fldUsername.getRealText().trim();
        String alasan = txtAlasan.getText().trim();

        // Validasi
        if (username.isEmpty()) {
            setStatusMessage("❌ Username tidak boleh kosong!", ERROR);
            return;
        }
        if (alasan.isEmpty()) {
            setStatusMessage("❌ Alasan harus diisi!", ERROR);
            return;
        }

        // Submit
        PasswordResetController controller = new PasswordResetController();
        String token = controller.requestPasswordReset(username, "", alasan);

        if (token != null) {
            setStatusMessage("✓ Request berhasil dikirim! Admin akan mereview permintaan Anda.", SUCCESS);
            btnSubmit.setEnabled(false);
            fldUsername.setEditable(false);
            txtAlasan.setEditable(false);
            
            // Tutup setelah 3 detik
            Timer timer = new Timer(3000, e -> dispose());
            timer.setRepeats(false);
            timer.start();
        } else {
            setStatusMessage("❌ Username tidak terdaftar!", ERROR);
        }
    }

    private void setStatusMessage(String msg, Color color) {
        lblStatus.setText(msg);
        lblStatus.setForeground(color);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Test");
            ForgotPasswordDialog dialog = new ForgotPasswordDialog(frame);
            dialog.setVisible(true);
        });
    }
}
