package view;

import component.*;
import controller.BarangController;
import model.dto.DashboardDTO;
import model.dto.DashboardDTO.ActivityDTO;
import service.DashboardService;
import util.notification.NotificationUtil;
import util.SessionManager;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.List;

/**
 * ModernDashboardView — Dashboard enterprise-level dengan statistik komprehensif.
 * Features: Statistics cards, recent activities, alerts, responsive layout.
 */
public class ModernDashboardView extends JPanel {
    
    // Warna enterprise
    private static final Color PRIMARY = new Color(0, 105, 140);
    private static final Color PRIMARY_LIGHT = new Color(0, 188, 212);
    private static final Color DARK = new Color(15, 32, 68);
    private static final Color TEXT_MAIN = new Color(28, 32, 50);
    private static final Color TEXT_LIGHT = new Color(120, 130, 155);
    private static final Color SUCCESS = new Color(76, 175, 80);
    private static final Color WARNING = new Color(255, 193, 7);
    private static final Color ERROR = new Color(244, 67, 54);
    private static final Color BG_LIGHT = new Color(248, 250, 253);
    private static final Color CARD_BG = Color.WHITE;
    
    private DashboardService dashboardService;
    private DashboardDTO dashboardData;
    
    private JLabel lblLoadingStatus;
    private JPanel pnlStatistics;
    private JPanel pnlAlerts;
    private JPanel pnlActivities;
    
    public ModernDashboardView() {
        this.dashboardService = new DashboardService();
        buatUI();
        loadDashboardData();
    }
    
    private void buatUI() {
        setLayout(new BorderLayout());
        setBackground(BG_LIGHT);
        
        // Header
        add(buatHeader(), BorderLayout.NORTH);
        
        // Main content dengan scroll
        JScrollPane scrollContent = new JScrollPane(buatMainContent());
        scrollContent.setBorder(null);
        scrollContent.getViewport().setBackground(BG_LIGHT);
        add(scrollContent, BorderLayout.CENTER);
    }
    
    private JPanel buatHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(CARD_BG);
        header.setBorder(new EmptyBorder(20, 20, 20, 20));
        header.setPreferredSize(new Dimension(0, 80));
        
        JLabel lblTitle = new JLabel("Dashboard");
        lblTitle.setFont(new Font("SansSerif", Font.BOLD, 28));
        lblTitle.setForeground(TEXT_MAIN);
        
        JLabel lblSubtitle = new JLabel("Selamat datang, " + SessionManager.getUsername());
        lblSubtitle.setFont(new Font("SansSerif", Font.PLAIN, 13));
        lblSubtitle.setForeground(TEXT_LIGHT);
        
        JPanel leftPanel = new JPanel();
        leftPanel.setOpaque(false);
        leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
        leftPanel.add(lblTitle);
        leftPanel.add(Box.createVerticalStrut(5));
        leftPanel.add(lblSubtitle);
        
        // Refresh button
        RoundedButton btnRefresh = new RoundedButton("🔄 Refresh");
        btnRefresh.setPreferredSize(new Dimension(110, 35));
        btnRefresh.setBackground(PRIMARY);
        btnRefresh.setForeground(Color.WHITE);
        btnRefresh.addActionListener(e -> loadDashboardData());
        
        header.add(leftPanel, BorderLayout.WEST);
        header.add(btnRefresh, BorderLayout.EAST);
        
        // Bottom border
        header.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(220, 220, 220)),
            new EmptyBorder(20, 20, 20, 20)
        ));
        
        return header;
    }
    
    private JPanel buatMainContent() {
        JPanel main = new JPanel();
        main.setLayout(new BoxLayout(main, BoxLayout.Y_AXIS));
        main.setBackground(BG_LIGHT);
        main.setBorder(new EmptyBorder(20, 20, 20, 20));
        
        // Section 1: Statistics Cards
        main.add(buatStatisticsSection());
        main.add(Box.createVerticalStrut(30));
        
        // Section 2: Alerts
        main.add(buatAlertsSection());
        main.add(Box.createVerticalStrut(30));
        
        // Section 3: Recent Activities
        main.add(buatActivitiesSection());
        
        return main;
    }
    
    private JPanel buatStatisticsSection() {
        JPanel section = new JPanel();
        section.setLayout(new BoxLayout(section, BoxLayout.Y_AXIS));
        section.setOpaque(false);
        
        JLabel lblTitle = new JLabel("📊 Statistik Utama");
        lblTitle.setFont(new Font("SansSerif", Font.BOLD, 16));
        lblTitle.setForeground(TEXT_MAIN);
        section.add(lblTitle);
        section.add(Box.createVerticalStrut(15));
        
        // Grid of statistics — 3 columns x 2 rows = 6 cards
        pnlStatistics = new JPanel(new GridLayout(2, 3, 15, 15));
        pnlStatistics.setOpaque(false);
        pnlStatistics.setMaximumSize(new Dimension(Integer.MAX_VALUE, 270));
        
        section.add(pnlStatistics);
        return section;
    }
    
    private JPanel buatAlertsSection() {
        JPanel section = new JPanel();
        section.setLayout(new BoxLayout(section, BoxLayout.Y_AXIS));
        section.setOpaque(false);
        
        JLabel lblTitle = new JLabel("⚠️ Alerts");
        lblTitle.setFont(new Font("SansSerif", Font.BOLD, 16));
        lblTitle.setForeground(TEXT_MAIN);
        section.add(lblTitle);
        section.add(Box.createVerticalStrut(15));
        
        pnlAlerts = new JPanel();
        pnlAlerts.setLayout(new BoxLayout(pnlAlerts, BoxLayout.Y_AXIS));
        pnlAlerts.setOpaque(false);
        pnlAlerts.setMaximumSize(new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE));
        
        section.add(pnlAlerts);
        return section;
    }
    
    private JPanel buatActivitiesSection() {
        JPanel section = new JPanel();
        section.setLayout(new BoxLayout(section, BoxLayout.Y_AXIS));
        section.setOpaque(false);
        
        JLabel lblTitle = new JLabel("📋 Recent Activity");
        lblTitle.setFont(new Font("SansSerif", Font.BOLD, 16));
        lblTitle.setForeground(TEXT_MAIN);
        section.add(lblTitle);
        section.add(Box.createVerticalStrut(15));
        
        pnlActivities = new JPanel();
        pnlActivities.setLayout(new BoxLayout(pnlActivities, BoxLayout.Y_AXIS));
        pnlActivities.setOpaque(false);
        pnlActivities.setMaximumSize(new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE));
        
        section.add(pnlActivities);
        return section;
    }
    
    private void loadDashboardData() {
        SwingWorker<DashboardDTO, Void> worker = new SwingWorker<DashboardDTO, Void>() {
            @Override
            protected DashboardDTO doInBackground() throws Exception {
                return dashboardService.buildFullDashboard();
            }
            
            @Override
            protected void done() {
                try {
                    dashboardData = get();
                    refreshUI();
                } catch (Exception e) {
                    NotificationUtil.showError((JFrame) SwingUtilities.getWindowAncestor(ModernDashboardView.this),
                            "Gagal memuat dashboard: " + e.getMessage());
                }
            }
        };
        worker.execute();
    }
    
    private void refreshUI() {
        // Refresh statistics — 6 cards
        pnlStatistics.removeAll();
        pnlStatistics.add(buatStatisticCard("📦 Total Barang",     dashboardData.getTotalBarang() + "",         PRIMARY));
        pnlStatistics.add(buatStatisticCard("✅ Tersedia",          dashboardData.getBarangTersedia() + "",       SUCCESS));
        pnlStatistics.add(buatStatisticCard("📤 Dipinjam",         dashboardData.getBarangDipinjam() + "",      WARNING));
        pnlStatistics.add(buatStatisticCard("❌ Rusak/Hilang",     dashboardData.getBarangRusakHilang() + "",   ERROR));
        pnlStatistics.add(buatStatisticCard("⏳ Req. Peminjaman",  dashboardData.getPeminjamanPending() + "",   new Color(103, 58, 183)));
        pnlStatistics.add(buatStatisticCard("📥 Req. Kembali",     dashboardData.getPengembalianPending() + "", new Color(0, 150, 136)));
        
        // Refresh alerts
        pnlAlerts.removeAll();
        if (dashboardData.getAlerts().isEmpty()) {
            JLabel lblNoAlert = new JLabel("✓ Tidak ada alert");
            lblNoAlert.setForeground(TEXT_LIGHT);
            lblNoAlert.setFont(new Font("SansSerif", Font.PLAIN, 12));
            pnlAlerts.add(lblNoAlert);
        } else {
            for (DashboardDTO.AlertDTO alert : dashboardData.getAlerts()) {
                pnlAlerts.add(buatAlertItem(alert));
                pnlAlerts.add(Box.createVerticalStrut(10));
            }
        }
        
        // Refresh activities
        pnlActivities.removeAll();
        if (dashboardData.getRecentActivities().isEmpty()) {
            JLabel lblNoActivity = new JLabel("Tidak ada activity");
            lblNoActivity.setForeground(TEXT_LIGHT);
            lblNoActivity.setFont(new Font("SansSerif", Font.PLAIN, 12));
            pnlActivities.add(lblNoActivity);
        } else {
            for (ActivityDTO activity : dashboardData.getRecentActivities()) {
                pnlActivities.add(buatActivityItem(activity));
            }
        }
        
        revalidate();
        repaint();
    }
    
    private JPanel buatStatisticCard(String label, String value, Color accentColor) {
        ModernCard card = new ModernCard(Color.WHITE);
        card.setLayout(new BorderLayout(10, 10));
        card.setBorder(new EmptyBorder(20, 20, 20, 20));
        
        JPanel leftPanel = new JPanel();
        leftPanel.setOpaque(false);
        leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
        
        JLabel lblLabel = new JLabel(label);
        lblLabel.setFont(new Font("SansSerif", Font.PLAIN, 12));
        lblLabel.setForeground(TEXT_LIGHT);
        
        JLabel lblValue = new JLabel(value);
        lblValue.setFont(new Font("SansSerif", Font.BOLD, 32));
        lblValue.setForeground(accentColor);
        
        leftPanel.add(lblLabel);
        leftPanel.add(Box.createVerticalStrut(8));
        leftPanel.add(lblValue);
        
        card.add(leftPanel, BorderLayout.CENTER);
        return card;
    }
    
    private JPanel buatAlertItem(DashboardDTO.AlertDTO alert) {
        JPanel item = new JPanel(new BorderLayout(10, 0));
        item.setBackground(CARD_BG);
        item.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(1, 4, 1, 1, 
                alert.severity == DashboardDTO.AlertDTO.Severity.ERROR ? ERROR :
                alert.severity == DashboardDTO.AlertDTO.Severity.WARNING ? WARNING : PRIMARY),
            new EmptyBorder(12, 12, 12, 12)
        ));
        
        JPanel leftPanel = new JPanel();
        leftPanel.setOpaque(false);
        leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
        
        JLabel lblTitle = new JLabel(alert.title);
        lblTitle.setFont(new Font("SansSerif", Font.BOLD, 12));
        lblTitle.setForeground(TEXT_MAIN);
        
        JLabel lblMessage = new JLabel(alert.message);
        lblMessage.setFont(new Font("SansSerif", Font.PLAIN, 11));
        lblMessage.setForeground(TEXT_LIGHT);
        
        leftPanel.add(lblTitle);
        leftPanel.add(Box.createVerticalStrut(3));
        leftPanel.add(lblMessage);
        
        item.add(leftPanel, BorderLayout.CENTER);
        item.setMaximumSize(new Dimension(Integer.MAX_VALUE, 70));
        
        return item;
    }
    
    private JPanel buatActivityItem(ActivityDTO activity) {
        JPanel item = new JPanel(new BorderLayout(12, 0));
        item.setBackground(CARD_BG);
        item.setBorder(new EmptyBorder(12, 12, 12, 12));
        item.setMaximumSize(new Dimension(Integer.MAX_VALUE, 60));
        
        // Icon
        JLabel lblIcon = new JLabel(activity.icon);
        lblIcon.setFont(new Font("SansSerif", Font.PLAIN, 20));
        
        // Content
        JPanel centerPanel = new JPanel();
        centerPanel.setOpaque(false);
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        
        JLabel lblDetail = new JLabel(activity.detail);
        lblDetail.setFont(new Font("SansSerif", Font.PLAIN, 12));
        lblDetail.setForeground(TEXT_MAIN);
        
        JLabel lblUser = new JLabel(activity.user + " - " + activity.tanggal);
        lblUser.setFont(new Font("SansSerif", Font.PLAIN, 10));
        lblUser.setForeground(TEXT_LIGHT);
        
        centerPanel.add(lblDetail);
        centerPanel.add(Box.createVerticalStrut(2));
        centerPanel.add(lblUser);
        
        item.add(lblIcon, BorderLayout.WEST);
        item.add(centerPanel, BorderLayout.CENTER);
        
        return item;
    }
}
