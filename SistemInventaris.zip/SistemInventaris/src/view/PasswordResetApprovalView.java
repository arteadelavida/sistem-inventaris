package view;

import component.GradientPanel;
import component.RoundedButton;
import controller.PasswordResetController;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.List;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import model.PasswordResetRequest;

/**
 * PasswordResetApprovalView — Admin view untuk approve/reject password reset requests.
 */
public class PasswordResetApprovalView extends JPanel {
    
    // Warna
    private static final Color PRIMARY = new Color(0, 105, 140);
    private static final Color PRIMARY_LIGHT = new Color(0, 188, 212);
    private static final Color DARK = new Color(15, 32, 68);
    private static final Color TEXT_MAIN = new Color(28, 32, 50);
    private static final Color TEXT_LIGHT = new Color(120, 130, 155);
    private static final Color SUCCESS = new Color(76, 175, 80);
    private static final Color ERROR = new Color(244, 67, 54);
    private static final Color WARNING = new Color(255, 193, 7);
    private static final Color FIELD_BG = new Color(248, 250, 253);

    private JTable tblRequests;
    private RoundedButton btnRefresh;
    private RoundedButton btnApprove;
    private RoundedButton btnReject;
    private JLabel lblStatus;
    private PasswordResetController controller;

    public PasswordResetApprovalView() {
        controller = new PasswordResetController();
        buatUI();
    }

    private void buatUI() {
        setLayout(new BorderLayout(15, 15));
        setBorder(new EmptyBorder(20, 20, 20, 20));
        setBackground(Color.WHITE);

        // Header dengan gradient
        JPanel pnlHeader = new GradientPanel(PRIMARY, PRIMARY_LIGHT, GradientPanel.HORIZONTAL, 15);
        pnlHeader.setLayout(new BorderLayout(10, 10));
        pnlHeader.setBorder(new EmptyBorder(20, 20, 20, 20));
        pnlHeader.setPreferredSize(new Dimension(0, 100));

        JLabel lblTitle = new JLabel("Password Reset Requests");
        lblTitle.setFont(new Font("SansSerif", Font.BOLD, 20));
        lblTitle.setForeground(Color.WHITE);

        JLabel lblDesc = new JLabel("Review dan approve/reject permintaan password reset dari user");
        lblDesc.setFont(new Font("SansSerif", Font.PLAIN, 12));
        lblDesc.setForeground(new Color(200, 230, 255));

        JPanel pnlTitleDesc = new JPanel();
        pnlTitleDesc.setOpaque(false);
        pnlTitleDesc.setLayout(new BoxLayout(pnlTitleDesc, BoxLayout.Y_AXIS));
        pnlTitleDesc.add(lblTitle);
        pnlTitleDesc.add(lblDesc);

        btnRefresh = new RoundedButton("🔄 Refresh");
        btnRefresh.setPreferredSize(new Dimension(120, 35));
        btnRefresh.setBackground(new Color(255, 255, 255, 80));
        btnRefresh.setForeground(Color.WHITE);
        btnRefresh.addActionListener(e -> loadRequests());

        pnlHeader.add(pnlTitleDesc, BorderLayout.CENTER);
        pnlHeader.add(btnRefresh, BorderLayout.EAST);

        // Table
        tblRequests = buatTable();
        JScrollPane scrollTable = new JScrollPane(tblRequests);
        scrollTable.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        scrollTable.getViewport().setBackground(Color.WHITE);

        // Bottom panel dengan buttons dan status
        JPanel pnlBottom = new JPanel(new BorderLayout(10, 0));
        pnlBottom.setOpaque(false);

        lblStatus = new JLabel("Memuat data...");
        lblStatus.setFont(new Font("SansSerif", Font.PLAIN, 11));
        lblStatus.setForeground(TEXT_LIGHT);

        JPanel pnlButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        pnlButtons.setOpaque(false);

        btnApprove = new RoundedButton("✓ Setujui");
        btnApprove.setPreferredSize(new Dimension(110, 35));
        btnApprove.setBackground(SUCCESS);
        btnApprove.setForeground(Color.WHITE);
        btnApprove.addActionListener(e -> approveSelected());

        btnReject = new RoundedButton("✗ Tolak");
        btnReject.setPreferredSize(new Dimension(110, 35));
        btnReject.setBackground(ERROR);
        btnReject.setForeground(Color.WHITE);
        btnReject.addActionListener(e -> rejectSelected());

        pnlButtons.add(btnApprove);
        pnlButtons.add(btnReject);

        pnlBottom.add(lblStatus, BorderLayout.WEST);
        pnlBottom.add(pnlButtons, BorderLayout.EAST);

        // Assemble
        add(pnlHeader, BorderLayout.NORTH);
        add(scrollTable, BorderLayout.CENTER);
        add(pnlBottom, BorderLayout.SOUTH);

        // Load data
        loadRequests();
    }

    private JTable buatTable() {
        DefaultTableModel model = new DefaultTableModel(
            new String[]{"Username", "Email", "Alasan", "Tanggal Request", "Status"}, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        JTable table = new JTable(model);
        table.setFont(new Font("SansSerif", Font.PLAIN, 11));
        table.setRowHeight(25);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setGridColor(new Color(230, 230, 230));

        JTableHeader header = table.getTableHeader();
        header.setBackground(PRIMARY);
        header.setForeground(Color.WHITE);
        header.setFont(new Font("SansSerif", Font.BOLD, 11));
        header.setPreferredSize(new Dimension(0, 30));

        table.getColumnModel().getColumn(0).setPreferredWidth(100);
        table.getColumnModel().getColumn(1).setPreferredWidth(150);
        table.getColumnModel().getColumn(2).setPreferredWidth(250);
        table.getColumnModel().getColumn(3).setPreferredWidth(120);
        table.getColumnModel().getColumn(4).setPreferredWidth(80);

        return table;
    }

    private void loadRequests() {
        DefaultTableModel model = (DefaultTableModel) tblRequests.getModel();
        model.setRowCount(0);

        List<PasswordResetRequest> requests = controller.getPendingRequests();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");

        for (PasswordResetRequest req : requests) {
            model.addRow(new Object[]{
                req.getUsername(),
                req.getEmail() != null ? req.getEmail() : "-",
                req.getReason().length() > 50 ? req.getReason().substring(0, 50) + "..." : req.getReason(),
                sdf.format(java.sql.Timestamp.valueOf(req.getCreatedAt())),
                req.getStatus()
            });
        }

        if (requests.isEmpty()) {
            lblStatus.setText("✓ Tidak ada request yang pending");
            lblStatus.setForeground(SUCCESS);
        } else {
            lblStatus.setText(requests.size() + " request menunggu persetujuan");
            lblStatus.setForeground(WARNING);
        }
    }

    private void approveSelected() {
        int selectedRow = tblRequests.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this, "Pilih request yang ingin disetujui!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String username = (String) tblRequests.getValueAt(selectedRow, 0);
        List<PasswordResetRequest> requests = controller.getPendingRequests();
        PasswordResetRequest selected = requests.stream()
            .filter(r -> r.getUsername().equals(username))
            .findFirst()
            .orElse(null);

        if (selected == null) return;

        // Dialog untuk password baru
        JPanel pnlInput = new JPanel(new GridLayout(2, 2, 10, 10));
        pnlInput.setBorder(new EmptyBorder(10, 10, 10, 10));

        JLabel lblPass = new JLabel("Password Baru:");
        JPasswordField fldPass = new JPasswordField(20);

        JLabel lblConfirm = new JLabel("Konfirmasi:");
        JPasswordField fldConfirm = new JPasswordField(20);

        pnlInput.add(lblPass);
        pnlInput.add(fldPass);
        pnlInput.add(lblConfirm);
        pnlInput.add(fldConfirm);

        int result = JOptionPane.showConfirmDialog(this, pnlInput, 
            "Set Password Baru untuk: " + username, JOptionPane.OK_CANCEL_OPTION);

        if (result == JOptionPane.OK_OPTION) {
            String pass1 = new String(fldPass.getPassword());
            String pass2 = new String(fldConfirm.getPassword());

            if (pass1.isEmpty() || pass2.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Password tidak boleh kosong!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (!pass1.equals(pass2)) {
                JOptionPane.showMessageDialog(this, "Password tidak cocok!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (controller.approveAndSetPassword(selected.getId(), "admin", pass1)) {
                JOptionPane.showMessageDialog(this, "✓ Request disetujui dan password diubah!", "Sukses", JOptionPane.INFORMATION_MESSAGE);
                loadRequests();
            } else {
                JOptionPane.showMessageDialog(this, "✗ Gagal memproses request!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void rejectSelected() {
        int selectedRow = tblRequests.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this, "Pilih request yang ingin ditolak!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String username = (String) tblRequests.getValueAt(selectedRow, 0);
        List<PasswordResetRequest> requests = controller.getPendingRequests();
        PasswordResetRequest selected = requests.stream()
            .filter(r -> r.getUsername().equals(username))
            .findFirst()
            .orElse(null);

        if (selected == null) return;

        int confirm = JOptionPane.showConfirmDialog(this, 
            "Yakin menolak request dari " + username + "?", 
            "Konfirmasi", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            if (controller.rejectRequest(selected.getId(), "admin")) {
                JOptionPane.showMessageDialog(this, "✓ Request ditolak!", "Sukses", JOptionPane.INFORMATION_MESSAGE);
                loadRequests();
            } else {
                JOptionPane.showMessageDialog(this, "✗ Gagal menolak request!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}
