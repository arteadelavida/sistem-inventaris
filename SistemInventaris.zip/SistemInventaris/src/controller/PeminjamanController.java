package controller;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.LogBarang;
import model.Peminjaman;
import util.DatabaseUtil;
import util.LogService;

/**
 * PeminjamanController — CRUD tabel peminjaman.
 * Tabel dibuat otomatis dengan kolom tanggal_pinjam, tanggal_kembali, keterangan_admin.
 * Saat disetujui: stok dikurangi atomik + log KELUAR dicatat.
 */
public class PeminjamanController {

    private final LogBarangController logCtrl = new LogBarangController();

    public PeminjamanController() {
        ensureTable();
    }

    // ── DDL ───────────────────────────────────────────────────────

    private void ensureTable() {
        String sql =
            "CREATE TABLE IF NOT EXISTS peminjaman (" +
            "  id               INT AUTO_INCREMENT PRIMARY KEY," +
            "  username         VARCHAR(100) NOT NULL," +
            "  kode_barang      VARCHAR(50)  NOT NULL," +
            "  nama_barang      VARCHAR(150) NOT NULL DEFAULT ''," +
            "  jumlah           INT          NOT NULL DEFAULT 1," +
            "  tanggal_pinjam   DATE         NOT NULL," +
            "  tanggal_kembali  DATE         NOT NULL," +
            "  status           VARCHAR(20)  NOT NULL DEFAULT 'pending'," +
            "  keterangan_admin VARCHAR(255)          DEFAULT '-'" +
            ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
        try (Connection c = DatabaseUtil.getInventarisConnection();
             Statement  s = c.createStatement()) {
            s.execute(sql);
        } catch (SQLException e) {
            System.err.println("[PeminjamanController] ensureTable: " + e.getMessage());
        }
    }

    // ── User ajukan ───────────────────────────────────────────────

    public void ajukanPeminjaman(Peminjaman p) throws SQLException {
        String sql = "INSERT INTO peminjaman " +
                     "(username, kode_barang, nama_barang, jumlah, " +
                     " tanggal_pinjam, tanggal_kembali, status, keterangan_admin) " +
                     "VALUES (?,?,?,?,?,?,?,?)";
        try (Connection c = DatabaseUtil.getInventarisConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, p.getUsername());
            ps.setString(2, p.getKodeBarang());
            ps.setString(3, p.getNamaBarang() != null ? p.getNamaBarang() : "");
            ps.setInt   (4, p.getJumlah());
            ps.setDate  (5, Date.valueOf(p.getTanggalPinjam()));
            ps.setDate  (6, Date.valueOf(p.getTanggalKembali()));
            ps.setString(7, "pending");
            ps.setString(8, "-");
            ps.executeUpdate();
        }
        LogService.catat("PINJAM", p.getUsername() + " ajukan pinjam " +
            p.getJumlah() + "× " + p.getKodeBarang());
    }

    // ── Admin lihat semua pending ─────────────────────────────────

    public List<Peminjaman> getPending() throws SQLException {
        return getByStatus("pending");
    }

    /** Semua peminjaman tanpa filter status — untuk statistik & chart. */
    public List<Peminjaman> getAllPeminjaman() throws SQLException {
        List<Peminjaman> list = new ArrayList<>();
        String sql = "SELECT * FROM peminjaman ORDER BY tanggal_pinjam DESC";
        try (Connection c = DatabaseUtil.getInventarisConnection();
             Statement  s = c.createStatement();
             ResultSet rs = s.executeQuery(sql)) {
            while (rs.next()) list.add(mapRow(rs));
        }
        return list;
    }

    /** Hanya yang berstatus disetujui — untuk hitung barang sedang dipinjam. */
    public List<Peminjaman> getDisetujui() throws SQLException {
        return getByStatus("disetujui");
    }

    // ── Admin setujui + kurangi stok atomik ───────────────────────

    public void setujuiDenganKeterangan(int id, String keterangan) throws SQLException {
        Peminjaman p = getById(id);
        if (p == null) throw new SQLException("Peminjaman #" + id + " tidak ditemukan.");
        if (keterangan == null || keterangan.trim().isEmpty()) keterangan = "-";

        Connection c = DatabaseUtil.getInventarisConnection();
        try {
            c.setAutoCommit(false);
            try {
                // Kurangi stok — gagal jika tidak cukup
                try (PreparedStatement ps = c.prepareStatement(
                        "UPDATE barang SET stok = stok - ? " +
                        "WHERE kode_barang=? AND stok >= ?")) {
                    ps.setInt   (1, p.getJumlah());
                    ps.setString(2, p.getKodeBarang());
                    ps.setInt   (3, p.getJumlah());
                    if (ps.executeUpdate() == 0)
                        throw new SQLException("Stok '" + p.getNamaBarang() +
                            "' tidak cukup (diperlukan: " + p.getJumlah() + ").");
                }
                // Update status + keterangan
                try (PreparedStatement ps = c.prepareStatement(
                        "UPDATE peminjaman SET status='disetujui', keterangan_admin=? WHERE id=?")) {
                    ps.setString(1, keterangan);
                    ps.setInt   (2, id);
                    ps.executeUpdate();
                }
                c.commit();
            } catch (SQLException e) {
                c.rollback();
                throw e;
            } finally {
                c.setAutoCommit(true);
            }
        } finally {
            c.close();
        }
        // Log keluar (di luar transaksi)
        logCtrl.catat(new LogBarang(p.getKodeBarang(), p.getNamaBarang(),
            "KELUAR", p.getJumlah(),
            "Peminjaman #" + id + " oleh " + p.getUsername() + " — " + keterangan,
            "admin"));
        LogService.catat("SETUJUI_PINJAM",
            "Peminjaman #" + id + " disetujui, stok -" + p.getJumlah());
    }

    /** Shortcut tanpa keterangan */
    public void setujui(int id) throws SQLException {
        setujuiDenganKeterangan(id, "-");
    }

    // ── Admin tolak ───────────────────────────────────────────────

    public void tolakDenganKeterangan(int id, String keterangan) throws SQLException {
        if (keterangan == null || keterangan.trim().isEmpty()) keterangan = "-";
        String sql = "UPDATE peminjaman SET status='ditolak', keterangan_admin=? WHERE id=?";
        try (Connection c = DatabaseUtil.getInventarisConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, keterangan);
            ps.setInt   (2, id);
            ps.executeUpdate();
        }
        LogService.catat("TOLAK_PINJAM", "Peminjaman #" + id + " ditolak");
    }

    public void tolak(int id) throws SQLException {
        tolakDenganKeterangan(id, "-");
    }

    // ── User riwayat ──────────────────────────────────────────────

    public List<Peminjaman> getByUser(String username) throws SQLException {
        List<Peminjaman> list = new ArrayList<>();
        String sql = "SELECT * FROM peminjaman WHERE username=? ORDER BY tanggal_pinjam DESC";
        try (Connection c = DatabaseUtil.getInventarisConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
        }
        return list;
    }

    /**
     * Dapatkan peminjaman berdasarkan ID (public).
     */
    public Peminjaman getById(int id) throws SQLException {
        String sql = "SELECT * FROM peminjaman WHERE id=?";
        try (Connection c = DatabaseUtil.getInventarisConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        }
        return null;
    }

    // ── Stat ─────────────────────────────────────────────────────

    public int countPending() {
        try { return getPending().size(); } catch (SQLException e) { return 0; }
    }

    // ── Helpers ───────────────────────────────────────────────────

    private List<Peminjaman> getByStatus(String status) throws SQLException {
        List<Peminjaman> list = new ArrayList<>();
        String sql = "SELECT * FROM peminjaman WHERE status=? ORDER BY tanggal_pinjam DESC";
        try (Connection c = DatabaseUtil.getInventarisConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, status);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
        }
        return list;
    }

    private Peminjaman mapRow(ResultSet rs) throws SQLException {
        Peminjaman p = new Peminjaman(
            rs.getString("username"),
            rs.getString("kode_barang"),
            rs.getString("nama_barang"),
            rs.getInt   ("jumlah"),
            rs.getDate  ("tanggal_kembali").toLocalDate()
        );
        p.setId(rs.getInt("id"));
        p.setTanggalPinjam(rs.getDate("tanggal_pinjam").toLocalDate());
        p.setStatus(rs.getString("status"));
        String ket = rs.getString("keterangan_admin");
        p.setKeteranganAdmin(ket != null ? ket : "-");
        // Map status_return from database
        String statusReturn = rs.getString("status_return");
        p.setStatusReturn(statusReturn != null ? statusReturn : "belum_dikembalikan");
        return p;
    }
}
