package controller;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.LogBarang;
import util.DatabaseUtil;

/**
 * LogBarangController — catat dan baca log pergerakan barang.
 * Tabel dibuat otomatis. Kolom: tipe_aksi (MASUK | KELUAR).
 */
public class LogBarangController {

    public LogBarangController() {
        ensureTable();
    }

    // ── DDL ───────────────────────────────────────────────────────

    private void ensureTable() {
        String sql =
            "CREATE TABLE IF NOT EXISTS log_barang (" +
            "  id          INT AUTO_INCREMENT PRIMARY KEY," +
            "  kode_barang VARCHAR(50)  NOT NULL," +
            "  nama_barang VARCHAR(150) NOT NULL DEFAULT ''," +
            "  tipe_aksi   VARCHAR(20)  NOT NULL," +
            "  jumlah      INT          NOT NULL DEFAULT 0," +
            "  keterangan  TEXT," +
            "  username    VARCHAR(100) NOT NULL DEFAULT ''," +
            "  tanggal     DATETIME     DEFAULT CURRENT_TIMESTAMP" +
            ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
        try (Connection c = DatabaseUtil.getInventarisConnection();
             Statement  s = c.createStatement()) {
            s.execute(sql);
        } catch (SQLException e) {
            System.err.println("[LogBarangController] ensureTable: " + e.getMessage());
        }
    }

    // ── WRITE ─────────────────────────────────────────────────────

    /**
     * Catat satu log. Bisa dipanggil sebagai catatLog() atau catat().
     * Silent — tidak lempar exception ke caller.
     */
    public void catatLog(LogBarang log) {
        catat(log);
    }

    public void catat(LogBarang log) {
        String sql = "INSERT INTO log_barang " +
                     "(kode_barang, nama_barang, tipe_aksi, jumlah, keterangan, username) " +
                     "VALUES (?,?,?,?,?,?)";
        try (Connection c = DatabaseUtil.getInventarisConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, log.getKodeBarang());
            ps.setString(2, log.getNamaBarang());
            ps.setString(3, log.getTipeAksi());
            ps.setInt   (4, log.getJumlah());
            ps.setString(5, log.getKeterangan());
            ps.setString(6, log.getUsername());
            ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println("[LogBarangController] Gagal catat: " + e.getMessage());
        }
    }

    // ── READ ──────────────────────────────────────────────────────

    public List<LogBarang> getAll() throws SQLException {
        return query("SELECT * FROM log_barang ORDER BY tanggal DESC");
    }

    public List<LogBarang> getByTipeAksi(String tipe) throws SQLException {
        List<LogBarang> list = new ArrayList<>();
        String sql = "SELECT * FROM log_barang WHERE tipe_aksi=? ORDER BY tanggal DESC";
        try (Connection c = DatabaseUtil.getInventarisConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, tipe);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
        }
        return list;
    }

    public List<LogBarang> getByKodeBarang(String kode) throws SQLException {
        List<LogBarang> list = new ArrayList<>();
        String sql = "SELECT * FROM log_barang WHERE kode_barang=? ORDER BY tanggal DESC";
        try (Connection c = DatabaseUtil.getInventarisConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, kode);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
        }
        return list;
    }

    // ── Helpers ───────────────────────────────────────────────────

    private List<LogBarang> query(String sql) throws SQLException {
        List<LogBarang> list = new ArrayList<>();
        try (Connection c = DatabaseUtil.getInventarisConnection();
             Statement  s = c.createStatement();
             ResultSet rs = s.executeQuery(sql)) {
            while (rs.next()) list.add(mapRow(rs));
        }
        return list;
    }

    private LogBarang mapRow(ResultSet rs) throws SQLException {
        LogBarang log = new LogBarang(
            rs.getString("kode_barang"),
            rs.getString("nama_barang"),
            rs.getString("tipe_aksi"),
            rs.getInt   ("jumlah"),
            rs.getString("keterangan"),
            rs.getString("username")
        );
        log.setId(rs.getInt("id"));
        Timestamp ts = rs.getTimestamp("tanggal");
        if (ts != null) log.setTanggal(ts.toLocalDateTime());
        return log;
    }
}
