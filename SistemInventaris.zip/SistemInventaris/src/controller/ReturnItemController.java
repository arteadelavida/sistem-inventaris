package controller;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.ReturnItem;
import util.DatabaseUtil;

/**
 * ReturnItemController — Mengelola pengembalian barang pinjaman.
 * User/Admin bisa record pengembalian, admin harus approve.
 */
public class ReturnItemController {

    /**
     * Request pengembalian barang.
     * @param peminjamanId ID peminjaman
     * @param username username yang mengembalikan
     * @param jumlahDikembalikan jumlah barang
     * @param kondisiBarang "baik" / "rusak ringan" / "rusak berat" / "hilang"
     * @param keterangan keterangan tambahan
     * @return ID return request jika berhasil, -1 jika gagal
     */
    public int createReturnRequest(int peminjamanId, String username, int jumlahDikembalikan,
                                   String kondisiBarang, String keterangan) {
        
        // Dapatkan data peminjaman
        String sqlGetPeminjaman = "SELECT kode_barang, nama_barang FROM peminjaman WHERE id = ?";
        String kodeBarang = null;
        String namaBarang = null;
        
        try (Connection conn = DatabaseUtil.getInventarisConnection();
             PreparedStatement ps = conn.prepareStatement(sqlGetPeminjaman)) {
            
            ps.setInt(1, peminjamanId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    kodeBarang = rs.getString("kode_barang");
                    namaBarang = rs.getString("nama_barang");
                    System.out.println("DEBUG: Found peminjaman - kodeBarang=" + kodeBarang + ", namaBarang=" + namaBarang);
                } else {
                    System.out.println("DEBUG: No peminjaman found with ID: " + peminjamanId);
                    return -1;
                }
            }
        } catch (SQLException e) {
            System.out.println("DEBUG: Error querying peminjaman: " + e.getMessage());
            e.printStackTrace();
            return -1;
        }
        
        if (kodeBarang == null || kodeBarang.trim().isEmpty()) {
            System.out.println("DEBUG: kodeBarang is null or empty!");
            return -1;
        }
        
        // Insert return request
        String sql = "INSERT INTO return_items (peminjaman_id, username, kode_barang, nama_barang, " +
                     "jumlah_dikembalikan, tanggal_return, kondisi_barang, keterangan, status, created_at) " +
                     "VALUES (?, ?, ?, ?, ?, CURDATE(), ?, ?, 'pending', NOW())";
        
        try (Connection conn = DatabaseUtil.getInventarisConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            ps.setInt(1, peminjamanId);
            ps.setString(2, username);
            ps.setString(3, kodeBarang);
            ps.setString(4, namaBarang);
            ps.setInt(5, jumlahDikembalikan);
            ps.setString(6, kondisiBarang);
            ps.setString(7, keterangan);
            
            System.out.println("DEBUG: Executing insert return request for peminjaman=" + peminjamanId);
            int affected = ps.executeUpdate();
            if (affected > 0) {
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if (rs.next()) {
                        int returnId = rs.getInt(1);
                        System.out.println("DEBUG: Return request created with ID: " + returnId);
                        return returnId;
                    }
                }
            }
            
        } catch (SQLException e) {
            System.out.println("DEBUG: Error inserting return request: " + e.getMessage());
            e.printStackTrace();
        }
        
        return -1;
    }

    /**
     * Dapatkan semua return request yang pending (untuk admin review).
     */
    public List<ReturnItem> getPendingReturnRequests() {
        List<ReturnItem> list = new ArrayList<>();
        String sql = "SELECT id, peminjaman_id, username, kode_barang, nama_barang, jumlah_dikembalikan, " +
                     "tanggal_return, kondisi_barang, keterangan, status, disetujui_oleh, " +
                     "tanggal_disetujui, created_at FROM return_items WHERE status = 'pending' " +
                     "ORDER BY created_at DESC";
        
        try (Connection conn = DatabaseUtil.getInventarisConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                ReturnItem item = new ReturnItem(
                    rs.getInt("peminjaman_id"),
                    rs.getString("username"),
                    rs.getString("kode_barang"),
                    rs.getString("nama_barang"),
                    rs.getInt("jumlah_dikembalikan"),
                    rs.getDate("tanggal_return").toLocalDate(),
                    rs.getString("kondisi_barang"),
                    rs.getString("keterangan")
                );
                item.setId(rs.getInt("id"));
                item.setStatus(rs.getString("status"));
                
                list.add(item);
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return list;
    }

    /**
     * Dapatkan return request berdasarkan ID.
     */
    public ReturnItem getReturnItemById(int id) {
        String sql = "SELECT id, peminjaman_id, username, kode_barang, nama_barang, jumlah_dikembalikan, " +
                     "tanggal_return, kondisi_barang, keterangan, status, disetujui_oleh, " +
                     "tanggal_disetujui, created_at FROM return_items WHERE id = ?";
        
        try (Connection conn = DatabaseUtil.getInventarisConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    ReturnItem item = new ReturnItem(
                        rs.getInt("peminjaman_id"),
                        rs.getString("username"),
                        rs.getString("kode_barang"),
                        rs.getString("nama_barang"),
                        rs.getInt("jumlah_dikembalikan"),
                        rs.getDate("tanggal_return").toLocalDate(),
                        rs.getString("kondisi_barang"),
                        rs.getString("keterangan")
                    );
                    item.setId(rs.getInt("id"));
                    item.setStatus(rs.getString("status"));
                    
                    return item;
                }
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return null;
    }

    /**
     * Approve pengembalian barang.
     * @param returnItemId ID return item
     * @param adminUsername username admin yang approve
     * @return true jika berhasil
     */
    public boolean approveReturn(int returnItemId, String adminUsername) {
        Connection conn = null;
        try {
            conn = DatabaseUtil.getInventarisConnection();
            conn.setAutoCommit(false);
            
            // Get return item data
            ReturnItem item = getReturnItemById(returnItemId);
            if (item == null || !item.getStatus().equals("pending")) {
                conn.rollback();
                return false;
            }
            
            // Update return item status
            String sqlUpdateReturn = "UPDATE return_items SET status = 'approved', disetujui_oleh = ?, " +
                                    "tanggal_disetujui = NOW() WHERE id = ?";
            try (PreparedStatement ps = conn.prepareStatement(sqlUpdateReturn)) {
                ps.setString(1, adminUsername);
                ps.setInt(2, returnItemId);
                ps.executeUpdate();
            }
            
            // Update peminjaman status_return
            String sqlUpdatePeminjaman = "UPDATE peminjaman SET status_return = 'dikembalikan', " +
                                        "tanggal_kembali_aktual = CURDATE() WHERE id = ?";
            try (PreparedStatement ps = conn.prepareStatement(sqlUpdatePeminjaman)) {
                ps.setInt(1, item.getPeminjamanId());
                ps.executeUpdate();
            }
            
            // Update stok barang (untuk semua kondisi - bukan hanya baik)
            String sqlUpdateStok = "UPDATE barang SET stok = stok + ? WHERE kode_barang = ?";
            try (PreparedStatement ps = conn.prepareStatement(sqlUpdateStok)) {
                ps.setInt(1, item.getJumlahDikembalikan());
                ps.setString(2, item.getKodeBarang());
                ps.executeUpdate();
            }
            
            conn.commit();
            return true;
            
        } catch (SQLException e) {
            try {
                if (conn != null) conn.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
            return false;
        } finally {
            try {
                if (conn != null) {
                    conn.setAutoCommit(true);
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Reject pengembalian barang.
     */
    public boolean rejectReturn(int returnItemId) {
        String sql = "UPDATE return_items SET status = 'rejected' WHERE id = ? AND status = 'pending'";
        
        try (Connection conn = DatabaseUtil.getInventarisConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, returnItemId);
            return ps.executeUpdate() > 0;
            
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Dapatkan return history untuk user tertentu.
     */
    public List<ReturnItem> getUserReturnHistory(String username) {
        List<ReturnItem> list = new ArrayList<>();
        String sql = "SELECT id, peminjaman_id, username, kode_barang, nama_barang, jumlah_dikembalikan, " +
                     "tanggal_return, kondisi_barang, keterangan, status, disetujui_oleh, " +
                     "tanggal_disetujui, created_at FROM return_items WHERE username = ? " +
                     "ORDER BY tanggal_return DESC";
        
        try (Connection conn = DatabaseUtil.getInventarisConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    ReturnItem item = new ReturnItem(
                        rs.getInt("peminjaman_id"),
                        rs.getString("username"),
                        rs.getString("kode_barang"),
                        rs.getString("nama_barang"),
                        rs.getInt("jumlah_dikembalikan"),
                        rs.getDate("tanggal_return").toLocalDate(),
                        rs.getString("kondisi_barang"),
                        rs.getString("keterangan")
                    );
                    item.setId(rs.getInt("id"));
                    item.setStatus(rs.getString("status"));
                    
                    list.add(item);
                }
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return list;
    }
}
