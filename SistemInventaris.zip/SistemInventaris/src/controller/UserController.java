package controller;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.User;
import util.DatabaseUtil;
import util.LogService;

/**
 * UserController menangani manajemen user:
 * menampilkan daftar akun pending dan menyetujuinya.
 */
public class UserController {

    /**
     * Mengambil semua user dengan status 'pending'.
     */
    public List<User> getPendingUsers() throws SQLException {
        List<User> list = new ArrayList<>();
        String sql = "SELECT id, username, role, status FROM users WHERE status = 'pending'";

        try (Connection conn = DatabaseUtil.getLoginConnection();
             Statement stmt  = conn.createStatement();
             ResultSet rs    = stmt.executeQuery(sql)) {

            while (rs.next()) {
                list.add(new User(
                    rs.getInt   ("id"),
                    rs.getString("username"),
                    rs.getString("role"),
                    rs.getString("status")
                ));
            }
        }
        return list;
    }

    /**
     * Menyetujui akun user (mengubah status dari 'pending' ke 'active').
     * @param username target user yang disetujui
     */
    public void setujuiAkun(String username) throws SQLException {
        String sql = "UPDATE users SET status = 'active' WHERE username = ?";

        try (Connection conn = DatabaseUtil.getLoginConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, username);
            int rows = ps.executeUpdate();

            if (rows > 0) {
                LogService.catat("APPROVE_USER", "Akun '" + username + "' disetujui");
            }
        }
    }

    /**
     * Menolak / menghapus akun user.
     * @param username target user yang ditolak
     */
    public void tolakAkun(String username) throws SQLException {
        String sql = "DELETE FROM users WHERE username = ? AND status = 'pending'";

        try (Connection conn = DatabaseUtil.getLoginConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, username);
            ps.executeUpdate();

            LogService.catat("REJECT_USER", "Akun '" + username + "' ditolak/dihapus");
        }
    }
}
