package controller;

import java.sql.*;
import model.User;
import util.DatabaseUtil;
import util.LogService;
import util.SessionManager;

/**
 * AuthController menangani autentikasi: login dan registrasi user.
 */
public class AuthController {

    // ─────────────────────────────────────────────────────────────
    // LOGIN
    // ─────────────────────────────────────────────────────────────

    /**
     * Memvalidasi kredensial user.
     * @return User yang berhasil login, atau null jika gagal.
     * @throws SQLException jika ada masalah database
     * @throws PendingAccountException jika akun belum disetujui admin
     */
    public User login(String username, String password)
            throws SQLException, PendingAccountException {

        String sql = "SELECT * FROM users WHERE username = ? AND password = ?";

        try (Connection conn = DatabaseUtil.getLoginConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, username);
            ps.setString(2, password);

            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    return null; // Username atau password salah
                }

                String status = rs.getString("status");
                if ("pending".equalsIgnoreCase(status)) {
                    throw new PendingAccountException(
                        "Akun Anda belum disetujui oleh Admin. Mohon tunggu persetujuan.");
                }

                User user = new User();
                user.setId(rs.getInt("id"));
                user.setUsername(rs.getString("username"));
                user.setRole(rs.getString("role"));
                user.setStatus(status);

                // Simpan ke session global
                SessionManager.login(user.getUsername(), user.getRole());
                LogService.catat("LOGIN", "User berhasil login dengan role: " + user.getRole());

                return user;
            }
        }
    }

    // ─────────────────────────────────────────────────────────────
    // REGISTER
    // ─────────────────────────────────────────────────────────────

    /**
     * Mendaftarkan user baru.
     * @throws SQLException jika ada masalah database
     * @throws DuplicateUsernameException jika username sudah terpakai
     */
    public void register(String username, String password, String role)
            throws SQLException, DuplicateUsernameException {

        // 1. Cek username duplikat
        if (isUsernameTaken(username)) {
            throw new DuplicateUsernameException("Username '" + username + "' sudah terpakai!");
        }

        // 2. Simpan user baru dengan status 'pending'
        String sql = "INSERT INTO users (username, password, role, status) VALUES (?, ?, ?, 'pending')";

        try (Connection conn = DatabaseUtil.getLoginConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, username);
            ps.setString(2, password);
            ps.setString(3, role.toLowerCase());
            ps.executeUpdate();
        }
    }

    private boolean isUsernameTaken(String username) throws SQLException {
        String sql = "SELECT id FROM users WHERE username = ?";

        try (Connection conn = DatabaseUtil.getLoginConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    // ─────────────────────────────────────────────────────────────
    // FORGOT PASSWORD
    // ─────────────────────────────────────────────────────────────

    /**
     * Mencari user berdasarkan username.
     * @return User jika ditemukan, null jika tidak ada
     */
    public User cariUser(String username) throws SQLException {
        String sql = "SELECT * FROM users WHERE username = ?";

        try (Connection conn = DatabaseUtil.getLoginConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) return null;

                User user = new User();
                user.setId(rs.getInt("id"));
                user.setUsername(rs.getString("username"));
                user.setRole(rs.getString("role"));
                user.setStatus(rs.getString("status"));
                return user;
            }
        }
    }

    /**
     * Reset password user (update ke password baru).
     * Biasanya dipanggil setelah email verification.
     */
    public void resetPassword(String username, String passwordBaru) throws SQLException {
        String sql = "UPDATE users SET password = ? WHERE username = ?";

        try (Connection conn = DatabaseUtil.getLoginConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, passwordBaru);
            ps.setString(2, username);
            ps.executeUpdate();
            LogService.catat("PASSWORD_RESET", "Password reset untuk user: " + username);
        }
    }

    // ─────────────────────────────────────────────────────────────

    public static class PendingAccountException extends Exception {
        public PendingAccountException(String msg) { super(msg); }
    }

    public static class DuplicateUsernameException extends Exception {
        public DuplicateUsernameException(String msg) { super(msg); }
    }
}
