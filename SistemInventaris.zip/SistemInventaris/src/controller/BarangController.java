package controller;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Barang;
import model.LogBarang;
import util.DatabaseUtil;
import util.LogService;
import util.SessionManager;

/**
 * BarangController — semua operasi CRUD tabel barang.
 * Setiap mutasi stok dicatat ke log_barang (MASUK/KELUAR).
 */
public class BarangController {

    private final LogBarangController logCtrl = new LogBarangController();

    // ── READ ──────────────────────────────────────────────────────

    public List<Barang> getAllBarang() throws SQLException {
        List<Barang> list = new ArrayList<>();
        String sql = "SELECT * FROM barang ORDER BY kode_barang";
        try (Connection c = DatabaseUtil.getInventarisConnection();
             Statement  s = c.createStatement();
             ResultSet rs = s.executeQuery(sql)) {
            while (rs.next()) list.add(mapRow(rs));
        }
        return list;
    }

    public Barang getBarangByKode(String kode) throws SQLException {
        String sql = "SELECT * FROM barang WHERE kode_barang=?";
        try (Connection c = DatabaseUtil.getInventarisConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            ps.setString(1, kode);
            if (rs.next()) return mapRow(rs);
        }
        return null;
    }

    // ── CREATE ────────────────────────────────────────────────────

    public void tambahBarang(Barang b) throws SQLException {
        String sql = "INSERT INTO barang (kode_barang, nama_barang, harga, stok, keterangan) " +
                     "VALUES (?,?,?,?,?)";
        try (Connection c = DatabaseUtil.getInventarisConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, b.getKodeBarang());
            ps.setString(2, b.getNamaBarang());
            ps.setInt   (3, b.getHarga());
            ps.setInt   (4, b.getStok());
            ps.setString(5, b.getKeterangan() != null ? b.getKeterangan() : "");
            ps.executeUpdate();
        }
        LogService.catat("TAMBAH", b.getKodeBarang() + " - " + b.getNamaBarang());
        if (b.getStok() > 0) {
            logCtrl.catat(new LogBarang(b.getKodeBarang(), b.getNamaBarang(),
                "MASUK", b.getStok(), "Barang baru ditambahkan", user()));
        }
    }

    // ── UPDATE ────────────────────────────────────────────────────

    public void updateBarang(Barang b) throws SQLException {
        // Ambil stok lama untuk log selisih
        Barang lama = getBarangByKode(b.getKodeBarang());
        int stokLama = (lama != null) ? lama.getStok() : 0;

        String sql = "UPDATE barang SET nama_barang=?, harga=?, stok=?, keterangan=? " +
                     "WHERE kode_barang=?";
        try (Connection c = DatabaseUtil.getInventarisConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, b.getNamaBarang());
            ps.setInt   (2, b.getHarga());
            ps.setInt   (3, b.getStok());
            ps.setString(4, b.getKeterangan() != null ? b.getKeterangan() : "");
            ps.setString(5, b.getKodeBarang());
            int affected = ps.executeUpdate();
            if (affected == 0)
                throw new SQLException("Barang '" + b.getKodeBarang() + "' tidak ditemukan.");
        }
        LogService.catat("UPDATE", b.getKodeBarang() + " - " + b.getNamaBarang());

        int delta = b.getStok() - stokLama;
        if (delta > 0) {
            logCtrl.catat(new LogBarang(b.getKodeBarang(), b.getNamaBarang(),
                "MASUK", delta, "Penyesuaian stok (+) oleh admin", user()));
        } else if (delta < 0) {
            logCtrl.catat(new LogBarang(b.getKodeBarang(), b.getNamaBarang(),
                "KELUAR", Math.abs(delta), "Penyesuaian stok (-) oleh admin", user()));
        }
    }

    // ── DELETE ────────────────────────────────────────────────────

    public void hapusBarang(String kode) throws SQLException {
        Barang b    = getBarangByKode(kode);
        String nama = (b != null) ? b.getNamaBarang() : kode;
        int    stok = (b != null) ? b.getStok() : 0;

        String sql = "DELETE FROM barang WHERE kode_barang=?";
        try (Connection c = DatabaseUtil.getInventarisConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, kode);
            int affected = ps.executeUpdate();
            if (affected == 0)
                throw new SQLException("Barang '" + kode + "' tidak ditemukan.");
        }
        LogService.catat("HAPUS", kode + " - " + nama);
        if (stok > 0) {
            logCtrl.catat(new LogBarang(kode, nama,
                "KELUAR", stok, "Barang dihapus dari inventaris", user()));
        }
    }

    // ── TAMBAH MASUK (barang restok manual) ───────────────────────

    public void tambahMasukBarang(String kode, int jumlah, String keterangan) throws SQLException {
        Barang b = getBarangByKode(kode);
        if (b == null) throw new SQLException("Barang '" + kode + "' tidak ditemukan.");

        String sql = "UPDATE barang SET stok = stok + ? WHERE kode_barang=?";
        try (Connection c = DatabaseUtil.getInventarisConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt   (1, jumlah);
            ps.setString(2, kode);
            ps.executeUpdate();
        }
        logCtrl.catat(new LogBarang(kode, b.getNamaBarang(),
            "MASUK", jumlah, keterangan != null ? keterangan : "Restok manual", user()));
        LogService.catat("RESTOK", kode + " +" + jumlah);
    }

    // ── HELPERS ───────────────────────────────────────────────────

    private String user() {
        String u = SessionManager.getUsername();
        return (u != null) ? u : "system";
    }

    private Barang mapRow(ResultSet rs) throws SQLException {
        return new Barang(
            rs.getString("kode_barang"),
            rs.getString("nama_barang"),
            rs.getInt   ("harga"),
            rs.getInt   ("stok"),
            rs.getString("keterangan")
        );
    }
}
