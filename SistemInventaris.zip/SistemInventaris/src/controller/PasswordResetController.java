package controller;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import model.PasswordResetRequest;
import util.DatabaseUtil;

/**
 * PasswordResetController — Mengelola permintaan password reset dengan approval admin.
 * User bisa request reset password, admin harus approve/reject.
 */
public class PasswordResetController {

    /**
     * Request password reset dari user.
     * @param username username yang request
     * @param email email user (tidak digunakan - untuk kompatibilitas)
     * @param reason alasan lupa password
     * @return token jika berhasil, null jika gagal
     */
    public String requestPasswordReset(String username, String email, String reason) {
        // VALIDASI: Cek apakah username ada di tabel users
        if (!userExists(username)) {
            return null; // Username tidak terdaftar
        }

        String token = UUID.randomUUID().toString();
        String sql = "INSERT INTO password_reset_requests (username, email, token, reason, status, created_at) " +
                     "VALUES (?, ?, ?, ?, 'pending', NOW())";
        
        try (Connection conn = DatabaseUtil.getLoginConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, username);
            ps.setString(2, email != null ? email : username); // Gunakan username jika email kosong
            ps.setString(3, token);
            ps.setString(4, reason);
            
            int affected = ps.executeUpdate();
            return affected > 0 ? token : null;
            
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Cek apakah username ada di tabel users (privat helper).
     */
    private boolean userExists(String username) {
        String sql = "SELECT COUNT(*) as cnt FROM users WHERE username = ?";
        try (Connection conn = DatabaseUtil.getLoginConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("cnt") > 0;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * Dapatkan semua request yang pending (untuk admin review).
     */
    public List<PasswordResetRequest> getPendingRequests() {
        List<PasswordResetRequest> list = new ArrayList<>();
        String sql = "SELECT id, username, email, token, reason, status, approved_by, approved_at, " +
                     "rejected_at, created_at FROM password_reset_requests WHERE status = 'pending' " +
                     "ORDER BY created_at DESC";
        
        try (Connection conn = DatabaseUtil.getLoginConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                PasswordResetRequest req = new PasswordResetRequest(
                    rs.getString("username"),
                    rs.getString("email"),
                    rs.getString("token"),
                    rs.getString("reason")
                );
                req.setId(rs.getInt("id"));
                req.setStatus(rs.getString("status"));
                
                Timestamp approvedAt = rs.getTimestamp("approved_at");
                if (approvedAt != null) {
                    req.setApprovedAt(approvedAt.toLocalDateTime());
                }
                
                list.add(req);
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return list;
    }

    /**
     * Approve password reset request dan set password baru.
     * @param requestId ID dari password reset request
     * @param adminUsername username admin yang approve
     * @param newPassword password baru
     * @return true jika berhasil
     */
    public boolean approveAndSetPassword(int requestId, String adminUsername, String newPassword) {
        String sqlGetRequest = "SELECT username FROM password_reset_requests WHERE id = ? AND status = 'pending'";
        String sqlUpdateRequest = "UPDATE password_reset_requests SET status = 'approved', " +
                                 "approved_by = ?, approved_at = NOW() WHERE id = ?";
        String sqlUpdatePassword = "UPDATE users SET password = ? WHERE username = ?";
        
        Connection conn = null;
        try {
            conn = DatabaseUtil.getLoginConnection();
            conn.setAutoCommit(false);
            
            // Dapatkan username dari request
            String username = null;
            try (PreparedStatement ps = conn.prepareStatement(sqlGetRequest)) {
                ps.setInt(1, requestId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        username = rs.getString("username");
                    }
                }
            }
            
            if (username == null) {
                conn.rollback();
                return false;
            }
            
            // Update request status
            try (PreparedStatement ps = conn.prepareStatement(sqlUpdateRequest)) {
                ps.setString(1, adminUsername);
                ps.setInt(2, requestId);
                ps.executeUpdate();
            }
            
            // Update password
            try (PreparedStatement ps = conn.prepareStatement(sqlUpdatePassword)) {
                ps.setString(1, newPassword);
                ps.setString(2, username);
                ps.executeUpdate();
            }
            
            conn.commit();
            return true;
            
        } catch (SQLException e) {
            try {
                if (conn != null) conn.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
            return false;
        } finally {
            try {
                if (conn != null) {
                    conn.setAutoCommit(true);
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Reject password reset request.
     */
    public boolean rejectRequest(int requestId, String adminUsername) {
        String sql = "UPDATE password_reset_requests SET status = 'rejected', " +
                     "approved_by = ?, rejected_at = NOW() WHERE id = ? AND status = 'pending'";
        
        try (Connection conn = DatabaseUtil.getLoginConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, adminUsername);
            ps.setInt(2, requestId);
            
            return ps.executeUpdate() > 0;
            
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Cek apakah ada request pending untuk user tertentu.
     */
    public boolean hasPendingRequest(String username) {
        String sql = "SELECT COUNT(*) as cnt FROM password_reset_requests WHERE username = ? AND status = 'pending'";
        
        try (Connection conn = DatabaseUtil.getLoginConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("cnt") > 0;
                }
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return false;
    }
}
