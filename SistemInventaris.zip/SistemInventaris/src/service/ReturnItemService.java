package service;

import controller.BarangController;
import controller.PeminjamanController;
import controller.ReturnItemController;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import model.Peminjaman;
import model.ReturnItem;
import model.dto.ReturnItemDTO;
import util.exception.ValidationException;
import util.validation.ValidationUtil;

/**
 * ReturnItemService — Business logic untuk sistem pengembalian barang.
 * Handle validasi, status tracking, stok update, dan logging.
 */
public class ReturnItemService extends BaseService {
    
    private final ReturnItemController returnItemCtrl;
    private final PeminjamanController peminjamanCtrl;
    private final BarangController barangCtrl;
    
    public ReturnItemService() {
        this.returnItemCtrl = new ReturnItemController();
        this.peminjamanCtrl = new PeminjamanController();
        this.barangCtrl = new BarangController();
    }
    
    /**
     * Request pengembalian barang dengan validasi komprehensif.
     */
    public int createReturnRequest(int peminjamanId, String username, int jumlahDikembalikan,
                                  String kondisiBarang, String keterangan) 
            throws ValidationException, SQLException {
        
        // Validasi input
        ValidationUtil.requirePositive(peminjamanId, "Peminjaman ID");
        ValidationUtil.requireNotEmpty(username, "Username");
        ValidationUtil.requirePositive(jumlahDikembalikan, "Jumlah dikembalikan");
        ValidationUtil.requireNotEmpty(kondisiBarang, "Kondisi barang");
        
        // Ambil data peminjaman
        Peminjaman peminjaman = peminjamanCtrl.getById(peminjamanId);
        if (peminjaman == null) {
            throw new ValidationException("Peminjaman #" + peminjamanId + " tidak ditemukan");
        }
        
        // Validasi status peminjaman
        if (!peminjaman.getStatus().equalsIgnoreCase("disetujui")) {
            throw new ValidationException("Hanya peminjaman yang sudah disetujui dapat dikembalikan. " +
                "Status saat ini: " + peminjaman.getStatus());
        }
        
        // Cek jika sudah fully returned
        if ("dikembalikan".equalsIgnoreCase(peminjaman.getStatusReturn())) {
            throw new ValidationException("Barang ini sudah sepenuhnya dikembalikan dan disetujui.");
        }
        
        // Validasi jumlah pengembalian tidak melebihi jumlah pinjam
        ValidationUtil.requireValidReturnQuantity(jumlahDikembalikan, peminjaman.getJumlah(), 
                                                 peminjaman.getNamaBarang());
        
        // Validasi kondisi barang valid
        if (!isValidCondition(kondisiBarang)) {
            throw new ValidationException("Kondisi barang harus: baik, rusak ringan, rusak berat, atau hilang");
        }
        
        // Create return request
        int returnId = returnItemCtrl.createReturnRequest(peminjamanId, username, 
                                                         jumlahDikembalikan, kondisiBarang, 
                                                         keterangan);
        
        if (returnId > 0) {
            logOperation("CREATE_RETURN", 
                        "User " + username + " request pengembalian " + 
                        jumlahDikembalikan + "x " + peminjaman.getNamaBarang());
        }
        
        return returnId;
    }
    
    /**
     * Approve return dengan update stok otomatis.
     */
    public boolean approveReturn(int returnItemId, String adminUsername) 
            throws ValidationException, SQLException {
        
        ValidationUtil.requirePositive(returnItemId, "Return Item ID");
        ValidationUtil.requireNotEmpty(adminUsername, "Admin Username");
        
        ReturnItem item = returnItemCtrl.getReturnItemById(returnItemId);
        if (item == null) {
            throw new ValidationException("Return item #" + returnItemId + " tidak ditemukan");
        }
        
        if (!item.getStatus().equalsIgnoreCase("pending")) {
            throw new ValidationException("Return hanya bisa di-approve jika status pending");
        }
        
        // Approve di controller (UPDATE return_items status + stok)
        boolean success = returnItemCtrl.approveReturn(returnItemId, adminUsername);
        
        if (success) {
            logOperation("APPROVE_RETURN", 
                        "Admin " + adminUsername + " approve pengembalian " + 
                        item.getJumlahDikembalikan() + "x " + item.getNamaBarang() + 
                        " (kondisi: " + item.getKondisiBarang() + ")");
        }
        
        return success;
    }
    
    /**
     * Reject return request.
     */
    public boolean rejectReturn(int returnItemId, String adminUsername) 
            throws ValidationException {
        
        ValidationUtil.requirePositive(returnItemId, "Return Item ID");
        ValidationUtil.requireNotEmpty(adminUsername, "Admin Username");
        
        ReturnItem item = returnItemCtrl.getReturnItemById(returnItemId);
        if (item == null) {
            throw new ValidationException("Return item #" + returnItemId + " tidak ditemukan");
        }
        
        boolean success = returnItemCtrl.rejectReturn(returnItemId);
        
        if (success) {
            logOperation("REJECT_RETURN", 
                        "Admin " + adminUsername + " reject pengembalian dari " + item.getUsername());
        }
        
        return success;
    }
    
    /**
     * Get all pending returns untuk admin.
     */
    public List<ReturnItemDTO> getPendingReturnsWithDetails() throws SQLException {
        List<ReturnItem> items = returnItemCtrl.getPendingReturnRequests();
        List<ReturnItemDTO> dtos = new ArrayList<>();
        
        for (ReturnItem item : items) {
            try {
                Peminjaman pem = peminjamanCtrl.getById(item.getPeminjamanId());
                if (pem != null) {
                    ReturnItemDTO dto = convertToDTO(item, pem);
                    dtos.add(dto);
                }
            } catch (SQLException ignored) {}
        }
        
        return dtos;
    }
    
    /**
     * Get return history untuk user.
     */
    public List<ReturnItemDTO> getUserReturnHistory(String username) throws SQLException {
        List<ReturnItem> items = returnItemCtrl.getUserReturnHistory(username);
        List<ReturnItemDTO> dtos = new ArrayList<>();
        
        for (ReturnItem item : items) {
            try {
                Peminjaman pem = peminjamanCtrl.getById(item.getPeminjamanId());
                if (pem != null) {
                    ReturnItemDTO dto = convertToDTO(item, pem);
                    dtos.add(dto);
                }
            } catch (SQLException ignored) {}
        }
        
        return dtos;
    }
    
    /**
     * Get return details dengan semua informasi lengkap.
     */
    public ReturnItemDTO getReturnDetailsWithStatus(int returnItemId) throws SQLException, ValidationException {
        ReturnItem item = returnItemCtrl.getReturnItemById(returnItemId);
        if (item == null) {
            throw new ValidationException("Return item tidak ditemukan");
        }
        
        Peminjaman pem = peminjamanCtrl.getById(item.getPeminjamanId());
        if (pem == null) {
            throw new ValidationException("Data peminjaman tidak ditemukan");
        }
        
        return convertToDTO(item, pem);
    }
    
    /**
     * Cek apakah ada pengembalian yang belum selesai.
     */
    public boolean hasIncompleteReturn(int peminjamanId) throws SQLException {
        Peminjaman pem = peminjamanCtrl.getById(peminjamanId);
        if (pem == null) return false;
        
        List<ReturnItem> returns = returnItemCtrl.getPendingReturnRequests();
        for (ReturnItem item : returns) {
            if (item.getPeminjamanId() == peminjamanId) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Kalkulasi sisa barang yang belum dikembalikan.
     */
    public int getRemainingQuantity(int peminjamanId) throws SQLException {
        List<ReturnItem> returns = returnItemCtrl.getUserReturnHistory("");
        int returned = 0;
        
        for (ReturnItem item : returns) {
            if (item.getPeminjamanId() == peminjamanId && 
                item.getStatus().equalsIgnoreCase("approved")) {
                returned += item.getJumlahDikembalikan();
            }
        }
        
        Peminjaman pem = peminjamanCtrl.getById(peminjamanId);
        return pem != null ? pem.getJumlah() - returned : 0;
    }
    
    // ── Private Helper Methods ────────────────────────────
    
    private void updateStokBerdasarkanKondisi(ReturnItem item) throws SQLException {
        String kondisi = item.getKondisiBarang().toLowerCase();
        
        if (kondisi.equals("baik")) {
            // Tambah stok normal jika kondisi baik
            barangCtrl.tambahMasukBarang(item.getKodeBarang(), 
                                        item.getJumlahDikembalikan(), 
                                        "Pengembalian barang (kondisi baik)");
        } else if (kondisi.equals("rusak ringan")) {
            // Catat sebagai barang rusak ringan (bisa diperbaiki)
            // Update log sebagai KELUAR (rusak)
            logOperation("UPDATE_STOK", 
                        item.getNamaBarang() + " (" + item.getJumlahDikembalikan() + "x) " +
                        "dikembalikan dengan kondisi rusak ringan");
        } else if (kondisi.equals("rusak berat") || kondisi.equals("hilang")) {
            // Catat sebagai penghapusan stok permanent
            logOperation("UPDATE_STOK", 
                        item.getNamaBarang() + " (" + item.getJumlahDikembalikan() + "x) " +
                        "dikembalikan dengan kondisi " + kondisi);
        }
    }
    
    private ReturnItemDTO convertToDTO(ReturnItem item, Peminjaman pem) {
        ReturnItemDTO dto = new ReturnItemDTO();
        dto.setId(item.getId());
        dto.setPeminjamanId(item.getPeminjamanId());
        dto.setUsername(item.getUsername());
        dto.setKodeBarang(item.getKodeBarang());
        dto.setNamaBarang(item.getNamaBarang());
        dto.setJumlahPinjam(pem.getJumlah());
        dto.setJumlahDikembalikan(item.getJumlahDikembalikan());
        dto.setJumlahBelumDikembalikan(pem.getJumlah() - item.getJumlahDikembalikan());
        dto.setTanggalPinjam(pem.getTanggalPinjam());
        dto.setTanggalSeharusnyaKembali(pem.getTanggalKembali());
        dto.setTanggalKembaliAktual(item.getTanggalReturn());
        dto.setKondisiBarang(item.getKondisiBarang());
        dto.setStatusPeminjaman(pem.getStatus());
        dto.setStatusPengembalian(item.getStatus());
        dto.setKeterangan(item.getKeterangan());
        
        // Check if late
        LocalDate today = LocalDate.now();
        if (today.isAfter(pem.getTanggalKembali())) {
            dto.setTerlambat(true);
            dto.setHariTerlambat((int) java.time.temporal.ChronoUnit.DAYS.between(
                pem.getTanggalKembali(), today));
        }
        
        return dto;
    }
    
    private boolean isValidCondition(String kondisi) {
        String lower = kondisi.toLowerCase();
        return lower.equals("baik") || 
               lower.equals("rusak ringan") || 
               lower.equals("rusak berat") || 
               lower.equals("hilang");
    }
}
