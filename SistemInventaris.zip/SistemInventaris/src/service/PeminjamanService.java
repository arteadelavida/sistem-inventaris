package service;

import controller.BarangController;
import controller.PeminjamanController;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import model.Barang;
import model.Peminjaman;
import util.exception.BusinessException;
import util.exception.ValidationException;
import util.validation.ValidationUtil;

/**
 * PeminjamanService — Service layer untuk business logic peminjaman.
 * Memisahkan validasi, orchestration, dan business rules dari controller.
 * 
 * Responsibilities:
 *   - Validasi request peminjaman (stok, durasi, user eligibility)
 *   - Orchestrate peminjaman approval workflow
 *   - Calculate statistics dan analytics
 *   - Error handling dan logging
 */
public class PeminjamanService extends BaseService {
    
    private final PeminjamanController peminjamanCtrl;
    private final BarangController barangCtrl;
    
    public PeminjamanService() {
        this.peminjamanCtrl = new PeminjamanController();
        this.barangCtrl = new BarangController();
    }
    
    /**
     * Ajukan peminjaman dengan validasi lengkap.
     * Includes: stock check, duration validation, eligibility checks.
     */
    public void ajukanPeminjamanWithValidation(String username, String kodeBarang, 
                                               int jumlah, LocalDate tanggalKembali) 
            throws ValidationException, BusinessException, SQLException {
        
        // Validasi input
        ValidationUtil.requireNotEmpty(username, "Username");
        ValidationUtil.requireNotEmpty(kodeBarang, "Kode barang");
        ValidationUtil.requirePositive(jumlah, "Jumlah");
        ValidationUtil.requireValidReturnDate(tanggalKembali);
        
        // Validasi duration
        ValidationUtil.requireValidBorrowDuration(LocalDate.now(), tanggalKembali);
        
        // Cek ketersediaan stok
        Barang barang = barangCtrl.getBarangByKode(kodeBarang);
        if (barang == null) {
            throw new ValidationException("Barang dengan kode '" + kodeBarang + "' tidak ditemukan");
        }
        
        if (barang.getStok() < jumlah) {
            throw new BusinessException(
                "Stok " + barang.getNamaBarang() + " tidak cukup. " +
                "Tersedia: " + barang.getStok() + ", diminta: " + jumlah,
                "INSUFFICIENT_STOCK");
        }
        
        // TODO: Check user eligibility
        // - Check if user sudah exceed borrow limit
        // - Check if user punya outstanding overdue items
        
        // Create peminjaman
        Peminjaman peminjaman = new Peminjaman(username, kodeBarang, 
                                               barang.getNamaBarang(), 
                                               jumlah, tanggalKembali);
        
        peminjamanCtrl.ajukanPeminjaman(peminjaman);
        
        logOperation("AJUKAN_PINJAM",
            username + " ajukan pinjam " + jumlah + "x " + barang.getNamaBarang() +
            " hingga " + tanggalKembali);
    }
    
    /**
     * Setujui peminjaman dengan optional keterangan.
     * Automatically updates stock dan logs operation.
     */
    public void setujuiPeminjamanWithValidation(int peminjamanId, String keterangan) 
            throws ValidationException, BusinessException, SQLException {
        
        ValidationUtil.requirePositive(peminjamanId, "Peminjaman ID");
        
        // Get peminjaman
        Peminjaman peminjaman = peminjamanCtrl.getById(peminjamanId);
        if (peminjaman == null) {
            throw new ValidationException("Peminjaman #" + peminjamanId + " tidak ditemukan");
        }
        
        // Validasi status
        if (!peminjaman.getStatus().equalsIgnoreCase("pending")) {
            throw new BusinessException(
                "Hanya peminjaman dengan status 'pending' yang bisa disetujui. " +
                "Status sekarang: " + peminjaman.getStatus(),
                "INVALID_STATUS");
        }
        
        // Double-check stok masih tersedia
        Barang barang = barangCtrl.getBarangByKode(peminjaman.getKodeBarang());
        if (barang == null || barang.getStok() < peminjaman.getJumlah()) {
            throw new BusinessException(
                "Stok sudah tidak tersedia untuk disetujui",
                "INSUFFICIENT_STOCK");
        }
        
        // Setujui (stock akan di-update otomatis di controller via transaksi)
        peminjamanCtrl.setujuiDenganKeterangan(peminjamanId, keterangan);
        
        logOperation("SETUJUI_PINJAM",
            "Peminjaman #" + peminjamanId + " disetujui. Stok -" + peminjaman.getJumlah() +
            " untuk " + peminjaman.getNamaBarang());
    }
    
    /**
     * Shortcut untuk setujui tanpa keterangan.
     */
    public void setujuiPeminjaman(int peminjamanId) 
            throws ValidationException, BusinessException, SQLException {
        setujuiPeminjamanWithValidation(peminjamanId, "-");
    }
    
    /**
     * Tolak peminjaman dengan keterangan.
     */
    public void tolakPeminjamanWithValidation(int peminjamanId, String keterangan) 
            throws ValidationException, SQLException {
        
        ValidationUtil.requirePositive(peminjamanId, "Peminjaman ID");
        
        Peminjaman peminjaman = peminjamanCtrl.getById(peminjamanId);
        if (peminjaman == null) {
            throw new ValidationException("Peminjaman #" + peminjamanId + " tidak ditemukan");
        }
        
        if (!peminjaman.getStatus().equalsIgnoreCase("pending")) {
            throw new ValidationException(
                "Hanya peminjaman pending yang bisa ditolak");
        }
        
        peminjamanCtrl.tolakDenganKeterangan(peminjamanId, keterangan);
        
        logOperation("TOLAK_PINJAM",
            "Peminjaman #" + peminjamanId + " ditolak. Alasan: " + 
            (keterangan != null ? keterangan : "-"));
    }
    
    /**
     * Get pending peminjaman (waiting for admin approval).
     */
    public List<Peminjaman> getPendingPeminjaman() {
        try {
            return peminjamanCtrl.getPending();
        } catch (SQLException e) {
            logOperation("GET_PENDING_PEMINJAMAN", e.getMessage());
            return new ArrayList<>();
        }
    }
    
    /**
     * Get user's peminjaman history.
     */
    public List<Peminjaman> getUserHistory(String username) {
        try {
            return peminjamanCtrl.getByUser(username);
        } catch (SQLException e) {
            logOperation("GET_USER_HISTORY", e.getMessage());
            return new ArrayList<>();
        }
    }
    
    /**
     * Get overdue peminjaman (tanggal_kembali sudah lewat tapi belum dikembalikan).
     */
    public List<Peminjaman> getOverduePeminjaman() {
        try {
            List<Peminjaman> all = peminjamanCtrl.getAllPeminjaman();
            List<Peminjaman> overdue = new ArrayList<>();
            
            LocalDate today = LocalDate.now();
            for (Peminjaman p : all) {
                // Status "disetujui" = approved borrowing
                if (p.getStatus().equalsIgnoreCase("disetujui") && 
                    p.getTanggalKembali() != null && 
                    p.getTanggalKembali().isBefore(today)) {
                    overdue.add(p);
                }
            }
            
            return overdue;
        } catch (SQLException e) {
            logOperation("GET_OVERDUE_PEMINJAMAN", e.getMessage());
            return new ArrayList<>();
        }
    }
    
    /**
     * Calculate hari sisa peminjaman.
     */
    public int getHariSisaPeminjaman(Peminjaman peminjaman) {
        if (peminjaman.getTanggalKembali() == null) return 0;
        return (int) java.time.temporal.ChronoUnit.DAYS.between(
            LocalDate.now(), 
            peminjaman.getTanggalKembali());
    }
    
    /**
     * Get peminjaman statistics untuk dashboard.
     */
    public PeminjamanStatistics getPeminjamanStatistics() {
        try {
            List<Peminjaman> all = peminjamanCtrl.getAllPeminjaman();
            
            int total = all.size();
            int pending = 0;
            int disetujui = 0;
            int ditolak = 0;
            int overdue = 0;
            
            LocalDate today = LocalDate.now();
            
            for (Peminjaman p : all) {
                String status = p.getStatus().toLowerCase();
                if (status.contains("pending")) pending++;
                else if (status.contains("disetujui")) {
                    disetujui++;
                    if (p.getTanggalKembali() != null && p.getTanggalKembali().isBefore(today)) {
                        overdue++;
                    }
                }
                else if (status.contains("tolak")) ditolak++;
            }
            
            return new PeminjamanStatistics(total, pending, disetujui, ditolak, overdue);
        } catch (SQLException e) {
            logOperation("GET_PEMINJAMAN_STATISTICS", e.getMessage());
            return new PeminjamanStatistics(0, 0, 0, 0, 0);
        }
    }
    
    /**
     * Inner class untuk peminjaman statistics.
     */
    public static class PeminjamanStatistics {
        public int totalPeminjaman;
        public int pending;
        public int disetujui;
        public int ditolak;
        public int overdue;
        
        public PeminjamanStatistics(int total, int pending, int disetujui, int ditolak, int overdue) {
            this.totalPeminjaman = total;
            this.pending = pending;
            this.disetujui = disetujui;
            this.ditolak = ditolak;
            this.overdue = overdue;
        }
    }
}
