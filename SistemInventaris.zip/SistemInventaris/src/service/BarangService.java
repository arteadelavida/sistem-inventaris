package service;

import controller.BarangController;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Barang;
import util.exception.BusinessException;
import util.exception.ValidationException;
import util.validation.ValidationUtil;

/**
 * BarangService — Service layer untuk business logic terkait Barang.
 * Memisahkan validasi dan business logic dari controller.
 * 
 * Responsibilities:
 *   - Validasi input dan business rules
 *   - Orchestrate controller calls
 *   - Logging dan notifications
 *   - Error handling
 */
public class BarangService extends BaseService {
    
    private final BarangController barangCtrl;
    
    public BarangService() {
        this.barangCtrl = new BarangController();
    }
    
    /**
     * Tambah barang baru dengan validasi lengkap.
     */
    public void tambahBarangWithValidation(String kodeBarang, String namaBarang, 
                                           int harga, int stok, String keterangan) 
            throws ValidationException, SQLException {
        
        // Validasi input
        ValidationUtil.requireNotEmpty(kodeBarang, "Kode barang");
        ValidationUtil.requireNotEmpty(namaBarang, "Nama barang");
        ValidationUtil.requireNonNegative(harga, "Harga");
        ValidationUtil.requireNonNegative(stok, "Stok");
        
        // Validasi panjang
        ValidationUtil.requireLength(kodeBarang, 1, 50, "Kode barang");
        ValidationUtil.requireLength(namaBarang, 3, 150, "Nama barang");
        
        // Cek duplikasi
        Barang existing = barangCtrl.getBarangByKode(kodeBarang);
        if (existing != null) {
            throw new ValidationException("Kode barang '" + kodeBarang + "' sudah terdaftar");
        }
        
        // Create dan simpan
        Barang barang = new Barang(kodeBarang, namaBarang, harga, stok, keterangan);
        barangCtrl.tambahBarang(barang);
        
        logOperation("TAMBAH_BARANG", 
            "Barang baru: " + kodeBarang + " (" + namaBarang + "), stok: " + stok);
    }
    
    /**
     * Update barang dengan validasi.
     */
    public void updateBarangWithValidation(String kodeBarang, String namaBarang,
                                           int harga, int stok, String keterangan) 
            throws ValidationException, SQLException {
        
        // Validasi input
        ValidationUtil.requireNotEmpty(kodeBarang, "Kode barang");
        ValidationUtil.requireNotEmpty(namaBarang, "Nama barang");
        ValidationUtil.requireNonNegative(harga, "Harga");
        ValidationUtil.requireNonNegative(stok, "Stok");
        
        // Cek keberadaan
        Barang existing = barangCtrl.getBarangByKode(kodeBarang);
        if (existing == null) {
            throw new ValidationException("Barang dengan kode '" + kodeBarang + "' tidak ditemukan");
        }
        
        // Update
        Barang updated = new Barang(kodeBarang, namaBarang, harga, stok, keterangan);
        barangCtrl.updateBarang(updated);
        
        logOperation("UPDATE_BARANG",
            "Update: " + kodeBarang + ", stok lama: " + existing.getStok() + 
            ", stok baru: " + stok);
    }
    
    /**
     * Hapus barang dengan validasi (hanya jika stok 0 dan tidak ada peminjaman aktif).
     */
    public void hapusBarangWithValidation(String kodeBarang) 
            throws ValidationException, BusinessException, SQLException {
        
        ValidationUtil.requireNotEmpty(kodeBarang, "Kode barang");
        
        Barang barang = barangCtrl.getBarangByKode(kodeBarang);
        if (barang == null) {
            throw new ValidationException("Barang dengan kode '" + kodeBarang + "' tidak ditemukan");
        }
        
        // Cek stok
        if (barang.getStok() > 0) {
            throw new BusinessException(
                "Tidak bisa menghapus barang. Stok masih ada: " + barang.getStok(),
                "BARANG_MASIH_ADA");
        }
        
        // TODO: Cek apakah ada peminjaman aktif
        // PeminjamanController peminjamanCtrl = new PeminjamanController();
        // List<Peminjaman> active = peminjamanCtrl.getByKodeBarang(kodeBarang, "approved");
        // if (!active.isEmpty()) { ... }
        
        barangCtrl.hapusBarang(kodeBarang);
        
        logOperation("HAPUS_BARANG", "Hapus: " + kodeBarang + " (" + barang.getNamaBarang() + ")");
    }
    
    /**
     * Get all barang dengan handling error.
     */
    public List<Barang> getAllBarangSafe() {
        try {
            return barangCtrl.getAllBarang();
        } catch (SQLException e) {
            logOperation("GET_ALL_BARANG", e.getMessage());
            return new ArrayList<>();
        }
    }
    
    /**
     * Get barang by kode dengan handling error.
     */
    public Barang getBarangByKodeSafe(String kodeBarang) {
        try {
            return barangCtrl.getBarangByKode(kodeBarang);
        } catch (SQLException e) {
            logOperation("GET_BARANG_BY_KODE", e.getMessage());
            return null;
        }
    }
    
    /**
     * Validasi ketersediaan stok untuk peminjaman.
     */
    public void validateStockAvailability(String kodeBarang, int quantity) 
            throws ValidationException, BusinessException {
        
        try {
            Barang barang = barangCtrl.getBarangByKode(kodeBarang);
            
            if (barang == null) {
                throw new ValidationException("Barang tidak ditemukan");
            }
            
            if (barang.getStok() < quantity) {
                throw new BusinessException(
                    "Stok " + barang.getNamaBarang() + " tidak cukup. " +
                    "Tersedia: " + barang.getStok() + ", diminta: " + quantity,
                    "INSUFFICIENT_STOCK");
            }
        } catch (SQLException e) {
            throw new ValidationException("Error saat validasi stok: " + e.getMessage());
        }
    }
    
    /**
     * Hitung item yang stok menipis (<5 unit).
     */
    public List<Barang> getBarangLowStock() {
        List<Barang> lowStock = new ArrayList<>();
        try {
            for (Barang b : barangCtrl.getAllBarang()) {
                if (b.getStok() < 5) {
                    lowStock.add(b);
                }
            }
        } catch (SQLException e) {
            logOperation("GET_LOW_STOCK", e.getMessage());
        }
        return lowStock;
    }
    
    /**
     * Get statistik barang.
     */
    public BarangStatistics getBarangStatistics() {
        try {
            List<Barang> all = barangCtrl.getAllBarang();
            int totalBarang = all.size();
            int barangTersedia = 0;
            int barangHabis = 0;
            int totalNilaiStok = 0;
            
            for (Barang b : all) {
                if (b.getStok() > 0) {
                    barangTersedia++;
                } else {
                    barangHabis++;
                }
                totalNilaiStok += (b.getStok() * b.getHarga());
            }
            
            return new BarangStatistics(totalBarang, barangTersedia, barangHabis, totalNilaiStok);
        } catch (SQLException e) {
            logOperation("GET_BARANG_STATISTICS", e.getMessage());
            return new BarangStatistics(0, 0, 0, 0);
        }
    }
    
    /**
     * Inner class untuk statistik barang.
     */
    public static class BarangStatistics {
        public int totalBarang;
        public int barangTersedia;
        public int barangHabis;
        public int totalNilaiStok;
        
        public BarangStatistics(int total, int tersedia, int habis, int nilaiStok) {
            this.totalBarang = total;
            this.barangTersedia = tersedia;
            this.barangHabis = habis;
            this.totalNilaiStok = nilaiStok;
        }
    }
}
