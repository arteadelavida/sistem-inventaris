package service;

import util.LogService;

/**
 * BaseService — Base class untuk semua service layer.
 * Menyediakan utility methods seperti logging, error handling.
 */
public abstract class BaseService {
    
    /**
     * Log operasi dengan action dan detail.
     */
    protected void logOperation(String action, String detail) {
        LogService.catat(action, detail);
    }
    
    /**
     * Validasi input tidak boleh null/empty.
     */
    protected void validateNotNull(Object obj, String fieldName) throws IllegalArgumentException {
        if (obj == null) {
            throw new IllegalArgumentException(fieldName + " tidak boleh null");
        }
    }
    
    protected void validateNotEmpty(String str, String fieldName) throws IllegalArgumentException {
        if (str == null || str.trim().isEmpty()) {
            throw new IllegalArgumentException(fieldName + " tidak boleh kosong");
        }
    }
    
    protected void validatePositive(int value, String fieldName) throws IllegalArgumentException {
        if (value <= 0) {
            throw new IllegalArgumentException(fieldName + " harus lebih dari 0");
        }
    }
    
    protected void validateNonNegative(int value, String fieldName) throws IllegalArgumentException {
        if (value < 0) {
            throw new IllegalArgumentException(fieldName + " tidak boleh negatif");
        }
    }
}
