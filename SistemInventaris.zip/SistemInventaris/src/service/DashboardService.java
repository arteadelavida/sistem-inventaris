package service;

import controller.*;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.*;
import model.*;
import model.dto.DashboardDTO;

/**
 * DashboardService — Service untuk mengumpulkan semua data statistik dashboard.
 */
public class DashboardService extends BaseService {
    
    private final BarangController barangCtrl;
    private final PeminjamanController peminjamanCtrl;
    private final ReturnItemController returnItemCtrl;
    private final UserController userCtrl;
    private final LogBarangController logBarangCtrl;
    
    public DashboardService() {
        this.barangCtrl = new BarangController();
        this.peminjamanCtrl = new PeminjamanController();
        this.returnItemCtrl = new ReturnItemController();
        this.userCtrl = new UserController();
        this.logBarangCtrl = new LogBarangController();
    }
    
    /**
     * Bangun dashboard lengkap dengan semua statistik.
     */
    public DashboardDTO buildFullDashboard() throws SQLException {
        DashboardDTO dashboard = new DashboardDTO();
        
        // Statistik utama
        populateBasicStats(dashboard);
        
        // Recent activities
        populateRecentActivities(dashboard);
        
        // Alerts
        populateAlerts(dashboard);
        
        // Charts data
        populateCharts(dashboard);
        
        return dashboard;
    }
    
    /**
     * Get statistik utama saja.
     */
    public DashboardDTO getBasicStats() throws SQLException {
        DashboardDTO dashboard = new DashboardDTO();
        populateBasicStats(dashboard);
        return dashboard;
    }
    
    /**
     * Get hanya alerts.
     */
    public List<DashboardDTO.AlertDTO> getAlerts() throws SQLException {
        DashboardDTO dashboard = new DashboardDTO();
        populateAlerts(dashboard);
        return dashboard.getAlerts();
    }
    
    /**
     * Get hanya recent activities.
     */
    public List<DashboardDTO.ActivityDTO> getRecentActivities() throws SQLException {
        DashboardDTO dashboard = new DashboardDTO();
        populateRecentActivities(dashboard);
        return dashboard.getRecentActivities();
    }
    
    // ── Private Helpers ────────────────────────────────
    
    private void populateBasicStats(DashboardDTO dashboard) throws SQLException {
        List<Barang> allBarang = barangCtrl.getAllBarang();
        
        // Total barang
        dashboard.setTotalBarang(allBarang.size());
        
        // Barang tersedia (stok > 0)
        int tersedia = 0;
        int dipinjam = 0;
        for (Barang b : allBarang) {
            if (b.getStok() > 0) tersedia++;
            // Simplified - in real scenario, track peminjaman per barang
        }
        dashboard.setBarangTersedia(tersedia);
        
        // Barang dipinjam (dari peminjaman yang disetujui & belum dikembalikan)
        List<Peminjaman> disetujuiList = peminjamanCtrl.getDisetujui();
        Set<String> barangDipinjamSet = new HashSet<>();
        for (Peminjaman p : disetujuiList) {
            barangDipinjamSet.add(p.getKodeBarang());
        }
        dashboard.setBarangDipinjam(barangDipinjamSet.size());
        
        // Barang rusak/hilang - dari return items dengan kondisi rusak/hilang
        List<ReturnItem> returns = returnItemCtrl.getPendingReturnRequests();
        int rusakHilang = 0;
        for (ReturnItem r : returns) {
            if (r.getKondisiBarang().contains("rusak") || r.getKondisiBarang().equals("hilang")) {
                rusakHilang++;
            }
        }
        dashboard.setBarangRusakHilang(rusakHilang);
        
        // Peminjaman pending
        List<Peminjaman> pendingList = peminjamanCtrl.getPending();
        dashboard.setPeminjamanPending(pendingList.size());
        
        // Pengembalian pending
        dashboard.setPengembalianPending(returns.size());
        
        // Pengguna
        try {
            List<User> users = userCtrl.getPendingUsers();
            dashboard.setPengguna(users.size() + 1); // +1 untuk admin
        } catch (SQLException ignored) {
            dashboard.setPengguna(0);
        }
    }
    
    private void populateRecentActivities(DashboardDTO dashboard) throws SQLException {
        List<DashboardDTO.ActivityDTO> activities = new ArrayList<>();
        
        // Get recent peminjaman (limit 5) — semua status, bukan hanya pending
        List<Peminjaman> recents = peminjamanCtrl.getAllPeminjaman();
        int count = 0;
        for (Peminjaman p : recents) {
            if (count >= 5) break;
            activities.add(new DashboardDTO.ActivityDTO(
                p.getUsername(),
                DashboardDTO.ActivityDTO.Type.PEMINJAMAN,
                "Meminjam " + p.getNamaBarang() + " (" + p.getJumlah() + "x)",
                p.getTanggalPinjam()
            ));
            count++;
        }
        
        // Get recent returns
        List<ReturnItem> returnRecents = returnItemCtrl.getPendingReturnRequests();
        count = 0;
        for (ReturnItem r : returnRecents) {
            if (count >= 3) break;
            activities.add(new DashboardDTO.ActivityDTO(
                r.getUsername(),
                DashboardDTO.ActivityDTO.Type.PENGEMBALIAN,
                "Mengembalikan " + r.getNamaBarang() + " (" + r.getJumlahDikembalikan() + "x)",
                r.getTanggalReturn()
            ));
            count++;
        }
        
        // Sort by tanggal (newest first)
        activities.sort((a, b) -> b.tanggal.compareTo(a.tanggal));
        
        dashboard.setRecentActivities(activities);
    }
    
    private void populateAlerts(DashboardDTO dashboard) throws SQLException {
        List<DashboardDTO.AlertDTO> alerts = new ArrayList<>();
        
        // Alert: Stok menipis (< 5)
        List<Barang> allBarang = barangCtrl.getAllBarang();
        for (Barang b : allBarang) {
            if (b.getStok() > 0 && b.getStok() < 5) {
                alerts.add(new DashboardDTO.AlertDTO(
                    "Stok Menipis: " + b.getNamaBarang(),
                    "Stok tinggal " + b.getStok() + " unit",
                    DashboardDTO.AlertDTO.Severity.WARNING
                ));
            }
        }
        
        // Alert: Barang belum dikembalikan
        List<Peminjaman> disetujuiAlerts = peminjamanCtrl.getDisetujui();
        LocalDate today = LocalDate.now();
        int terlambat = 0;

        for (Peminjaman p : disetujuiAlerts) {
            if (today.isAfter(p.getTanggalKembali())) {
                terlambat++;
            }
        }
        
        if (terlambat > 0) {
            alerts.add(new DashboardDTO.AlertDTO(
                "Peminjaman Terlambat",
                terlambat + " peminjaman belum dikembalikan melewati tenggat waktu",
                DashboardDTO.AlertDTO.Severity.ERROR
            ));
        }
        
        // Alert: Pengembalian barang rusak
        List<ReturnItem> returns = returnItemCtrl.getPendingReturnRequests();
        int rusak = 0;
        for (ReturnItem r : returns) {
            if (r.getKondisiBarang().contains("rusak")) rusak++;
        }
        
        if (rusak > 0) {
            alerts.add(new DashboardDTO.AlertDTO(
                "Barang Rusak",
                rusak + " barang dikembalikan dalam kondisi rusak",
                DashboardDTO.AlertDTO.Severity.WARNING
            ));
        }
        
        dashboard.setAlerts(alerts);
    }
    
    private void populateCharts(DashboardDTO dashboard) throws SQLException {
        // Chart 1: Peminjaman per bulan (last 12 months)
        Map<LocalDate, Integer> peminjamanPerBulan = new LinkedHashMap<>();
        
        List<Peminjaman> allPeminjaman = peminjamanCtrl.getAllPeminjaman();
        Map<YearMonth, Integer> monthMap = new HashMap<>();
        
        for (Peminjaman p : allPeminjaman) {
            YearMonth ym = YearMonth.from(p.getTanggalPinjam());
            monthMap.put(ym, monthMap.getOrDefault(ym, 0) + 1);
        }
        
        // Convert to LocalDate for display
        for (int i = 11; i >= 0; i--) {
            YearMonth ym = YearMonth.now().minusMonths(i);
            LocalDate ld = ym.atDay(1);
            peminjamanPerBulan.put(ld, monthMap.getOrDefault(ym, 0));
        }
        
        dashboard.setPeminjamanPerBulan(peminjamanPerBulan);
    }
}
