import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;
import java.io.*;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;

/**
 * WebServer — Simple HTTP server untuk akses Sistem Inventaris via browser.
 * Jalankan dengan: java -cp "out;lib/*" WebServer
 * Akses: http://localhost:8080 atau http://<IP_ANDA>:8080
 */
public class WebServer {
    private static final int PORT = 8080;

    public static void main(String[] args) throws IOException {
        HttpServer server = HttpServer.create(new InetSocketAddress(PORT), 0);
        
        // Root endpoint - menampilkan halaman utama
        server.createContext("/", new HttpHandler() {
            @Override
            public void handle(HttpExchange exchange) throws IOException {
                String html = getHomePage();
                sendResponse(exchange, 200, html);
            }
        });
        
        // Endpoint untuk status
        server.createContext("/status", new HttpHandler() {
            @Override
            public void handle(HttpExchange exchange) throws IOException {
                String timestamp = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new java.util.Date());
                String json = "{\"status\":\"running\",\"app\":\"Sistem Inventaris\",\"timestamp\":\"" + 
                    timestamp + "\"}";
                sendResponse(exchange, 200, json, "application/json");
            }
        });

        server.setExecutor(null);
        server.start();
        
        String ipAddress = getIPAddress();
        System.out.println("╔════════════════════════════════════════════════════════╗");
        System.out.println("║        SISTEM INVENTARIS - WEB SERVER RUNNING         ║");
        System.out.println("╠════════════════════════════════════════════════════════╣");
        System.out.println("║ Akses lokal:                                           ║");
        System.out.println("║   http://localhost:8080                                ║");
        System.out.println("║                                                        ║");
        System.out.println("║ Akses dari jaringan:                                   ║");
        System.out.println("║   http://" + padRight(ipAddress + ":8080", 46) + "║");
        System.out.println("║                                                        ║");
        System.out.println("║ Share link ini ke orang lain untuk diakses!            ║");
        System.out.println("╚════════════════════════════════════════════════════════╝");
    }

    private static String getHomePage() {
        return "<!DOCTYPE html>\n" +
            "<html lang=\"id\">\n" +
            "<head>\n" +
            "    <meta charset=\"UTF-8\">\n" +
            "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n" +
            "    <title>Sistem Inventaris</title>\n" +
            "    <style>\n" +
            "        * { margin: 0; padding: 0; box-sizing: border-box; }\n" +
            "        body {\n" +
            "            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;\n" +
            "            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);\n" +
            "            min-height: 100vh;\n" +
            "            display: flex;\n" +
            "            align-items: center;\n" +
            "            justify-content: center;\n" +
            "        }\n" +
            "        .container {\n" +
            "            background: white;\n" +
            "            padding: 40px;\n" +
            "            border-radius: 15px;\n" +
            "            box-shadow: 0 20px 60px rgba(0,0,0,0.3);\n" +
            "            max-width: 600px;\n" +
            "            text-align: center;\n" +
            "        }\n" +
            "        h1 {\n" +
            "            color: #333;\n" +
            "            margin-bottom: 10px;\n" +
            "            font-size: 2.5em;\n" +
            "        }\n" +
            "        .subtitle {\n" +
            "            color: #666;\n" +
            "            margin-bottom: 30px;\n" +
            "            font-size: 1.1em;\n" +
            "        }\n" +
            "        .status-box {\n" +
            "            background: #e8f5e9;\n" +
            "            border-left: 4px solid #4caf50;\n" +
            "            padding: 15px;\n" +
            "            margin: 20px 0;\n" +
            "            border-radius: 5px;\n" +
            "            text-align: left;\n" +
            "        }\n" +
            "        .status-item {\n" +
            "            display: flex;\n" +
            "            justify-content: space-between;\n" +
            "            padding: 8px 0;\n" +
            "            border-bottom: 1px solid #c8e6c9;\n" +
            "        }\n" +
            "        .status-item:last-child {\n" +
            "            border-bottom: none;\n" +
            "        }\n" +
            "        .status-label {\n" +
            "            font-weight: bold;\n" +
            "            color: #333;\n" +
            "        }\n" +
            "        .status-value {\n" +
            "            color: #4caf50;\n" +
            "            font-weight: bold;\n" +
            "        }\n" +
            "        .info {\n" +
            "            background: #f5f5f5;\n" +
            "            padding: 20px;\n" +
            "            border-radius: 10px;\n" +
            "            margin: 20px 0;\n" +
            "            text-align: left;\n" +
            "        }\n" +
            "        .info h3 {\n" +
            "            color: #667eea;\n" +
            "            margin-bottom: 10px;\n" +
            "        }\n" +
            "        .info p {\n" +
            "            color: #666;\n" +
            "            margin-bottom: 8px;\n" +
            "            line-height: 1.6;\n" +
            "        }\n" +
            "        .footer {\n" +
            "            color: #999;\n" +
            "            font-size: 0.9em;\n" +
            "            margin-top: 30px;\n" +
            "            padding-top: 20px;\n" +
            "            border-top: 1px solid #eee;\n" +
            "        }\n" +
            "        .dot {\n" +
            "            display: inline-block;\n" +
            "            width: 12px;\n" +
            "            height: 12px;\n" +
            "            background: #4caf50;\n" +
            "            border-radius: 50%;\n" +
            "            margin-right: 8px;\n" +
            "            animation: pulse 1.5s infinite;\n" +
            "        }\n" +
            "        @keyframes pulse {\n" +
            "            0%, 100% { opacity: 1; }\n" +
            "            50% { opacity: 0.5; }\n" +
            "        }\n" +
            "    </style>\n" +
            "</head>\n" +
            "<body>\n" +
            "    <div class=\"container\">\n" +
            "        <h1>📦 Sistem Inventaris</h1>\n" +
            "        <p class=\"subtitle\">Inventory Management System</p>\n" +
            "\n" +
            "        <div class=\"status-box\">\n" +
            "            <div class=\"status-item\">\n" +
            "                <span class=\"status-label\"><span class=\"dot\"></span>Status Server</span>\n" +
            "                <span class=\"status-value\">Online ✓</span>\n" +
            "            </div>\n" +
            "            <div class=\"status-item\">\n" +
            "                <span class=\"status-label\">Database</span>\n" +
            "                <span class=\"status-value\">Connected</span>\n" +
            "            </div>\n" +
            "            <div class=\"status-item\">\n" +
            "                <span class=\"status-label\">Waktu</span>\n" +
            "                <span class=\"status-value\" id=\"time\">Loading...</span>\n" +
            "            </div>\n" +
            "        </div>\n" +
            "\n" +
            "        <div class=\"info\">\n" +
            "            <h3>ℹ️ Informasi</h3>\n" +
            "            <p><strong>✓ Server sedang berjalan</strong></p>\n" +
            "            <p>Aplikasi Sistem Inventaris siap digunakan. Server Web aktif dan dapat diakses dari jaringan.</p>\n" +
            "            <p style=\"margin-top: 15px; color: #999; font-size: 0.9em;\">\n" +
            "                <em>Untuk menggunakan aplikasi, silakan login dengan kredensial Anda.</em>\n" +
            "            </p>\n" +
            "        </div>\n" +
            "\n" +
            "        <div class=\"footer\">\n" +
            "            <p>Sistem Inventaris v1.0 © 2026</p>\n" +
            "            <p>Powered by Java Web Server</p>\n" +
            "        </div>\n" +
            "    </div>\n" +
            "\n" +
            "    <script>\n" +
            "        setInterval(() => {\n" +
            "            fetch('/status')\n" +
            "                .then(r => r.json())\n" +
            "                .then(d => {\n" +
            "                    document.getElementById('time').textContent = d.timestamp.split('.')[0];\n" +
            "                })\n" +
            "                .catch(e => console.log('Auto-refresh timestamp'));\n" +
            "        }, 1000);\n" +
            "    </script>\n" +
            "</body>\n" +
            "</html>";
    }

    private static void sendResponse(HttpExchange exchange, int statusCode, String response) throws IOException {
        sendResponse(exchange, statusCode, response, "text/html; charset=utf-8");
    }

    private static void sendResponse(HttpExchange exchange, int statusCode, String response, String contentType) throws IOException {
        exchange.getResponseHeaders().set("Content-Type", contentType);
        exchange.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
        byte[] responseBytes = response.getBytes(StandardCharsets.UTF_8);
        exchange.sendResponseHeaders(statusCode, responseBytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(responseBytes);
        }
    }

    private static String getIPAddress() {
        try {
            return java.net.InetAddress.getLocalHost().getHostAddress();
        } catch (Exception e) {
            return "localhost";
        }
    }

    private static String padRight(String s, int n) {
        return String.format("%-" + n + "s", s);
    }
}
