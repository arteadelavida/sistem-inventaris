package util.theme;

import java.awt.*;

/**
 * ColorPalette — Centralized color definitions untuk enterprise theme.
 * Supports light dan dark mode.
 * 
 * Color scheme:
 *   - Modern, professional, accessible
 *   - WCAG AA compliant
 *   - Soft shadows, subtle contrasts
 */
public class ColorPalette {
    
    // Light mode colors
    public static class Light {
        public static final Color PRIMARY = new Color(0, 105, 140);
        public static final Color PRIMARY_LIGHT = new Color(0, 188, 212);
        public static final Color DARK = new Color(15, 32, 68);
        public static final Color TEXT_MAIN = new Color(28, 32, 50);
        public static final Color TEXT_LIGHT = new Color(120, 130, 155);
        public static final Color TEXT_MUTED = new Color(180, 190, 210);
        public static final Color BG_PRIMARY = new Color(248, 250, 253);
        public static final Color BG_SECONDARY = Color.WHITE;
        public static final Color BORDER = new Color(230, 235, 245);
        public static final Color SHADOW = new Color(0, 0, 0, 15);
        
        public static final Color SUCCESS = new Color(76, 175, 80);
        public static final Color WARNING = new Color(255, 193, 7);
        public static final Color ERROR = new Color(244, 67, 54);
        public static final Color INFO = new Color(33, 150, 243);
        
        public static final Color HOVER_OVERLAY = new Color(0, 0, 0, 5);
        public static final Color ACTIVE_OVERLAY = new Color(0, 0, 0, 10);
    }
    
    // Dark mode colors
    public static class Dark {
        public static final Color PRIMARY = new Color(0, 150, 200);
        public static final Color PRIMARY_LIGHT = new Color(0, 188, 212);
        public static final Color DARK = new Color(240, 242, 245);
        public static final Color TEXT_MAIN = new Color(240, 242, 245);
        public static final Color TEXT_LIGHT = new Color(180, 190, 210);
        public static final Color TEXT_MUTED = new Color(120, 130, 155);
        public static final Color BG_PRIMARY = new Color(18, 25, 45);
        public static final Color BG_SECONDARY = new Color(30, 40, 65);
        public static final Color BORDER = new Color(60, 75, 110);
        public static final Color SHADOW = new Color(0, 0, 0, 30);
        
        public static final Color SUCCESS = new Color(102, 195, 105);
        public static final Color WARNING = new Color(255, 210, 70);
        public static final Color ERROR = new Color(255, 100, 90);
        public static final Color INFO = new Color(70, 175, 255);
        
        public static final Color HOVER_OVERLAY = new Color(255, 255, 255, 5);
        public static final Color ACTIVE_OVERLAY = new Color(255, 255, 255, 10);
    }
    
    // Semantic colors
    public enum ColorMode {
        LIGHT, DARK
    }
    
    private static ColorMode currentMode = ColorMode.LIGHT;
    
    public static void setColorMode(ColorMode mode) {
        currentMode = mode;
    }
    
    public static ColorMode getColorMode() {
        return currentMode;
    }
    
    // Get colors based on current mode
    public static Color getPrimary() {
        return currentMode == ColorMode.LIGHT ? Light.PRIMARY : Dark.PRIMARY;
    }
    
    public static Color getPrimaryLight() {
        return currentMode == ColorMode.LIGHT ? Light.PRIMARY_LIGHT : Dark.PRIMARY_LIGHT;
    }
    
    public static Color getTextMain() {
        return currentMode == ColorMode.LIGHT ? Light.TEXT_MAIN : Dark.TEXT_MAIN;
    }
    
    public static Color getTextLight() {
        return currentMode == ColorMode.LIGHT ? Light.TEXT_LIGHT : Dark.TEXT_LIGHT;
    }
    
    public static Color getTextMuted() {
        return currentMode == ColorMode.LIGHT ? Light.TEXT_MUTED : Dark.TEXT_MUTED;
    }
    
    public static Color getBackgroundPrimary() {
        return currentMode == ColorMode.LIGHT ? Light.BG_PRIMARY : Dark.BG_PRIMARY;
    }
    
    public static Color getBackgroundSecondary() {
        return currentMode == ColorMode.LIGHT ? Light.BG_SECONDARY : Dark.BG_SECONDARY;
    }
    
    public static Color getBorder() {
        return currentMode == ColorMode.LIGHT ? Light.BORDER : Dark.BORDER;
    }
    
    public static Color getShadow() {
        return currentMode == ColorMode.LIGHT ? Light.SHADOW : Dark.SHADOW;
    }
    
    public static Color getSuccess() {
        return currentMode == ColorMode.LIGHT ? Light.SUCCESS : Dark.SUCCESS;
    }
    
    public static Color getWarning() {
        return currentMode == ColorMode.LIGHT ? Light.WARNING : Dark.WARNING;
    }
    
    public static Color getError() {
        return currentMode == ColorMode.LIGHT ? Light.ERROR : Dark.ERROR;
    }
    
    public static Color getInfo() {
        return currentMode == ColorMode.LIGHT ? Light.INFO : Dark.INFO;
    }
    
    public static Color getHoverOverlay() {
        return currentMode == ColorMode.LIGHT ? Light.HOVER_OVERLAY : Dark.HOVER_OVERLAY;
    }
    
    public static Color getActiveOverlay() {
        return currentMode == ColorMode.LIGHT ? Light.ACTIVE_OVERLAY : Dark.ACTIVE_OVERLAY;
    }
}
