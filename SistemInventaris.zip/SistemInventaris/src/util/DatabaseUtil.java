package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * DatabaseUtil — satu-satunya tempat koneksi database.
 * Konfigurasi: edit HOST, PORT, DB_USER, DB_PASS sesuai environment.
 */
public class DatabaseUtil {

    private static final String HOST          = "localhost";
    private static final String PORT          = "3306";
    private static final String DB_USER       = "root";
    private static final String DB_PASS       = "";
    private static final String DB_LOGIN      = "login";
    private static final String DB_INVENTARIS = "sisteminventaris";

    /** URL params: nonaktifkan SSL, set timezone, charset UTF-8, hindari warning JDBC */
    private static final String URL_PARAMS =
        "?useSSL=false&serverTimezone=Asia%2FJakarta" +
        "&useUnicode=true&characterEncoding=UTF-8" +
        "&allowPublicKeyRetrieval=true" +
        "&useJDBCCompliantTimezoneShift=false" +
        "&useLegacyDatetimeCode=false&connectTimeout=5000";

    private static boolean driverLoaded = false;

    /**
     * Load driver MySQL secara lazy (hanya saat pertama kali dibutuhkan)
     */
    private static synchronized void loadDriver() {
        if (driverLoaded) return;
        try {
            // Driver baru (Connector/J 8+): com.mysql.cj.jdbc.Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            // Fallback ke driver lama
            try { Class.forName("com.mysql.jdbc.Driver"); }
            catch (ClassNotFoundException ex) {
                System.err.println("[DatabaseUtil] Driver MySQL tidak ditemukan. " +
                    "Pastikan mysql-connector-j-*.jar ada di folder lib/");
            }
        }
        driverLoaded = true;
    }

    public static Connection getLoginConnection() throws SQLException {
        loadDriver();
        return DriverManager.getConnection(
            "jdbc:mysql://" + HOST + ":" + PORT + "/" + DB_LOGIN + URL_PARAMS,
            DB_USER, DB_PASS);
    }

    public static Connection getInventarisConnection() throws SQLException {
        loadDriver();
        return DriverManager.getConnection(
            "jdbc:mysql://" + HOST + ":" + PORT + "/" + DB_INVENTARIS + URL_PARAMS,
            DB_USER, DB_PASS);
    }
}
