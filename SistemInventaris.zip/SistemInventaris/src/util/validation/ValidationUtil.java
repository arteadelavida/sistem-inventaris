package util.validation;

import java.util.regex.Pattern;
import util.exception.ValidationException;

/**
 * ValidationUtil — Utility untuk validasi input dengan pesan yang jelas.
 */
public class ValidationUtil {
    
    private static final Pattern EMAIL_PATTERN = Pattern.compile(
        "^[A-Za-z0-9+_.-]+@(.+)$"
    );
    
    /**
     * Validasi string tidak null dan tidak kosong.
     */
    public static void requireNotEmpty(String value, String fieldName) throws ValidationException {
        if (value == null || value.trim().isEmpty()) {
            throw new ValidationException(fieldName + " tidak boleh kosong");
        }
    }
    
    /**
     * Validasi integer positif (> 0).
     */
    public static void requirePositive(int value, String fieldName) throws ValidationException {
        if (value <= 0) {
            throw new ValidationException(fieldName + " harus lebih dari 0");
        }
    }
    
    /**
     * Validasi integer non-negative (>= 0).
     */
    public static void requireNonNegative(int value, String fieldName) throws ValidationException {
        if (value < 0) {
            throw new ValidationException(fieldName + " tidak boleh negatif");
        }
    }
    
    /**
     * Validasi panjang string.
     */
    public static void requireLength(String value, int minLength, int maxLength, String fieldName) 
            throws ValidationException {
        if (value == null) {
            throw new ValidationException(fieldName + " tidak boleh null");
        }
        int len = value.length();
        if (len < minLength || len > maxLength) {
            throw new ValidationException(fieldName + " harus antara " + minLength + " - " + maxLength + " karakter");
        }
    }
    
    /**
     * Validasi email format.
     */
    public static void requireValidEmail(String email) throws ValidationException {
        if (email == null || !EMAIL_PATTERN.matcher(email).matches()) {
            throw new ValidationException("Format email tidak valid");
        }
    }
    
    /**
     * Validasi jumlah pinjam tidak melebihi stok.
     */
    public static void requireSufficientStock(int requested, int available, String itemName) 
            throws ValidationException {
        if (requested > available) {
            throw new ValidationException("Jumlah " + itemName + " melebihi stok tersedia (" + available + ")");
        }
    }
    
    /**
     * Validasi jumlah pengembalian tidak melebihi jumlah pinjam.
     */
    public static void requireValidReturnQuantity(int returned, int borrowed, String itemName) 
            throws ValidationException {
        if (returned > borrowed) {
            throw new ValidationException("Jumlah pengembalian " + itemName + " melebihi jumlah pinjam (" + borrowed + ")");
        }
    }
    
    /**
     * Validasi tanggal kembali tidak null dan tidak di masa lalu.
     */
    public static void requireValidReturnDate(java.time.LocalDate returnDate) throws ValidationException {
        if (returnDate == null) {
            throw new ValidationException("Tanggal kembali tidak boleh null");
        }
        if (returnDate.isBefore(java.time.LocalDate.now())) {
            throw new ValidationException("Tanggal kembali tidak boleh di masa lalu");
        }
    }
    
    /**
     * Validasi durasi peminjaman (max 30 hari, min 1 hari).
     */
    public static void requireValidBorrowDuration(java.time.LocalDate startDate, java.time.LocalDate returnDate) 
            throws ValidationException {
        if (returnDate == null || startDate == null) {
            throw new ValidationException("Tanggal mulai dan kembali harus valid");
        }
        long days = java.time.temporal.ChronoUnit.DAYS.between(startDate, returnDate);
        if (days < 1) {
            throw new ValidationException("Durasi peminjaman minimal 1 hari");
        }
        if (days > 30) {
            throw new ValidationException("Durasi peminjaman maksimal 30 hari");
        }
    }
}
