package util.export;

import java.io.*;
import java.util.List;
import javax.swing.JTable;

/**
 * ExportUtil — Utility untuk export data ke CSV/Excel.
 * CSV format untuk kompatibilitas universal.
 */
public class ExportUtil {
    
    /**
     * Export JTable ke CSV file.
     */
    public static boolean exportTableToCSV(JTable table, String filePath) {
        try (FileWriter fw = new FileWriter(filePath);
             BufferedWriter bw = new BufferedWriter(fw)) {
            
            // Header
            for (int col = 0; col < table.getColumnCount(); col++) {
                bw.write(escapeCSV(table.getColumnName(col)));
                if (col < table.getColumnCount() - 1) bw.write(",");
            }
            bw.newLine();
            
            // Data
            for (int row = 0; row < table.getRowCount(); row++) {
                for (int col = 0; col < table.getColumnCount(); col++) {
                    Object value = table.getValueAt(row, col);
                    bw.write(escapeCSV(value != null ? value.toString() : ""));
                    if (col < table.getColumnCount() - 1) bw.write(",");
                }
                bw.newLine();
            }
            
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Export list of strings ke CSV file.
     */
    public static boolean exportToCSV(List<String[]> rows, String[] headers, String filePath) {
        try (FileWriter fw = new FileWriter(filePath);
             BufferedWriter bw = new BufferedWriter(fw)) {
            
            // Headers
            for (int i = 0; i < headers.length; i++) {
                bw.write(escapeCSV(headers[i]));
                if (i < headers.length - 1) bw.write(",");
            }
            bw.newLine();
            
            // Data rows
            for (String[] row : rows) {
                for (int i = 0; i < row.length; i++) {
                    bw.write(escapeCSV(row[i] != null ? row[i] : ""));
                    if (i < row.length - 1) bw.write(",");
                }
                bw.newLine();
            }
            
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Generate PDF report (placeholder - requires library).
     * Untuk implementasi lengkap, gunakan iText atau Apache PDFBox.
     */
    public static boolean exportToPDF(String title, List<String> data, String filePath) {
        try (FileWriter fw = new FileWriter(filePath);
             BufferedWriter bw = new BufferedWriter(fw)) {
            
            bw.write("=== " + title + " ===\n\n");
            for (String line : data) {
                bw.write(line + "\n");
            }
            
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Escape string untuk CSV format.
     */
    private static String escapeCSV(String value) {
        if (value == null) return "";
        
        if (value.contains(",") || value.contains("\"") || value.contains("\n")) {
            return "\"" + value.replace("\"", "\"\"") + "\"";
        }
        return value;
    }
    
    /**
     * Get file extension dari path.
     */
    public static String getFileExtension(String filePath) {
        int lastDot = filePath.lastIndexOf('.');
        return lastDot > 0 ? filePath.substring(lastDot + 1).toLowerCase() : "";
    }
    
    /**
     * Generate default filename dengan timestamp.
     */
    public static String generateDefaultFilename(String prefix, String extension) {
        String timestamp = new java.text.SimpleDateFormat("yyyyMMdd_HHmmss").format(new java.util.Date());
        return prefix + "_" + timestamp + "." + extension;
    }
}
