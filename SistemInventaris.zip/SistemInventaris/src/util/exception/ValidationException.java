package util.exception;

/**
 * ValidationException — Untuk error validasi input.
 */
public class ValidationException extends Exception {
    public ValidationException(String message) {
        super(message);
    }
    
    public ValidationException(String message, Throwable cause) {
        super(message, cause);
    }
}
