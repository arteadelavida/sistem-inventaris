package util.exception;

/**
 * BusinessException — Exception untuk business logic errors.
 * Berbeda dengan ValidationException, ini untuk rule violations.
 * 
 * Example:
 *   - Stock tidak cukup
 *   - Item sudah dikembalikan
 *   - Borrow limit exceeded
 */
public class BusinessException extends Exception {
    
    private String errorCode;
    private Object[] details;
    
    public BusinessException(String message) {
        super(message);
    }
    
    public BusinessException(String message, String errorCode) {
        super(message);
        this.errorCode = errorCode;
    }
    
    public BusinessException(String message, Throwable cause) {
        super(message, cause);
    }
    
    public BusinessException(String message, String errorCode, Object... details) {
        super(message);
        this.errorCode = errorCode;
        this.details = details;
    }
    
    public String getErrorCode() {
        return errorCode;
    }
    
    public Object[] getDetails() {
        return details;
    }
    
    @Override
    public String toString() {
        if (errorCode != null) {
            return "[" + errorCode + "] " + getMessage();
        }
        return getMessage();
    }
}
