package util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * LogService — mencatat aktivitas user ke tabel log_aktivitas.
 * Tabel dibuat otomatis jika belum ada.
 * Silent: tidak pernah melempar exception ke caller.
 */
public class LogService {

    static {
        ensureTable();
    }

    private static void ensureTable() {
        String sql =
            "CREATE TABLE IF NOT EXISTS log_aktivitas (" +
            "  id         INT AUTO_INCREMENT PRIMARY KEY," +
            "  username   VARCHAR(100)," +
            "  role       VARCHAR(20)," +
            "  aksi       VARCHAR(50)," +
            "  detail     TEXT," +
            "  waktu      DATETIME DEFAULT CURRENT_TIMESTAMP" +
            ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
        try (Connection c = DatabaseUtil.getInventarisConnection();
             Statement  s = c.createStatement()) {
            s.execute(sql);
        } catch (SQLException e) {
            System.err.println("[LogService] ensureTable: " + e.getMessage());
        }
    }

    /**
     * Catat aksi ke log_aktivitas. Silent — tidak crash app jika gagal.
     * @param aksi   jenis aksi: LOGIN, TAMBAH, UPDATE, HAPUS, APPROVE_USER, dsb.
     * @param detail keterangan bebas
     */
    public static void catat(String aksi, String detail) {
        String username = SessionManager.getUsername();
        String role     = SessionManager.getRole();
        String sql = "INSERT INTO log_aktivitas (username, role, aksi, detail) VALUES (?,?,?,?)";
        try (Connection c = DatabaseUtil.getInventarisConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, username != null ? username : "SYSTEM");
            ps.setString(2, role     != null ? role     : "unknown");
            ps.setString(3, aksi);
            ps.setString(4, detail);
            ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println("[LogService] Gagal catat: " + e.getMessage());
        }
    }
}
