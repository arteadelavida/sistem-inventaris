package util;

/**
 * SessionManager menyimpan data user yang sedang login secara global.
 * File ini TIDAK ADA di project asli, padahal banyak class merujuknya.
 */
public class SessionManager {

    private static String username;
    private static String role;

    /** Dipanggil saat login berhasil */
    public static void login(String username, String role) {
        SessionManager.username = username;
        SessionManager.role     = role;
    }

    /** Dipanggil saat logout */
    public static void logout() {
        SessionManager.username = null;
        SessionManager.role     = null;
    }

    public static String getUsername() { return username; }
    public static String getRole()     { return role; }

    /** Helper: apakah user yang login adalah admin? */
    public static boolean isAdmin() {
        return "admin".equalsIgnoreCase(role);
    }
}
