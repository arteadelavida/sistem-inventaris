package util.notification;

import javax.swing.*;

/**
 * NotificationUtil — Utility untuk menampilkan notifikasi dengan konsisten.
 */
public class NotificationUtil {
    
    /**
     * Tampilkan pesan sukses.
     */
    public static void showSuccess(JFrame parent, String message) {
        showMessage(parent, message, "Sukses", JOptionPane.INFORMATION_MESSAGE);
    }
    
    /**
     * Tampilkan pesan error.
     */
    public static void showError(JFrame parent, String message) {
        showMessage(parent, message, "Error", JOptionPane.ERROR_MESSAGE);
    }
    
    /**
     * Tampilkan pesan warning.
     */
    public static void showWarning(JFrame parent, String message) {
        showMessage(parent, message, "Peringatan", JOptionPane.WARNING_MESSAGE);
    }
    
    /**
     * Tampilkan pesan info.
     */
    public static void showInfo(JFrame parent, String message) {
        showMessage(parent, message, "Informasi", JOptionPane.INFORMATION_MESSAGE);
    }
    
    /**
     * Tampilkan dialog konfirmasi (Yes/No).
     */
    public static boolean showConfirm(JFrame parent, String message, String title) {
        return JOptionPane.showConfirmDialog(parent, message, title, JOptionPane.YES_NO_OPTION) 
            == JOptionPane.YES_OPTION;
    }
    
    /**
     * Tampilkan input dialog.
     */
    public static String showInput(JFrame parent, String prompt, String title) {
        return JOptionPane.showInputDialog(parent, prompt, title, JOptionPane.QUESTION_MESSAGE);
    }
    
    private static void showMessage(JFrame parent, String message, String title, int messageType) {
        JOptionPane.showMessageDialog(parent, message, title, messageType);
    }
}
