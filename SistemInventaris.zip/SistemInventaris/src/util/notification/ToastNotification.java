package util.notification;

import util.theme.ColorPalette;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.RoundRectangle2D;

/**
 * ToastNotification — Non-blocking notification untuk user feedback.
 * Auto-dismisses setelah timeout.
 * 
 * Usage:
 *   ToastNotification.showSuccess("Data saved successfully");
 *   ToastNotification.showError("Failed to save data");
 *   ToastNotification.showWarning("Action requires confirmation");
 *   ToastNotification.showInfo("Processing...");
 */
public class ToastNotification extends JWindow {
    
    public enum ToastType {
        SUCCESS, ERROR, WARNING, INFO
    }
    
    private ToastType type;
    private String message;
    private static final int DURATION = 4000; // 4 seconds
    private static final int WIDTH = 350;
    private static final int HEIGHT = 60;
    private static final int RADIUS = 10;
    
    private ToastNotification(ToastType type, String message) {
        this.type = type;
        this.message = message;
        
        initUI();
        positionBottomRight();
        startAutoHide();
    }
    
    private void initUI() {
        JPanel content = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                int w = getWidth();
                int h = getHeight();
                
                // Background dengan gradient
                Color bgColor = getBackgroundColor();
                g2d.setColor(bgColor);
                g2d.fillRoundRect(0, 0, w, h, RADIUS, RADIUS);
                
                // Border
                g2d.setStroke(new BasicStroke(1));
                g2d.setColor(getAccentColor());
                g2d.drawRoundRect(0, 0, w-1, h-1, RADIUS, RADIUS);
                
                // Icon
                g2d.setFont(new Font("SansSerif", Font.PLAIN, 16));
                g2d.setColor(getAccentColor());
                String icon = getIcon();
                g2d.drawString(icon, 15, 30);
                
                // Message
                g2d.setColor(ColorPalette.getTextMain());
                g2d.setFont(new Font("SansSerif", Font.PLAIN, 12));
                g2d.drawString(message, 45, 30);
            }
        };
        
        content.setOpaque(false);
        content.setLayout(null);
        add(content);
        
        setSize(WIDTH, HEIGHT);
        setLocationRelativeTo(null);
    }
    
    private Color getBackgroundColor() {
        switch (type) {
            case SUCCESS:
                return new Color(240, 250, 240);
            case ERROR:
                return new Color(255, 240, 240);
            case WARNING:
                return new Color(255, 250, 240);
            case INFO:
            default:
                return new Color(240, 245, 255);
        }
    }
    
    private Color getAccentColor() {
        switch (type) {
            case SUCCESS:
                return ColorPalette.getSuccess();
            case ERROR:
                return ColorPalette.getError();
            case WARNING:
                return ColorPalette.getWarning();
            case INFO:
            default:
                return ColorPalette.getInfo();
        }
    }
    
    private String getIcon() {
        switch (type) {
            case SUCCESS:
                return "✓";
            case ERROR:
                return "✕";
            case WARNING:
                return "⚠";
            case INFO:
            default:
                return "ℹ";
        }
    }
    
    private void positionBottomRight() {
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int x = screenSize.width - WIDTH - 20;
        int y = screenSize.height - HEIGHT - 80;
        setLocation(x, y);
    }
    
    private void startAutoHide() {
        Timer timer = new Timer(DURATION, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        timer.setRepeats(false);
        timer.start();
    }
    
    // Static factory methods
    public static void showSuccess(String message) {
        new ToastNotification(ToastType.SUCCESS, message).setVisible(true);
    }
    
    public static void showError(String message) {
        new ToastNotification(ToastType.ERROR, message).setVisible(true);
    }
    
    public static void showWarning(String message) {
        new ToastNotification(ToastType.WARNING, message).setVisible(true);
    }
    
    public static void showInfo(String message) {
        new ToastNotification(ToastType.INFO, message).setVisible(true);
    }
}
