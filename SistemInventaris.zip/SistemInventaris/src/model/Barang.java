package model;

/**
 * Model untuk data Barang.
 * Merepresentasikan satu baris di tabel 'barang'.
 */
public class Barang {

    private String kodeBarang;
    private String namaBarang;
    private int    harga;
    private int    stok;
    private String keterangan;

    public Barang() {}

    public Barang(String kodeBarang, String namaBarang, int harga, int stok, String keterangan) {
        this.kodeBarang  = kodeBarang;
        this.namaBarang  = namaBarang;
        this.harga       = harga;
        this.stok        = stok;
        this.keterangan  = keterangan;
    }

    // ── Getters ──────────────────────────────────────────────
    public String getKodeBarang()  { return kodeBarang; }
    public String getNamaBarang()  { return namaBarang; }
    public int    getHarga()       { return harga; }
    public int    getStok()        { return stok; }
    public String getKeterangan()  { return keterangan; }

    // ── Setters ──────────────────────────────────────────────
    public void setKodeBarang(String kodeBarang)  { this.kodeBarang = kodeBarang; }
    public void setNamaBarang(String namaBarang)  { this.namaBarang = namaBarang; }
    public void setHarga(int harga)               { this.harga = harga; }
    public void setStok(int stok)                 { this.stok = stok; }
    public void setKeterangan(String keterangan)  { this.keterangan = keterangan; }

    @Override
    public String toString() {
        return String.format("Barang{kode='%s', nama='%s', harga=%d, stok=%d}",
                kodeBarang, namaBarang, harga, stok);
    }
}
