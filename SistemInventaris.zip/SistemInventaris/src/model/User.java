package model;

/**
 * Model untuk data User.
 * Merepresentasikan satu baris di tabel 'users'.
 */
public class User {

    private int    id;
    private String username;
    private String password;
    private String role;   // "admin" atau "user"
    private String status; // "pending" atau "approved"

    public User() {}

    public User(int id, String username, String role, String status) {
        this.id       = id;
        this.username = username;
        this.role     = role;
        this.status   = status;
    }

    // ── Getters ──────────────────────────────────────────────
    public int    getId()       { return id; }
    public String getUsername() { return username; }
    public String getPassword() { return password; }
    public String getRole()     { return role; }
    public String getStatus()   { return status; }

    // ── Setters ──────────────────────────────────────────────
    public void setId(int id)             { this.id = id; }
    public void setUsername(String u)     { this.username = u; }
    public void setPassword(String p)     { this.password = p; }
    public void setRole(String r)         { this.role = r; }
    public void setStatus(String s)       { this.status = s; }

    /** Shortcut: apakah akun sudah disetujui? */
    public boolean isApproved() {
        return "active".equalsIgnoreCase(status);
    }

    @Override
    public String toString() {
        return String.format("User{id=%d, username='%s', role='%s', status='%s'}",
                id, username, role, status);
    }
}
