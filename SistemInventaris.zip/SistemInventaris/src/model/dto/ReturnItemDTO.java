package model.dto;

import java.time.LocalDate;

/**
 * ReturnItemDTO — Data Transfer Object untuk tracking pengembalian barang.
 * Digunakan untuk menampilkan status lengkap pengembalian.
 */
public class ReturnItemDTO {
    
    private int id;
    private int peminjamanId;
    private String username;
    private String kodeBarang;
    private String namaBarang;
    private int jumlahPinjam;              // Jumlah yang dipinjam
    private int jumlahDikembalikan;        // Jumlah yang dikembalikan
    private int jumlahBelumDikembalikan;   // Sisa yang belum dikembalikan
    private LocalDate tanggalPinjam;
    private LocalDate tanggalSeharusnyaKembali;
    private LocalDate tanggalKembaliAktual;
    private String kondisiBarang;          // "baik", "rusak ringan", "rusak berat", "hilang"
    private String statusPeminjaman;       // "pending", "approved", "rejected", "dikembalikan"
    private String statusPengembalian;     // "pending", "approved", "rejected"
    private String keterangan;
    private boolean terlambat;
    private int hariTerlambat;
    
    // Constructor
    public ReturnItemDTO() {}
    
    public ReturnItemDTO(int id, String username, String namaBarang, int jumlahPinjam, 
                        LocalDate tanggalPinjam, LocalDate tanggalSeharusnyaKembali) {
        this.id = id;
        this.username = username;
        this.namaBarang = namaBarang;
        this.jumlahPinjam = jumlahPinjam;
        this.tanggalPinjam = tanggalPinjam;
        this.tanggalSeharusnyaKembali = tanggalSeharusnyaKembali;
    }
    
    // Getters & Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public int getPeminjamanId() { return peminjamanId; }
    public void setPeminjamanId(int peminjamanId) { this.peminjamanId = peminjamanId; }
    
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    
    public String getKodeBarang() { return kodeBarang; }
    public void setKodeBarang(String kodeBarang) { this.kodeBarang = kodeBarang; }
    
    public String getNamaBarang() { return namaBarang; }
    public void setNamaBarang(String namaBarang) { this.namaBarang = namaBarang; }
    
    public int getJumlahPinjam() { return jumlahPinjam; }
    public void setJumlahPinjam(int jumlahPinjam) { this.jumlahPinjam = jumlahPinjam; }
    
    public int getJumlahDikembalikan() { return jumlahDikembalikan; }
    public void setJumlahDikembalikan(int jumlahDikembalikan) { 
        this.jumlahDikembalikan = jumlahDikembalikan;
        this.jumlahBelumDikembalikan = this.jumlahPinjam - jumlahDikembalikan;
    }
    
    public int getJumlahBelumDikembalikan() { return jumlahBelumDikembalikan; }
    public void setJumlahBelumDikembalikan(int jumlah) { this.jumlahBelumDikembalikan = jumlah; }
    
    public LocalDate getTanggalPinjam() { return tanggalPinjam; }
    public void setTanggalPinjam(LocalDate tanggalPinjam) { this.tanggalPinjam = tanggalPinjam; }
    
    public LocalDate getTanggalSeharusnyaKembali() { return tanggalSeharusnyaKembali; }
    public void setTanggalSeharusnyaKembali(LocalDate date) { this.tanggalSeharusnyaKembali = date; }
    
    public LocalDate getTanggalKembaliAktual() { return tanggalKembaliAktual; }
    public void setTanggalKembaliAktual(LocalDate date) { this.tanggalKembaliAktual = date; }
    
    public String getKondisiBarang() { return kondisiBarang; }
    public void setKondisiBarang(String kondisiBarang) { this.kondisiBarang = kondisiBarang; }
    
    public String getStatusPeminjaman() { return statusPeminjaman; }
    public void setStatusPeminjaman(String status) { this.statusPeminjaman = status; }
    
    public String getStatusPengembalian() { return statusPengembalian; }
    public void setStatusPengembalian(String status) { this.statusPengembalian = status; }
    
    public String getKeterangan() { return keterangan; }
    public void setKeterangan(String keterangan) { this.keterangan = keterangan; }
    
    public boolean isTerlambat() { return terlambat; }
    public void setTerlambat(boolean terlambat) { this.terlambat = terlambat; }
    
    public int getHariTerlambat() { return hariTerlambat; }
    public void setHariTerlambat(int hari) { this.hariTerlambat = hari; }
    
    @Override
    public String toString() {
        return String.format("ReturnItemDTO{user='%s', barang='%s', status='%s', " +
                "pinjam=%d, kembali=%d, sisa=%d}", 
                username, namaBarang, statusPengembalian, jumlahPinjam, 
                jumlahDikembalikan, jumlahBelumDikembalikan);
    }
}
