package model.dto;

import java.time.LocalDate;
import java.util.Map;

/**
 * DashboardDTO — Data Transfer Object untuk statistik dashboard.
 */
public class DashboardDTO {
    
    private int totalBarang;
    private int barangTersedia;
    private int barangDipinjam;
    private int barangRusakHilang;
    private int peminjamanPending;
    private int pengembalianPending;
    private int pengguna;
    private int penggunaAktif;
    
    // Recent activities
    private java.util.List<ActivityDTO> recentActivities;
    
    // Alerts
    private java.util.List<AlertDTO> alerts;
    
    // Charts data
    private Map<LocalDate, Integer> peminjamanPerBulan;  // Trend peminjaman
    private Map<String, Integer> barangPerKategori;      // Distribution by category (future)
    
    // Constructor
    public DashboardDTO() {
        this.recentActivities = new java.util.ArrayList<>();
        this.alerts = new java.util.ArrayList<>();
    }
    
    // Getters & Setters
    public int getTotalBarang() { return totalBarang; }
    public void setTotalBarang(int total) { this.totalBarang = total; }
    
    public int getBarangTersedia() { return barangTersedia; }
    public void setBarangTersedia(int tersedia) { this.barangTersedia = tersedia; }
    
    public int getBarangDipinjam() { return barangDipinjam; }
    public void setBarangDipinjam(int dipinjam) { this.barangDipinjam = dipinjam; }
    
    public int getBarangRusakHilang() { return barangRusakHilang; }
    public void setBarangRusakHilang(int rusak) { this.barangRusakHilang = rusak; }
    
    public int getPeminjamanPending() { return peminjamanPending; }
    public void setPeminjamanPending(int pending) { this.peminjamanPending = pending; }
    
    public int getPengembalianPending() { return pengembalianPending; }
    public void setPengembalianPending(int pending) { this.pengembalianPending = pending; }
    
    public int getPengguna() { return pengguna; }
    public void setPengguna(int pengguna) { this.pengguna = pengguna; }
    
    public int getPenggunaAktif() { return penggunaAktif; }
    public void setPenggunaAktif(int aktif) { this.penggunaAktif = aktif; }
    
    public java.util.List<ActivityDTO> getRecentActivities() { return recentActivities; }
    public void setRecentActivities(java.util.List<ActivityDTO> activities) { this.recentActivities = activities; }
    public void addActivity(ActivityDTO activity) { this.recentActivities.add(activity); }
    
    public java.util.List<AlertDTO> getAlerts() { return alerts; }
    public void setAlerts(java.util.List<AlertDTO> alerts) { this.alerts = alerts; }
    public void addAlert(AlertDTO alert) { this.alerts.add(alert); }
    
    public Map<LocalDate, Integer> getPeminjamanPerBulan() { return peminjamanPerBulan; }
    public void setPeminjamanPerBulan(Map<LocalDate, Integer> data) { this.peminjamanPerBulan = data; }
    
    public Map<String, Integer> getBarangPerKategori() { return barangPerKategori; }
    public void setBarangPerKategori(Map<String, Integer> data) { this.barangPerKategori = data; }
    
    @Override
    public String toString() {
        return String.format("DashboardDTO{total=%d, tersedia=%d, dipinjam=%d, " +
                "pending=%d, alerts=%d}", totalBarang, barangTersedia, barangDipinjam, 
                peminjamanPending, alerts.size());
    }
    
    // Inner class for Activity
    public static class ActivityDTO {
        public enum Type { PEMINJAMAN, PENGEMBALIAN, BARANG_BARU, BARANG_UPDATE }
        
        public String user;
        public Type type;
        public String detail;
        public LocalDate tanggal;
        public String icon;
        
        public ActivityDTO(String user, Type type, String detail, LocalDate tanggal) {
            this.user = user;
            this.type = type;
            this.detail = detail;
            this.tanggal = tanggal;
            this.icon = getIconForType(type);
        }
        
        private String getIconForType(Type type) {
            switch(type) {
                case PEMINJAMAN: return "📤";
                case PENGEMBALIAN: return "📥";
                case BARANG_BARU: return "➕";
                case BARANG_UPDATE: return "✏️";
                default: return "";
            }
        }
    }
    
    // Inner class for Alert
    public static class AlertDTO {
        public enum Severity { INFO, WARNING, ERROR }
        
        public String title;
        public String message;
        public Severity severity;
        public LocalDate tanggal;
        
        public AlertDTO(String title, String message, Severity severity) {
            this.title = title;
            this.message = message;
            this.severity = severity;
            this.tanggal = LocalDate.now();
        }
    }
}
