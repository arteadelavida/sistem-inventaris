package model;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * ReturnItem — Model untuk tracking pengembalian barang
 * dengan kondisi barang dan approval admin.
 */
public class ReturnItem {
    private int id;
    private int peminjamanId;
    private String username;
    private String kodeBarang;
    private String namaBarang;
    private int jumlahDikembalikan;
    private LocalDate tanggalReturn;
    private String kondisiBarang; // baik, rusak ringan, rusak berat
    private String keterangan;
    private String status; // pending, approved, rejected
    private String disetujuiOleh;
    private LocalDateTime tanggalDisetujui;
    private LocalDateTime createdAt;

    public ReturnItem(int peminjamanId, String username, String kodeBarang, 
                      String namaBarang, int jumlahDikembalikan, 
                      LocalDate tanggalReturn, String kondisiBarang, String keterangan) {
        this.peminjamanId = peminjamanId;
        this.username = username;
        this.kodeBarang = kodeBarang;
        this.namaBarang = namaBarang;
        this.jumlahDikembalikan = jumlahDikembalikan;
        this.tanggalReturn = tanggalReturn;
        this.kondisiBarang = kondisiBarang;
        this.keterangan = keterangan;
        this.status = "pending";
        this.createdAt = LocalDateTime.now();
    }

    // GETTER
    public int getId() { return id; }
    public int getPeminjamanId() { return peminjamanId; }
    public String getUsername() { return username; }
    public String getKodeBarang() { return kodeBarang; }
    public String getNamaBarang() { return namaBarang; }
    public int getJumlahDikembalikan() { return jumlahDikembalikan; }
    public LocalDate getTanggalReturn() { return tanggalReturn; }
    public String getKondisiBarang() { return kondisiBarang; }
    public String getKeterangan() { return keterangan; }
    public String getStatus() { return status; }
    public String getDisetujuiOleh() { return disetujuiOleh; }
    public LocalDateTime getTanggalDisetujui() { return tanggalDisetujui; }
    public LocalDateTime getCreatedAt() { return createdAt; }

    // SETTER
    public void setId(int id) { this.id = id; }
    public void setStatus(String status) { this.status = status; }
    public void setDisetujuiOleh(String disetujuiOleh) { this.disetujuiOleh = disetujuiOleh; }
    public void setTanggalDisetujui(LocalDateTime tanggalDisetujui) { this.tanggalDisetujui = tanggalDisetujui; }
}
