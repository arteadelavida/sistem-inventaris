package model;

import java.time.LocalDateTime;

/**
 * PasswordResetRequest — Model untuk tracking permintaan reset password
 * dengan approval dari admin.
 */
public class PasswordResetRequest {
    private int id;
    private String username;
    private String email;
    private String token;
    private String reason;
    private String status; // pending, approved, rejected
    private String approvedBy;
    private LocalDateTime approvedAt;
    private LocalDateTime rejectedAt;
    private LocalDateTime createdAt;

    public PasswordResetRequest(String username, String email, String token, String reason) {
        this.username = username;
        this.email = email;
        this.token = token;
        this.reason = reason;
        this.status = "pending";
        this.createdAt = LocalDateTime.now();
    }

    // GETTER
    public int getId() { return id; }
    public String getUsername() { return username; }
    public String getEmail() { return email; }
    public String getToken() { return token; }
    public String getReason() { return reason; }
    public String getStatus() { return status; }
    public String getApprovedBy() { return approvedBy; }
    public LocalDateTime getApprovedAt() { return approvedAt; }
    public LocalDateTime getRejectedAt() { return rejectedAt; }
    public LocalDateTime getCreatedAt() { return createdAt; }

    // SETTER
    public void setId(int id) { this.id = id; }
    public void setStatus(String status) { this.status = status; }
    public void setApprovedBy(String approvedBy) { this.approvedBy = approvedBy; }
    public void setApprovedAt(LocalDateTime approvedAt) { this.approvedAt = approvedAt; }
    public void setRejectedAt(LocalDateTime rejectedAt) { this.rejectedAt = rejectedAt; }
}
