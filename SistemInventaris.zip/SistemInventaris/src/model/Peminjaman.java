package model;

import java.time.LocalDate;

public class Peminjaman {
    private int id;
    private String username;
    private String kodeBarang;
    private String namaBarang;
    private int jumlah;

    // FITUR BARU
    private LocalDate tanggalPinjam;
    private LocalDate tanggalKembali;
    private String status;
    private String statusReturn;  // NEW: track if returned (belum_dikembalikan, dikembalikan)
    private String keteranganAdmin;

    // CONSTRUCTOR BARU
    public Peminjaman(String username, String kodeBarang, String namaBarang, int jumlah, LocalDate tanggalKembali) {
        this.username = username;
        this.kodeBarang = kodeBarang;
        this.namaBarang = namaBarang;
        this.jumlah = jumlah;
        this.tanggalPinjam = LocalDate.now();
        this.tanggalKembali = tanggalKembali;
        this.status = "pending";
        this.statusReturn = "belum_dikembalikan";
        this.keteranganAdmin = "-";
    }

    // GETTER
    public int getId() { return id; }
    public String getUsername() { return username; }
    public String getKodeBarang() { return kodeBarang; }
    public String getNamaBarang() { return namaBarang; }
    public int getJumlah() { return jumlah; }
    public LocalDate getTanggalPinjam() { return tanggalPinjam; }
    public LocalDate getTanggalKembali() { return tanggalKembali; }
    public String getStatus() { return status; }
    public String getStatusReturn() { return statusReturn; }
    public String getKeteranganAdmin() { return keteranganAdmin; }

    // SETTER
    public void setId(int id) { this.id = id; }
    public void setStatus(String status) { this.status = status; }
    public void setStatusReturn(String statusReturn) { this.statusReturn = statusReturn; }
    public void setKeteranganAdmin(String ket) { this.keteranganAdmin = ket; }
    public void setTanggalPinjam(LocalDate tanggal) { this.tanggalPinjam = tanggal; }
    public void setTanggalKembali(LocalDate tanggal) { this.tanggalKembali = tanggal; }
}