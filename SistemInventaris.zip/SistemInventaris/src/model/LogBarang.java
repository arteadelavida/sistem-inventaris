package model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Model satu baris log barang masuk / barang keluar.
 * Field tipeAksi: "MASUK" atau "KELUAR".
 */
public class LogBarang {

    private static final DateTimeFormatter FMT =
        DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    private int           id;
    private String        kodeBarang;
    private String        namaBarang;
    private String        tipeAksi;       // "MASUK" | "KELUAR"
    private int           jumlah;
    private String        keterangan;
    private String        username;
    private LocalDateTime tanggal;

    public LogBarang() {}

    public LogBarang(String kodeBarang, String namaBarang,
                     String tipeAksi, int jumlah,
                     String keterangan, String username) {
        this.kodeBarang  = kodeBarang  != null ? kodeBarang  : "";
        this.namaBarang  = namaBarang  != null ? namaBarang  : "";
        this.tipeAksi    = tipeAksi    != null ? tipeAksi    : "";
        this.jumlah      = jumlah;
        this.keterangan  = keterangan  != null ? keterangan  : "";
        this.username    = username    != null ? username    : "system";
        this.tanggal     = LocalDateTime.now();
    }

    // ── Getters ──────────────────────────────────────────────────
    public int           getId()          { return id; }
    public String        getKodeBarang()  { return kodeBarang; }
    public String        getNamaBarang()  { return namaBarang; }
    public String        getTipeAksi()    { return tipeAksi; }
    public int           getJumlah()      { return jumlah; }
    public String        getKeterangan()  { return keterangan; }
    public String        getUsername()    { return username; }
    public LocalDateTime getTanggal()     { return tanggal; }

    /** Formatted tanggal untuk tampil di tabel */
    public String getTanggalFormatted() {
        return tanggal != null ? tanggal.format(FMT) : "-";
    }

    // ── Setters ──────────────────────────────────────────────────
    public void setId(int id)                       { this.id = id; }
    public void setTanggal(LocalDateTime tanggal)   { this.tanggal = tanggal; }
}
