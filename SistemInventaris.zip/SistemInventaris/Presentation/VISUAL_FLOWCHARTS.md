# 📊 VISUAL FLOWCHARTS - Untuk Presentasi

Gunakan flowchart ini saat menjelaskan kepada dosen.

---

## 1. SISTEM OVERVIEW - 1 Slide

```
┌──────────────────────────────────────────────────────────────────┐
│                   SISTEM INVENTARIS ENTERPRISE                   │
│                   Multi-User | Audit Trail | Real-time Analytics │
├──────────────────────────────────────────────────────────────────┤
│                                                                   │
│     ┌─────────────┐                    ┌─────────────┐           │
│     │   ADMIN     │                    │    USER     │           │
│     │             │                    │             │           │
│     │ • Manage    │                    │ • View      │           │
│     │   Barang    │◄───────────────►   │ • Pinjam    │           │
│     │ • Approve   │                    │ • Return    │           │
│     │ • View Logs │                    │             │           │
│     └──────┬──────┘                    └──────┬──────┘           │
│            │                                   │                 │
│            └──────────────┬────────────────────┘                 │
│                           │                                      │
│                    ┌──────▼──────┐                               │
│                    │   BACKEND    │                              │
│                    │   (Services) │                              │
│                    │   (Business  │                              │
│                    │    Logic)    │                              │
│                    └──────┬───────┘                              │
│                           │                                      │
│        ┌──────────────────┼──────────────────┐                   │
│        │                  │                  │                   │
│   ┌────▼────┐        ┌───▼────┐       ┌────▼────┐              │
│   │  MySQL  │        │  MySQL │       │  MySQL  │              │
│   │ login   │        │sistem  │       │ Logs    │              │
│   │ DB      │        │invent  │       │(Audit)  │              │
│   └─────────┘        │ DB     │       │         │              │
│                      └────────┘       └─────────┘              │
│                                                                   │
└──────────────────────────────────────────────────────────────────┘
```

---

## 2. LOGIN SYSTEM - 2 Slides

### Slide A: Authentication Flow

```
┌─────────────────────────────────┐
│      USER MASUK KE SISTEM       │
│                                 │
│  [LoginView]                    │
│  Username: ________             │
│  Password: ________             │
│  [LOGIN BUTTON]                 │
└────────────────┬────────────────┘
                 │
          ┌──────▼──────┐
          │   Validasi   │
          │ username &   │
          │ password     │
          └──────┬───────┘
                 │
        ┌────────┴────────┐
        │                 │
   ┌────▼─────┐     ┌────▼─────┐
   │  VALID   │     │ INVALID   │
   │           │     │           │
   └────┬─────┘     └────┬─────┘
        │                │
   ┌────▼─────────────────▼─────┐
   │ UPDATE SessionManager      │
   │ - currentUser = username   │
   │ - currentRole = role       │
   └────────────────┬───────────┘
                    │
        ┌───────────▼────────────┐
        │  Route ke halaman      │
        │  berdasarkan role      │
        └───────────┬────────────┘
                    │
         ┌──────────┴──────────┐
         │                     │
    ┌────▼─────┐        ┌────▼─────┐
    │  ADMIN   │        │   USER    │
    │          │        │           │
    │Dashboard │        │Dashboard  │
    │(Admin)   │        │(Simple)   │
    └──────────┘        └───────────┘
```

### Slide B: Registration Flow

```
[RegisterView]
Username: ________
Email: ________
Password: ________
[REGISTER]
   │
   ▼
ValidationUtil.validate()
├─ Username unique?
├─ Password strong?
└─ Email format valid?
   │
   ├─ YES ──► UserController.register()
   │          │
   │          ├─ Hash password
   │          ├─ INSERT users table
   │          └─ Status = "pending"
   │
   └─ NO  ──► Show error message
             (Username taken / weak password)

Result: "Silakan tunggu approval dari admin"
Admin masuk ke UserManagementView → approve user
Baru user bisa login
```

---

## 3. ADMIN FEATURES - 3 Slides

### Slide A: Manajemen Barang

```
╔═══════════════════════════════════╗
║   BARANG MANAGEMENT               ║
║   Admin Menu → Manage Barang       ║
╚═════════════╤═════════════════════╝
              │
    ┌─────────┼─────────┐
    │         │         │
┌───▼──┐ ┌───▼──┐ ┌───▼──┐ ┌───▼──┐
│LIHAT │ │TAMBAH│ │EDIT  │ │HAPUS │
└───┬──┘ └───┬──┘ └───┬──┘ └───┬──┘
    │        │        │        │
    │    ┌───▼─────────────────┐
    │    │ Form Input:         │
    │    │ - Kode Barang       │
    │    │ - Nama              │
    │    │ - Harga             │
    │    │ - Stok              │
    │    └───┬─────────────────┘
    │        │
    │    ┌───▼────────────────────┐
    │    │ ValidationUtil:        │
    │    │ - Format valid?        │
    │    │ - Kode unik?           │
    │    │ - Nilai numeric?       │
    │    └───┬────────────────────┘
    │        │
    │    ┌───▼──────────────────────┐
    │    │ BarangController:        │
    │    │ - INSERT/UPDATE/DELETE   │
    │    │   ke database            │
    │    └───┬──────────────────────┘
    │        │
    │    ┌───▼────────────────────┐
    │    │ LogBarangController:   │
    │    │ - LOGKAN AKTIVITAS     │
    │    └────────────────────────┘
    │
    └──► JTable refresh ► User lihat perubahan
         
Status: ✅ Barang berhasil diupdate
Logs:   🔐 Admin added BRG001 Laptop at 14:30
```

### Slide B: Approve Returns

```
╔═══════════════════════════════════╗
║   RETURN ITEM APPROVAL             ║
║   Admin Menu → Approve Returns     ║
╚═════════════╤═════════════════════╝
              │
    ┌─────────▼──────────────┐
    │ Lihat Return Requests  │
    │ Status = PENDING       │
    │                        │
    │ ID  │ User │ Barang    │
    │ ────┼──────┼───────    │
    │ #1  │user1 │Laptop    │
    │ #2  │user2 │Monitor   │
    └─────────┬──────────────┘
              │
    ┌─────────▼──────────────────────┐
    │ Admin review kondisi barang:   │
    │ - Baik / Rusak / Hilang        │
    │ - Lihat catatan dari user      │
    └─────────┬──────────────────────┘
              │
        ┌─────┴────────┐
        │              │
    ┌───▼────┐    ┌───▼────┐
    │APPROVE │    │ REJECT │
    └───┬────┘    └────────┘
        │
    ┌───▼─────────────────────────┐
    │ ReturnItemController:       │
    │ ├─ UPDATE status="approved" │
    │ ├─ UPDATE stok += 1         │
    │ ├─ Log aktivitas            │
    │ └─ Kirim notifikasi ke user │
    └──────────────────────────────┘

Status: ✅ Return disetujui
Stok:   📦 Laptop stok naik dari 3 → 4
Logs:   🔐 Admin approved return #1 at 15:45
```

### Slide C: Dashboard Analytics

```
╔═══════════════════════════════════╗
║   ADMIN DASHBOARD                 ║
║   Real-time Statistics & Alerts   ║
╚═════════════╤═════════════════════╝
              │
    ┌─────────▼─────────────────────┐
    │ Load statistics (async):      │
    │ • Total Barang: 45            │
    │ • Total Stok: 230             │
    │ • Peminjaman Aktif: 12        │
    │ • Item Terlambat: 2           │
    │ • Return Pending: 3           │
    └─────────┬─────────────────────┘
              │
    ┌─────────▼─────────────────────┐
    │ Generate Charts:              │
    │ • Monthly loan trends         │
    │ • Top 10 borrowed items       │
    │ • User activity heatmap       │
    │ • Inventory status pie        │
    └─────────┬─────────────────────┘
              │
    ┌─────────▼─────────────────────┐
    │ Display Alerts:               │
    │ ⚠️  Low stock items (< 5)     │
    │ ⚠️  Overdue loans             │
    │ ⚠️  Return requests > 7 hari   │
    │ ⚠️  Suspicious activities      │
    └─────────────────────────────────┘
```

---

## 4. USER FEATURES - 2 Slides

### Slide A: Peminjaman Barang

```
╔═══════════════════════════════════╗
║   USER PINJAM BARANG              ║
║   User Menu → Pinjam Barang       ║
╚═════════════╤═════════════════════╝
              │
    ┌─────────▼──────────────┐
    │ Lihat daftar barang:   │
    │ • Laptop               │
    │ • Monitor              │
    │ • Mouse                │
    └─────────┬──────────────┘
              │
    ┌─────────▼─────────────────┐
    │ Select barang → Laptop    │
    │ Check: Stok > 0?          │
    └─────────┬─────────────────┘
              │
        ┌─────┴─────────────┐
        │                   │
   ┌────▼───┐          ┌───▼────┐
   │ STOK OK │          │NO STOK │
   └────┬───┘          └────────┘
        │               (Disable form)
    ┌───▼─────────────────────┐
    │ Input target return:    │
    │ Tanggal: _________      │
    │ (Next 7 days)           │
    └───┬─────────────────────┘
        │
    ┌───▼──────────────────────────┐
    │ Validation:                  │
    │ • Format date valid?         │
    │ • Max items check?           │
    │ • Business rules?            │
    └───┬──────────────────────────┘
        │
    ┌───▼────────────────────────┐
    │ PeminjamanController:      │
    │ ├─ INSERT peminjaman      │
    │ ├─ UPDATE stok -= 1       │
    │ ├─ Log aktivitas          │
    │ └─ Notif ke admin         │
    └────────────────────────────┘

Status: ✅ Peminjaman tercatat
        📧 Admin akan dinotifikasi
```

### Slide B: Return Barang

```
╔═══════════════════════════════════╗
║   USER KEMBALIKAN BARANG          ║
║   User Menu → Lihat Peminjaman    ║
╚═════════════╤═════════════════════╝
              │
    ┌─────────▼──────────────┐
    │ Lihat barang dipinjam: │
    │ • Laptop (dipinjam 3hr)│
    │ • Monitor (dipinjam 1d)│
    └─────────┬──────────────┘
              │
    ┌─────────▼────────────────┐
    │ Click "Return" button    │
    │ pada barang tertentu     │
    └─────────┬────────────────┘
              │
    ┌─────────▼───────────────────┐
    │ Return Request Form:        │
    │ Kondisi:                    │
    │  ○ Baik      ○ Rusak ○ Hilang
    │ Catatan: _______________   │
    │ [Submit]                   │
    └─────────┬───────────────────┘
              │
    ┌─────────▼──────────────────────┐
    │ Validation:                    │
    │ • Kondisi dipilih?             │
    │ • Format valid?                │
    └─────────┬──────────────────────┘
              │
    ┌─────────▼─────────────────────┐
    │ ReturnItemController:         │
    │ ├─ INSERT return request      │
    │ ├─ Status = "pending"         │
    │ ├─ Log aktivitas              │
    │ └─ Notif ke admin approval    │
    └─────────────────────────────────┘

Status: ✅ Return request dikirim
        ⏳ Tunggu admin approval
        
[Admin akan approve & stok akan otomatis kembali]
```

---

## 5. AUDIT TRAIL - 1 Slide

```
╔═════════════════════════════════════════════╗
║   ACTIVITY LOG (Audit Trail)                ║
║   Admin Menu → View Logs                    ║
╚═════════════╤═════════════════════════════════╝
              │
    ┌─────────▼──────────────────────────────┐
    │ Filter & Search:                       │
    │ • By user / date / action              │
    │ • Sort by timestamp                    │
    │ • Export to CSV                        │
    └─────────┬──────────────────────────────┘
              │
    ┌─────────▼──────────────────────────────┐
    │ Display Log Table:                     │
    │                                        │
    │ Time    │ User  │ Action    │ Detail   │
    │ ───────┼───────┼───────────┼──────    │
    │ 14:30  │ admin │ INSERT    │ BRG001   │
    │ 14:35  │ admin │ UPDATE    │ stok: 3→5
    │ 14:40  │ user1 │ BORROW    │ Laptop   │
    │ 15:00  │ user1 │ RETURN_REQ│ Laptop   │
    │ 15:45  │ admin │ APPROVE   │ Return#1 │
    │        │       │           │          │
    │        │  ... (more records)          │
    │                                        │
    └──────────────────────────────────────────┘
              │
    ┌─────────▼──────────────────────────────┐
    │ Features:                              │
    │ • Download CSV (untuk audit)           │
    │ • Print report                         │
    │ • Cannot delete (append-only)          │
    │ • Timestamp immutable                  │
    └──────────────────────────────────────────┘
```

---

## 6. DATABASE SCHEMA VISUAL - 1 Slide

```
┌─────────────────────┐           ┌─────────────────────────┐
│   DATABASE: login   │           │DATABASE: sisteminventaris
├─────────────────────┤           ├─────────────────────────┤
│ users               │           │ barang                  │
│ ┌─────────────────┐ │           │ ┌─────────────────────┐ │
│ │ id (PK)         │ │           │ │ kode_barang (PK)   │ │
│ │ username (UQ)   │◄─┼───FK─────┼─┤ nama_barang        │ │
│ │ password        │ │  │        │ │ harga              │ │
│ │ role            │ │  │        │ │ stok               │ │
│ │ status          │ │  │        │ │ keterangan         │ │
│ └─────────────────┘ │  │        │ └─────────────────────┘ │
└─────────────────────┘  │        │                         │
                         │        │ peminjaman              │
                         │        │ ┌─────────────────────┐ │
                         │        │ │ id_peminjaman (PK) │ │
                         │        │ │ id_user (FK)       │◄┼──┐
                         │        │ │ kode_barang (FK)   │◄┼──┤
                         │        │ │ tgl_pinjam         │ │  │
                         │        │ │ tgl_target_kembali │ │  │
                         │        │ │ status             │ │  │
                         │        │ └──────────┬──────────┘ │  │
                         │        │            │            │  │
                         │        │ return_items           │  │
                         │        │ ┌──────────▼──────────┐│  │
                         │        │ │ id_return (PK)    ││  │
                         │        │ │ id_peminjaman (FK)││  │
                         │        │ │ tgl_pengembalian  ││  │
                         │        │ │ kondisi_barang    ││  │
                         │        │ │ catatan           ││  │
                         │        │ └───────────────────┘│  │
                         │        │                      │  │
                         │        │ log_barang           │  │
                         │        │ ┌──────────────────┐ │  │
                         │        │ │ id_log (PK)    ││  │
                         │        │ │ tgl_log        ││  │
                         │        │ │ aksi           ││  │
                         │        │ │ detail_perubahan││  │
                         │        │ │ nama_user      ││──┘
                         │        │ └───────────────────┘ │
                         │        │                       │
                         └─────────────────────────────────┘
```

---

## 7. SYSTEM CALL SEQUENCE - 1 Slide

```
┌─────────────┐         ┌──────────────┐        ┌────────────┐       ┌──────────────┐
│   Frontend  │         │   Service    │        │ Controller │       │   Database   │
│   (Swing)   │         │   (Logic)    │        │    (DAO)   │       │   (MySQL)    │
└──────┬──────┘         └──────┬───────┘        └──────┬─────┘       └──────┬───────┘
       │                       │                       │                    │
       │ 1. Click "Pinjam"     │                       │                    │
       ├──────────────────────►│                       │                    │
       │                       │ 2. Validate           │                    │
       │                       ├─────────────────────► │                    │
       │                       │                       │ 3. Query Barang    │
       │                       │                       ├──────────────────► │
       │                       │                       │                    │
       │                       │                       │ Stok: 5◄───────────┤
       │                       │◄──────────────────────┤                    │
       │                       │ (OK, stok > 0)        │                    │
       │                       │                       │ 4. INSERT Peminjaman
       │                       │                       ├──────────────────► │
       │                       │                       │                    │
       │                       │                       │ 5. UPDATE stok -= 1
       │                       │                       ├──────────────────► │
       │                       │                       │                    │
       │                       │                       │ 6. INSERT Log      │
       │                       │                       ├──────────────────► │
       │                       │                       │                    │
       │                       │◄──────────────────────┤ OK ◄───────────────┤
       │ 7. Show Success ◄─────┤                       │                    │
       │                       │                       │                    │
```

---

## 8. TECH STACK DIAGRAM - 1 Slide

```
┌────────────────────────────────────────────────────────────────┐
│                       SISTEM INVENTARIS                         │
│                         Tech Stack                              │
├────────────────────────────────────────────────────────────────┤
│                                                                 │
│  PRESENTATION LAYER                                            │
│  ┌────────────────────────────────────────────────────────┐   │
│  │ Java Swing (JFrame, JPanel, JTable, JButton, etc)     │   │
│  │ • Custom components (RoundedButton, ModernCard, etc)  │   │
│  │ • Multi-threaded (SwingWorker for async ops)          │   │
│  └────────────────────────────────────────────────────────┘   │
│                                                                 │
│  BUSINESS LOGIC LAYER                                          │
│  ┌────────────────────────────────────────────────────────┐   │
│  │ Service Classes                                        │   │
│  │ • BarangService, PeminjamanService, etc               │   │
│  │ • Validation & Business Rules                         │   │
│  │ SessionManager, LogService, etc                       │   │
│  └────────────────────────────────────────────────────────┘   │
│                                                                 │
│  DATA ACCESS LAYER                                             │
│  ┌────────────────────────────────────────────────────────┐   │
│  │ Controllers (DAO Pattern)                             │   │
│  │ • BarangController, PeminjamanController, etc         │   │
│  │ • SQL Queries using PreparedStatement                 │   │
│  │ DatabaseUtil (Connection Pool)                        │   │
│  └────────────────────────────────────────────────────────┘   │
│                                                                 │
│  DATABASE LAYER                                                │
│  ┌────────────────────────────────────────────────────────┐   │
│  │ MySQL 5.7+ / MariaDB 10.3+                            │   │
│  │ • login database (authentication)                     │   │
│  │ • sisteminventaris database (business data)           │   │
│  │ • mysql-connector-j (JDBC driver)                     │   │
│  └────────────────────────────────────────────────────────┘   │
│                                                                 │
│  DEPLOYMENT                                                    │
│  ┌────────────────────────────────────────────────────────┐   │
│  │ Single JAR + MySQL Server                             │   │
│  │ Cross-platform: Windows / Mac / Linux                 │   │
│  │ Minimal dependencies (just MySQL connector)           │   │
│  └────────────────────────────────────────────────────────┘   │
│                                                                 │
└────────────────────────────────────────────────────────────────┘
```

---

## Quick Copy-Paste Tips untuk Presentasi:

### Untuk explain MVC:
"Model adalah struktur data, View adalah UI yang dilihat user, 
Controller adalah logic yang menghubungkan antara database dengan UI."

### Untuk explain Audit Trail:
"Setiap perubahan di sistem tercatat dengan timestamp, siapa yang melakukan, 
dan apa yang diubah. Ini tidak bisa dihapus untuk memastikan compliance dan 
memudahkan untuk investigate jika ada masalah."

### Untuk explain Workflow Peminjaman:
"Ada 3 tahap: User submit peminjaman, Admin approve dengan check kondisi, 
Stok otomatis update. Ini memastikan tidak ada barang yang hilang 
dan ada clear accountability."

---

**Print atau screenshot diagram ini untuk di-project ke layar saat presentasi!**
