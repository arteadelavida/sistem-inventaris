# VISUAL SUMMARY & KEY CODE EXAMPLES

## 1. FLOW DIAGRAM UNTUK PRESENTASI

### Login Flow
```
START
  |
  v
LoginView (Username, Password form)
  |
  v
Input credentials
  |
  v
AuthController.login(username, password)
  |
  +-- Cek di database users
  |
  +-- Valid?
      |
      +-- YES --> SessionManager.setSession(user)
      |          |
      |          v
      |          DashboardView
      |
      +-- NO  --> Show error message
                  |
                  v
                  Back to LoginView
```

### Peminjaman Approval Flow
```
User ajukan pinjam
  |
  v
ValidationUtil check:
  - Username valid?
  - Barang ada?
  - Stok cukup?
  - Tanggal valid?
  |
  +-- Error? --> Show message, back to form
  |
  +-- OK --> Insert ke DB (status: pending)
       |
       v
Admin lihat pending list
       |
       v
Admin click Setujui
       |
       v
PeminjamanController.setujui(id)
       |
       +-- Update peminjaman status = "disetujui"
       +-- BarangController.decreaseStock()
       +-- LogService.catat(action, detail)
       |
       v
Return success message
```

### Dashboard Load Flow
```
User buka Dashboard
       |
       v
Async SwingWorker start
       |
       +-- Query 1: SELECT COUNT(*) FROM barang (total)
       +-- Query 2: SELECT SUM(stok) FROM barang (available)
       +-- Query 3: SELECT * FROM peminjaman WHERE status='pending' (pending count)
       +-- Query 4: SELECT * FROM peminjaman WHERE tanggal_kembali < TODAY (overdue)
       |
       v
DashboardDTO assemble results
       |
       v
ModernDashboardView.refreshUI()
       |
       v
Display cards:
  - Total Barang: X
  - Barang Tersedia: Y
  - Peminjaman Pending: Z
  - Alert: X item stok rendah, Y item overdue
```

---

## 2. KEY CODE SNIPPETS UNTUK DITUNJUK

### Snippet 1: Validation (Service Layer)
```java
// File: PeminjamanService.java
public void ajukanPeminjamanWithValidation(
        String username, String kodeBarang, 
        int jumlah, LocalDate tanggalKembali) 
    throws ValidationException, SQLException {
    
    // 1. Validasi input tidak kosong/invalid
    ValidationUtil.requireNotEmpty(username, "Username");
    ValidationUtil.requireNotEmpty(kodeBarang, "Kode barang");
    ValidationUtil.requirePositive(jumlah, "Jumlah");
    ValidationUtil.requireValidReturnDate(tanggalKembali);
    
    // 2. Validasi business rule (stok cukup?)
    Barang barang = barangCtrl.getBarangByKode(kodeBarang);
    if (barang == null) {
        throw new ValidationException(
            "Barang dengan kode '" + kodeBarang + "' tidak ditemukan");
    }
    
    if (barang.getStok() < jumlah) {
        throw new ValidationException(
            "Stok " + barang.getNamaBarang() + " tidak cukup. " +
            "Tersedia: " + barang.getStok() + ", diminta: " + jumlah);
    }
    
    // 3. Create & persist peminjaman
    Peminjaman peminjaman = new Peminjaman(
        username, kodeBarang, barang.getNamaBarang(), 
        jumlah, tanggalKembali);
    
    peminjamanCtrl.ajukanPeminjaman(peminjaman);
    
    // 4. Log untuk audit trail
    logOperation("AJUKAN_PINJAM",
        username + " ajukan pinjam " + jumlah + "x " + 
        barang.getNamaBarang() + " hingga " + tanggalKembali);
}
```

**Key points:**
- Input validation terpisah per field
- Business logic validation (stok, barang exists)
- Create object baru sebelum insert
- Log setiap aksi penting

---

### Snippet 2: Safe Database Query (SQL Injection Prevention)
```java
// File: AuthController.java
public User login(String username, String password) throws SQLException {
    // SAFE: Gunakan PreparedStatement dengan parameter binding
    String sql = "SELECT id, username, role FROM users " +
                 "WHERE username = ? AND password = ?";
    
    try (Connection conn = DatabaseUtil.getLoginConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {
        
        ps.setString(1, username);      // Parameter 1
        ps.setString(2, password);      // Parameter 2
        
        try (ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                return new User(
                    rs.getInt("id"),
                    rs.getString("username"),
                    rs.getString("role")
                );
            }
        }
    }
    return null;
}
```

**Why safe:**
- PreparedStatement compile SQL terlebih dahulu
- Parameter di-escape otomatis, treated sebagai data bukan code
- Jika user input: `admin' OR '1'='1`, treated sebagai literal string

---

### Snippet 3: Transaction untuk Atomic Operation
```java
// File: PeminjamanController.java
public void setujuiDenganKeterangan(int peminjamanId, String keterangan) 
        throws SQLException {
    
    Connection conn = DatabaseUtil.getInventarisConnection();
    conn.setAutoCommit(false);  // Start transaction
    
    try {
        // Step 1: Update peminjaman status
        String sql1 = "UPDATE peminjaman SET status='disetujui', " +
                      "keterangan_admin=? WHERE id=?";
        try (PreparedStatement ps1 = conn.prepareStatement(sql1)) {
            ps1.setString(1, keterangan);
            ps1.setInt(2, peminjamanId);
            ps1.executeUpdate();
        }
        
        // Step 2: Decrease barang stock (atomic dengan step 1)
        Peminjaman p = getById(peminjamanId);
        String sql2 = "UPDATE barang SET stok=stok-? WHERE kode_barang=?";
        try (PreparedStatement ps2 = conn.prepareStatement(sql2)) {
            ps2.setInt(1, p.getJumlah());
            ps2.setString(2, p.getKodeBarang());
            ps2.executeUpdate();
        }
        
        conn.commit();  // Commit both atau rollback both
        
    } catch (SQLException e) {
        conn.rollback();  // Rollback jika ada error
        throw e;
    } finally {
        conn.setAutoCommit(true);
    }
}
```

**Why important:**
- Jika update peminjaman success tapi decrease stok fail → partial update (inconsistent)
- Transaction memastikan kedua operation atomic (all or nothing)

---

### Snippet 4: Error Handling dengan Custom Exception
```java
// File: BarangView.java
private void onTambahBarangClick() {
    try {
        String nama = tfNama.getText();
        int harga = Integer.parseInt(tfHarga.getText());
        int stok = Integer.parseInt(tfStok.getText());
        
        // Service method dengan validasi
        barangService.tambahBarangWithValidation(nama, harga, stok);
        
        // Jika sukses, refresh UI
        refreshTable();
        JOptionPane.showMessageDialog(this,
            "Barang berhasil ditambahkan",
            "Success", JOptionPane.INFORMATION_MESSAGE);
            
    } catch (ValidationException e) {
        // User input error - tampil spesifik message
        JOptionPane.showMessageDialog(this,
            "Validasi gagal: " + e.getMessage(),
            "Input Error", JOptionPane.ERROR_MESSAGE);
            
    } catch (BusinessException e) {
        // Business rule violation
        JOptionPane.showMessageDialog(this,
            "Error: " + e.getMessage(),
            "Business Error", JOptionPane.ERROR_MESSAGE);
            
    } catch (SQLException e) {
        // Database error - log & tampil generic message
        LogService.catat("ERROR_TAMBAH_BARANG", e.getMessage());
        JOptionPane.showMessageDialog(this,
            "Gagal akses database. Hubungi admin.",
            "Database Error", JOptionPane.ERROR_MESSAGE);
            
    } catch (NumberFormatException e) {
        // Invalid number format
        JOptionPane.showMessageDialog(this,
            "Harga dan stok harus berupa angka",
            "Format Error", JOptionPane.ERROR_MESSAGE);
    }
}
```

**Benefits:**
- Custom exception untuk meaningful error message
- Different handling untuk validation error vs database error
- Consistent error presentation kepada user

---

## 3. TABLE SCHEMA VISUALIZATION

### Users Table (login DB)
```
┌─────┬──────────────┬────────┬──────────────┬──────┐
│ id  │ username     │ password  │ email      │ role │
├─────┼──────────────┼────────┼──────────────┼──────┤
│ 1   │ admin        │ [hash] │ admin@...    │ admin│
│ 2   │ farras       │ [hash] │ farras@...   │ user │
│ 3   │ budi         │ [hash] │ budi@...     │ user │
└─────┴──────────────┴────────┴──────────────┴──────┘
```

### Barang Table (inventory DB)
```
┌─────┬──────────┬──────────────┬─────────┬─────┐
│ id  │ kode     │ nama_barang  │ harga   │ stok│
├─────┼──────────┼──────────────┼─────────┼─────┤
│ 1   │ LAP001   │ Laptop Dell  │ 5000000 │ 4   │ (stok berkurang setelah approve)
│ 2   │ MON001   │ Monitor 24"  │ 1500000 │ 10  │
└─────┴──────────┴──────────────┴─────────┴─────┘
```

### Peminjaman Table (inventory DB)
```
┌─────┬──────────┬──────────┬────────┬───────────┬───────────┬────────────┐
│ id  │ username │ kode_bgr │ jumlah │ tgl_pinjam│ tgl_kembali│ status    │
├─────┼──────────┼──────────┼────────┼───────────┼───────────┼────────────┤
│ 1   │ farras   │ LAP001   │ 1      │ 2024-01-15│ 2024-01-22│ disetujui │
│ 2   │ budi     │ MON001   │ 2      │ 2024-01-16│ 2024-01-23│ pending   │
└─────┴──────────┴──────────┴────────┴───────────┴───────────┴────────────┘
```

---

## 4. CLASS DIAGRAM SUMMARY

```
┌──────────────────────────────────┐
│         Model Layer              │
├──────────────────────────────────┤
│ User                             │
│  - id, username, password, role  │
│                                  │
│ Barang                           │
│  - id, kode, nama, harga, stok   │
│                                  │
│ Peminjaman                       │
│  - id, username, kodeBarang,     │
│    jumlah, tanggalPinjam, status │
└──────────────────────────────────┘

┌──────────────────────────────────┐
│      Controller Layer (DAO)      │
├──────────────────────────────────┤
│ AuthController                   │
│  + login(username, password)     │
│  + register(user)                │
│                                  │
│ BarangController                 │
│  + getAllBarang()                │
│  + insert(barang)                │
│  + decreaseStock(kode, qty)      │
│                                  │
│ PeminjamanController             │
│  + ajukanPeminjaman(peminjaman)  │
│  + getPending()                  │
│  + setujui(id)                   │
│  + tolak(id)                     │
└──────────────────────────────────┘

┌──────────────────────────────────┐
│      Service Layer               │
├──────────────────────────────────┤
│ ReturnItemService                │
│  + processReturn()               │
│  + validate()                    │
│                                  │
│ DashboardService                 │
│  + buildFullDashboard()          │
│  + calculateStatistics()         │
│  + findAlerts()                  │
└──────────────────────────────────┘

┌──────────────────────────────────┐
│       View Layer (UI)            │
├──────────────────────────────────┤
│ LoginView (JFrame)               │
│  - tfUsername, tfPassword        │
│  - btnLogin, btnRegister         │
│                                  │
│ BarangView (JPanel)              │
│  - tableBarang (JTable)          │
│  - btnTambah, btnEdit, btnHapus  │
│                                  │
│ PeminjamanView (JPanel)          │
│  - tablePeminjaman (JTable)      │
│  - btnAjukan, btnSetujui, btnTolak
│                                  │
│ ModernDashboardView (JPanel)     │
│  - Cards dengan statistik        │
│  - Alerts section                │
└──────────────────────────────────┘
```

---

## 5. KEY METRICS & STATISTICS

### Database Schema
- 2 Databases: login (auth), sisteminventaris (inventory)
- 5 Main Tables: users, barang, peminjaman, return_items, log_aktivitas
- ~20+ columns total
- Indexes pada: username, kode_barang, status

### Codebase
- ~6000+ lines of code
- 3 Model classes + DTOs
- 6 Controller classes
- 3 Service classes
- 8 View classes
- 10+ Utility/Component classes

### Features
- 5 Main modules (Auth, Inventory, Loans, Returns, Dashboard)
- 20+ CRUD operations
- 15+ Business validations
- 10+ Report/Dashboard views

---

## 6. DEPLOYMENT CHECKLIST

Before Go Live:
- [ ] Database backup created
- [ ] All SQL scripts tested
- [ ] Connection credentials verified
- [ ] Error logging configured
- [ ] User roles & permissions setup
- [ ] Sample data loaded
- [ ] Performance tested
- [ ] Security audit completed

---

## 7. TROUBLESHOOTING QUICK REFERENCE

**Problem:** Connection refused
- Solution: Pastikan MySQL running, database exist, credentials benar di DatabaseUtil

**Problem:** Table not found
- Solution: Run database schema script dari DATABASE_MIGRATIONS.sql

**Problem:** ClassNotFoundException for MySQL driver
- Solution: Pastikan mysql-connector-j-*.jar di folder lib/

**Problem:** "Stok tidak cukup" error saat pinjam
- Solution: Feature working as designed, user memang stok habis

**Problem:** UI lag/freeze saat load data
- Solution: Data loading sudah async dengan SwingWorker, ada index di database

---

## 8. BEST PRACTICES HIGHLIGHT

1. **Layered Architecture**
   - Clear separation of concerns
   - Each layer punya single responsibility

2. **Input Validation**
   - Validate di client (quick feedback)
   - Validate di server (main security)

3. **Error Handling**
   - Custom exceptions untuk meaningful message
   - Consistent error presentation

4. **SQL Security**
   - PreparedStatement prevent injection
   - Parameter binding treated sebagai data

5. **Data Consistency**
   - Transaction untuk atomic operations
   - Rollback jika ada error

6. **Code Reusability**
   - BaseService untuk common methods
   - Utility classes untuk common operations
   - DTOs untuk data transfer

7. **Logging & Audit**
   - Every important action di-log
   - Track who did what when

---

## 9. COMPARISON TABLE (Sistem kami vs kompetitor)

| Feature | Sistem Kami | Spreadsheet | Manual Process |
|---------|-----------|------------|-----------------|
| Real-time data | Ya | Tidak (manual input) | Tidak |
| Automatic stok decrease | Ya | Tidak | Tidak |
| Audit trail | Ya (log tabel) | Tidak | Tidak |
| Role-based access | Ya | Tidak | Tidak |
| Data validation | Ya | Partial | Tidak |
| Reporting | Ya (dashboard) | Possible | Tidak |
| User management | Ya | Tidak | Tidak |

---

## 10. ESTIMATED TIME BREAKDOWN

- Setup & Architecture: 20%
- Backend (Controllers, Services): 40%
- Frontend (Views, Components): 25%
- Testing & Debugging: 15%

**Total Development Time:** ~2-3 bulan dengan team 2-3 orang
