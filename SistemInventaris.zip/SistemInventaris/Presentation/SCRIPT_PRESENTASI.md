# SCRIPT PRESENTASI - VERSI SINGKAT (5-10 Menit)

## PERSIAPAN SEBELUM PRESENTASI

### Checklist Teknis
- [ ] MySQL running dan database ter-setup
- [ ] Java sudah ter-install (Java 8+)
- [ ] Aplikasi sudah ter-compile
- [ ] Test login dengan user sample
- [ ] Tes semua fitur (tambah barang, ajukan pinjam, approve, dashboard)
- [ ] Siapkan data sample untuk demo (2-3 barang, 1-2 peminjaman)
- [ ] Koneksi internet stabil (jika butuh screen recording)

### Persiapan Presentasi
- [ ] Siapkan laptop dengan screen projection
- [ ] Ukuran font di IDE minimal 18pt (mudah dilihat)
- [ ] Highlight kode yang penting
- [ ] Siapkan slide ringkas (bukan kode panjang)
- [ ] Tes mic & speaker sebelumnya

---

## SCRIPT PRESENTASI SINGKAT (Timing)

### 1. INTRODUCTION (1 menit)

"Assalamualaikum. Nama saya [Nama]. Saya presentasikan Sistem Inventaris - aplikasi untuk manajemen peminjaman barang di departemen.

Sistem ini pakai arsitektur MVC dengan Java Swing UI dan MySQL database. Fitur utamanya adalah login, kelola stok barang, proses peminjaman & pengembalian, dan dashboard dengan statistik real-time."

### 2. PROBLEM STATEMENT (30 detik)

"Masalah yang kami selesaikan:
- Peminjaman barang masih manual, rawan human error
- Tidak ada tracking stok real-time
- Sulit lihat history peminjaman
- Admin harus cek satu per satu"

### 3. SOLUSI & FITUR (2 menit)

**Fitur 1: Login & Authentication**
- User login dengan username-password
- Role-based access (admin vs user biasa)
- Session tracking

**Fitur 2: Inventory Management**
- CRUD barang (tambah, lihat, edit, hapus)
- Tracking stok real-time
- Alert stok rendah

**Fitur 3: Loan Management**
- User ajukan peminjaman
- Admin approve/reject
- Auto decrease stok saat approve
- Tracking tanggal kembali

**Fitur 4: Return Management**
- User return barang
- Auto increase stok
- Tracking late returns

**Fitur 5: Dashboard**
- Statistik total barang, peminjaman, returns
- Alert barang stok rendah & overdue items
- Activity log

### 4. ARSITEKTUR SISTEM (1 menit) - SHOW DIAGRAM

```
┌─────────────────┐
│  View (UI)      │  ← Swing Components
├─────────────────┤
│  Service        │  ← Business Logic & Validation
├─────────────────┤
│  Controller     │  ← Database Operations
├─────────────────┤
│  Database       │  ← MySQL Tables
└─────────────────┘
```

"Kami pisah menjadi 4 layer:
- View: User interface Swing
- Service: Business logic & validation
- Controller: Database operations (CRUD)
- Database: Data storage MySQL

Keuntungan: Clean code, mudah di-maintain, mudah di-test."

### 5. LIVE DEMO (3-5 menit)

**Demo Script:**

**Step 1: Login**
```
Buka aplikasi → LoginView tampil
Username: admin
Password: admin123
Login → Masuk Dashboard
```

**Step 2: Browse & Tambah Barang**
```
View → Barang
Klik "Tambah Barang"
Isikan:
  - Kode: LAP001
  - Nama: Laptop Dell
  - Harga: 5000000
  - Stok: 5
Klik Simpan → Data muncul di table
```

**Step 3: Ajukan Peminjaman**
```
Switch user: logout, login dengan user biasa
Username: farras
Password: password
View → Peminjaman
Klik "Ajukan Pinjam"
Pilih barang: Laptop Dell
Jumlah: 1
Tanggal kembali: [pilih 7 hari dari sekarang]
Klik Ajukan → Status menjadi "pending"
```

**Step 4: Admin Approve Peminjaman**
```
Logout, login sebagai admin lagi
View → Peminjaman
Klik "Setujui" pada peminjaman yang pending
Status berubah → "disetujui"
Stok Laptop Dell berkurang dari 5 menjadi 4 (otomatis)
```

**Step 5: View Dashboard**
```
View → Dashboard
Tampil statistik:
  - Total barang: 1
  - Total peminjaman: 1
  - Barang tersedia: 1
  - Stok rendah: (none)
  - Overdue items: (none)
```

### 6. TECHNICAL HIGHLIGHTS (1 menit) - SHOW KODE PENTING

**Highlight 1: SQL Injection Prevention**
```java
// SAFE - PreparedStatement
String sql = "SELECT * FROM users WHERE username = ?";
PreparedStatement ps = conn.prepareStatement(sql);
ps.setString(1, username);
```

**Highlight 2: Business Logic Validation**
```java
public void ajukanPeminjaman(String kodeBarang, int jumlah) {
    // 1. Validasi input
    if (jumlah <= 0) throw new ValidationException("Jumlah harus > 0");
    
    // 2. Cek stok
    Barang barang = barangCtrl.getBarangByKode(kodeBarang);
    if (barang.getStok() < jumlah) 
        throw new ValidationException("Stok tidak cukup");
    
    // 3. Insert peminjaman
    peminjamanCtrl.insert(new Peminjaman(...));
    
    // 4. Log aktivitas
    logOperation("AJUKAN_PINJAM", ...);
}
```

**Highlight 3: MVC Separation**
- Model: Plain POJO (Barang.java, Peminjaman.java)
- Controller: DAO layer (BarangController, PeminjamanController)
- Service: Business logic (ReturnItemService, DashboardService)
- View: UI Swing (BarangView, PeminjamanView)

### 7. CHALLENGES & SOLUTIONS (1 menit)

**Challenge 1: Stok consistency saat concurrent access**
- Solution: Use transaction & locking

**Challenge 2: Performance dengan dataset besar**
- Solution: Pagination, indexing, async loading

**Challenge 3: Data validation**
- Solution: Validate di client dan server

**Challenge 4: Error handling**
- Solution: Custom exceptions, meaningful error messages

### 8. FUTURE IMPROVEMENT (30 detik)

- Mobile app (Android/iOS)
- Web interface (Spring Boot + React)
- Advanced reporting & analytics
- Real-time sync multi-user
- Cloud deployment

### 9. KESIMPULAN (30 detik)

"Sistem Inventaris sudah functional dan siap production untuk internal use. Pakai best practice dalam security, error handling, dan architecture.

Terima kasih. Siap menjawab pertanyaan."

---

## STRATEGY JAWAB PERTANYAAN

### Jika ditanya tentang "Apa kekurangan?":
**Jawab honest:**
"Kekurangan utama adalah scalability - cocok untuk internal use puluhan-ratusan user. Jika perlu ribuan user simultaneous, perlu upgrade ke web framework. Tapi untuk scope project ini, sudah cukup memenuhi requirement."

### Jika ditanya "Bagaimana dengan security?":
**Jawab confident:**
"Kami sudah implement best practices:
1. PreparedStatement untuk prevent SQL injection
2. Session management untuk authentication
3. Input validation di server-side
4. Custom exception handling
5. Activity logging untuk audit trail"

### Jika ditanya "Kenapa Swing dan bukan web?":
**Jawab langsung:**
"Swing dipilih karena:
1. Simple deployment - langsung run, tidak perlu web server
2. Native UI, performance bagus
3. Sesuai requirement (desktop application)
4. Faster development untuk prototype
Jika perlu scale, bisa refactor ke Spring Boot + React."

### Jika ditanya "Berapa waktu develop?":
**Jawab real:**
"Dikerjakan dalam [X] phase:
- Phase 1: DB & basic CRUD (1 minggu)
- Phase 2: UI refactoring (1 minggu)
- Phase 3: Service layer & business logic (1 minggu)
- Phase 4: Dashboard & testing (1 minggu)
Total: [X] minggu dengan team [X] orang."

### Jika ditanya "Ada test case?":
**Jawab dengan example:**
"Ya, sudah test:
- Happy path: login → buat peminjaman → approve → cek dashboard
- Error cases: login invalid, stok habis, jumlah invalid
- Edge cases: duplicate username, past dates
Manual testing yang comprehensive."

---

## RED FLAGS TO AVOID

- Jangan over-claim fitur yang tidak ada
- Jangan masuk detail teknis terlalu dalam (unless ditanya)
- Jangan debating tentang technology choice (Swing vs web, MySQL vs NoSQL)
- Jangan bilang "belum implement" untuk fitur penting
- Jangan nervous saat demo - sudah siap, pasti lancar

---

## QUICK REFERENCE - Struktur Folder

Kalau dosen minta lihat structure:
```
src/
├── Main.java                    # Entry point
├── controller/                  # DAO layer (CRUD)
├── service/                     # Business logic
├── view/                        # UI Swing
├── model/                       # Domain objects
├── util/                        # Helpers & validation
└── component/                   # Custom UI components
```

---

## SLIDE CONTENT SUGGESTION

### Slide 1: Title
- Sistem Inventaris
- Inventory Management System
- [Nama], [Institusi], [Tanggal]

### Slide 2: Problem & Solution
- Problem: Manual process, no tracking
- Solution: Automated system dengan real-time tracking

### Slide 3: Features
- Login & Authentication
- Inventory Management
- Loan & Return Management
- Dashboard & Reporting

### Slide 4: Architecture
- MVC Diagram
- Layer explanation

### Slide 5: Technology Stack
- Java Swing (Frontend)
- MySQL (Database)
- JDBC (Driver)

### Slide 6: Demo Flow
- Screenshot atau diagram flow

### Slide 7: Q&A
- Thank you
