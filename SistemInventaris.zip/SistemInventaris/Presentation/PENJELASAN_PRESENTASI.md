# Penjelasan Sistem Inventaris - Untuk Presentasi

## 1. RINGKASAN SINGKAT (1-2 menit)

Sistem Inventaris adalah aplikasi desktop Java untuk manajemen peminjaman barang dengan fitur:
- Login & registrasi user
- Kelola stok barang
- Proses peminjaman & pengembalian barang
- Dashboard dengan statistik real-time
- Logging aktivitas user
- Export data ke CSV

Teknologi: Java Swing + MySQL, MVC Architecture.

---

## 2. ARSITEKTUR SISTEM (Jelaskan dengan diagram)

```
┌─────────────────────┐
│   VIEW LAYER (UI)   │ ← LoginView, BarangView, DashboardView
├─────────────────────┤
│  SERVICE LAYER      │ ← Business logic, validation, calculations
├─────────────────────┤
│ CONTROLLER LAYER    │ ← Database operations (CRUD)
├─────────────────────┤
│   DATABASE (MySQL)  │ ← Data storage
└─────────────────────┘
```

**Keuntungan**: Separation of concerns, mudah di-maintain, mudah di-test.

---

## 3. FLOW UTAMA APLIKASI

### A. Flow Login
```
User buka aplikasi
        ↓
LoginView tampil
        ↓
Input username & password
        ↓
AuthController.login() cek di DB
        ↓
Jika valid → SessionManager simpan data user → Buka DashboardView
Jika invalid → Tampil error message
```

### B. Flow Peminjaman Barang
```
User klik "Ajukan Pinjam" di BarangView
        ↓
Muncul dialog pilih barang & jumlah
        ↓
PeminjamanService validasi:
  - Username tidak kosong?
  - Barang ada di database?
  - Stok cukup?
  - Tanggal kembali valid?
        ↓
Jika valid → Insert ke tabel peminjaman dengan status "pending"
Jika invalid → Tampil pesan error spesifik
        ↓
Admin buka PeminjamanView → Lihat list pending
        ↓
Admin klik "Setujui" → PeminjamanController.setujui()
        ↓
Status berubah jadi "disetujui", stok barang berkurang otomatis
        ↓
LogBarangController catat aktivitas ke log_aktivitas
```

### C. Flow Dashboard
```
User buka Dashboard
        ↓
DashboardService.buildFullDashboard() jalankan 4 query paralel:
  1. Hitung total barang, stok tersedia, barang habis
  2. Hitung peminjaman pending, disetujui, ditolak
  3. Cari barang stok rendah (< 5)
  4. Cari peminjaman yang sudah lewat deadline
        ↓
Gabung hasil → Return DashboardDTO
        ↓
ModernDashboardView.refreshUI() tampilkan statistik & alert
```

---

## 4. PENJELASAN KODE SINGKAT PER MODULE

### Controller Layer
```java
// Contoh: BarangController.java
// Tugasnya: Direct DB operations, CRUD untuk barang
public List<Barang> getAllBarang() throws SQLException {
    String sql = "SELECT * FROM barang";
    // Execute query, map hasil ke List<Barang>, return
}
```

### Service Layer
```java
// Contoh: ReturnItemService.java
// Tugasnya: Business logic, validasi, calculation
public void processReturn(int peminjamanId, int jumlahDikembalikan) 
        throws ValidationException, SQLException {
    // 1. Validasi input
    ValidationUtil.requirePositive(peminjamanId, "Peminjaman ID");
    
    // 2. Ambil data dari controller
    Peminjaman p = peminjamanCtrl.getById(peminjamanId);
    
    // 3. Validasi business rule
    if (jumlahDikembalikan > p.getJumlah()) {
        throw new ValidationException("Jumlah pengembalian melebihi jumlah pinjam");
    }
    
    // 4. Lakukan update
    peminjamanCtrl.ubahStatus(peminjamanId, "dikembalikan");
    barangCtrl.tambahStok(p.getKodeBarang(), jumlahDikembalikan);
    
    // 5. Log aktivitas
    logOperation("KEMBALIKAN_BARANG", "User " + username + " kembalikan barang");
}
```

### View Layer
```java
// Contoh: BarangView.java
// Tugasnya: Tampilkan UI, capture input user, panggil service
private void setupTable() {
    // 1. Buat JTable dengan custom renderer
    table = new JTable(new DefaultTableModel(...));
    
    // 2. Load data dari service
    List<Barang> listBarang = barangService.getAllBarangSafe();
    
    // 3. Populate table
    for (Barang b : listBarang) {
        model.addRow(new Object[]{
            b.getKodeBarang(), b.getNamaBarang(), b.getStok(), ...
        });
    }
}

private void setupActions() {
    // User klik tombol "Tambah Barang"
    btnTambah.addActionListener(e -> {
        String nama = tfNama.getText();
        int harga = Integer.parseInt(tfHarga.getText());
        
        // Validasi & panggil service
        barangService.tambahBarang(nama, harga);
        refreshTable();
    });
}
```

---

## 5. FITUR UTAMA & CARA KERJANYA

| Fitur | Cara Kerja | Validasi |
|-------|-----------|----------|
| **Login** | Input username & password → Cek database → Simpan session | Username & password harus valid |
| **Tambah Barang** | Input kode, nama, harga, stok → Insert DB | Kode barang unik, stok > 0 |
| **Ajukan Pinjam** | Pilih barang & jumlah → Validasi stok → Insert peminjaman (status: pending) | Stok harus cukup, jumlah > 0 |
| **Setujui Pinjam** | Admin approve → Update status → Kurangi stok otomatis | Hanya admin bisa approve |
| **Kembalikan Barang** | User return → Validasi jumlah → Tambah stok → Update status | Jumlah return ≤ jumlah pinjam |
| **Dashboard** | Tampilkan statistik: total barang, peminjaman, stok rendah, overdue | Real-time dari DB |

---

## 6. DESIGN PATTERN YANG DIGUNAKAN

1. **MVC (Model-View-Controller)**
   - Pisahkan UI, business logic, dan data access
   - Mudah di-maintain dan di-test

2. **DAO (Data Access Object)**
   - Setiap entity punya controller sendiri
   - Centralize semua DB operations
   - Contoh: BarangController, PeminjamanController

3. **Service Layer**
   - Pusat business logic & validasi
   - Lebih tinggi level dari controller
   - Contoh: ReturnItemService, DashboardService

4. **Singleton**
   - SessionManager → Hanya 1 instance user session di memory
   - DatabaseUtil → Reuse connection pool

5. **Observer Pattern** (Implicit)
   - JTable listener mendengarkan perubahan data
   - Auto refresh UI saat data berubah

---

## 7. IMPLEMENTASI KEAMANAN

1. **SQL Injection Prevention**
   - Gunakan PreparedStatement, bukan string concatenation
   ```java
   PreparedStatement ps = conn.prepareStatement("SELECT * FROM users WHERE username = ?");
   ps.setString(1, username); // Parameter binding, aman dari injection
   ```

2. **Session Management**
   - SessionManager track user login
   - Logout clear session
   - Jika buka window tanpa login → Redirect ke LoginView

3. **Role-Based Access**
   - Admin bisa approve peminjaman & lihat semua user
   - User normal hanya bisa lihat data pribadi
   - Check role di setiap action yang sensitive

4. **Input Validation**
   - ValidationUtil check input sebelum proses
   - Tangkap exception & tampil error message jelas

---

## 8. DATABASE SCHEMA SINGKAT

```sql
-- Database: login (untuk authentication)
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) UNIQUE,
    password VARCHAR(255),
    email VARCHAR(100),
    role ENUM('admin', 'user')
);

-- Database: sisteminventaris (untuk inventory)
CREATE TABLE barang (
    id INT AUTO_INCREMENT PRIMARY KEY,
    kode_barang VARCHAR(50) UNIQUE,
    nama_barang VARCHAR(150),
    harga INT,
    stok INT
);

CREATE TABLE peminjaman (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100),
    kode_barang VARCHAR(50),
    jumlah INT,
    tanggal_pinjam DATE,
    tanggal_kembali DATE,
    status ENUM('pending', 'disetujui', 'ditolak')
);
```

---

## 9. ERROR HANDLING

```java
// Setiap method punya try-catch & meaningful error message

public void processReturn() {
    try {
        // Validasi
        if (jumlah <= 0) {
            throw new ValidationException("Jumlah harus > 0");
        }
        
        // Proses
        returnItemCtrl.proses(...);
        
    } catch (ValidationException e) {
        // Tampil error ke user dengan pesan jelas
        JOptionPane.showMessageDialog(null, 
            "Error validasi: " + e.getMessage(),
            "Validasi Gagal", JOptionPane.ERROR_MESSAGE);
            
    } catch (SQLException e) {
        // Log error & tampil generic message
        LogService.catat("ERROR_PROCESS_RETURN", e.getMessage());
        JOptionPane.showMessageDialog(null,
            "Gagal proses pengembalian. Hubungi admin.",
            "Database Error", JOptionPane.ERROR_MESSAGE);
    }
}
```

---

## 10. PERFORMANCE OPTIMIZATION

1. **Connection Pooling**
   - Reuse DB connections, jangan create baru tiap kali
   - DatabaseUtil manage connection pool

2. **Async Loading** (SwingWorker)
   - Dashboard load data di background thread
   - UI tidak freeze saat query berat

3. **Indexed Queries**
   - INDEX pada username, kode_barang untuk query cepat
   - Primary key otomatis di-INDEX

4. **Lazy Loading**
   - Jangan load semua barang sekaligus
   - Load per page / on-demand

---

## 11. TEST CASE YANG BISA DIJELASKAN

1. **Test Happy Path**
   - Login valid → Berhasil login
   - Ajukan pinjam valid → Masuk ke pending
   - Admin approve → Status jadi "disetujui", stok berkurang

2. **Test Error Cases**
   - Login invalid → Error message
   - Pinjam stok habis → Error "Stok tidak cukup"
   - Kembalikan > jumlah pinjam → Error "Jumlah kembali melebihi jumlah pinjam"

3. **Test Edge Cases**
   - Pinjam barang yang tidak ada → Not found
   - Username duplicate saat register → Error "Username sudah terdaftar"
   - Logout dan login dengan user beda → Session berubah

---

# FAQ - ANTISIPASI PERTANYAAN DOSEN

## Q1: Kenapa pakai MVC? Apa keuntungannya?

**Jawab singkat:**
MVC memisahkan UI (View), bisnis logic (Controller), dan data (Model). Keuntungan:
- Mudah maintenance: Setiap bagian punya tanggung jawab jelas
- Mudah testing: Bisa test logic tanpa UI
- Mudah scale: Tambah fitur tanpa ubah struktur existing
- Reusable: Controller bisa dipakai di berbagai View

**Contoh di project:**
- Model: Barang.java (hanya data)
- Controller: BarangController.java (CRUD DB)
- Service: ReturnItemService.java (business logic)
- View: BarangView.java (UI Swing)

---

## Q2: Bagaimana cara prevent SQL injection?

**Jawab singkat:**
Gunakan PreparedStatement dengan parameter binding, bukan string concatenation.

**Bad (Vulnerable):**
```java
String sql = "SELECT * FROM users WHERE username = '" + username + "'";
// Jika username = "admin' OR '1'='1", query jadi:
// SELECT * FROM users WHERE username = 'admin' OR '1'='1'
// Return semua user!
```

**Good (Safe):**
```java
String sql = "SELECT * FROM users WHERE username = ?";
PreparedStatement ps = conn.prepareStatement(sql);
ps.setString(1, username); // Parameter binding, aman
// Database treat username sebagai value, bukan code
```

---

## Q3: Bagaimana transaction & consistency di database?

**Jawab singkat:**
Saat user approve peminjaman, kami update 2 tabel atomik:
1. Update status peminjaman → "disetujui"
2. Kurangi stok barang

Pakai transaction agar kedua operation gagal atau sukses bersama, tidak partial update.

```java
public void setujuiPeminjaman(int peminjamanId) throws SQLException {
    conn.setAutoCommit(false);
    try {
        // Update 1: status peminjaman
        stmt.execute("UPDATE peminjaman SET status='disetujui' WHERE id=" + peminjamanId);
        
        // Update 2: kurangi stok
        stmt.execute("UPDATE barang SET stok=stok-1 WHERE kode_barang=...");
        
        // Jika 1 gagal, 2 juga rollback
        conn.commit();
    } catch (SQLException e) {
        conn.rollback();
        throw e;
    }
}
```

---

## Q4: Bagaimana validasi input? Di mana dilakukan?

**Jawab singkat:**
Validasi dilakukan di 2 tempat:
1. **Client-side (UI)**: Quick feedback, cegah submit form invalid
2. **Server-side (Service)**: Main validasi, prevent bypass

**Contoh:**
```java
// View layer (Client-side)
if (tfJumlah.getText().isEmpty()) {
    JOptionPane.showMessageDialog(null, "Jumlah tidak boleh kosong");
    return;
}

// Service layer (Server-side) - Main validasi
public void ajukanPeminjaman(String kodeBarang, int jumlah) 
        throws ValidationException {
    ValidationUtil.requirePositive(jumlah, "Jumlah");
    
    Barang barang = barangCtrl.getBarangByKode(kodeBarang);
    if (barang == null) {
        throw new ValidationException("Barang tidak ditemukan");
    }
    
    if (barang.getStok() < jumlah) {
        throw new ValidationException("Stok tidak cukup. Tersedia: " + barang.getStok());
    }
    
    // Proses jika validasi passed
    ...
}
```

---

## Q5: Bagaimana menangani error & exception?

**Jawab singkat:**
Kami buat custom exception (`ValidationException`, `BusinessException`) dan tangkap dengan meaningful message.

```java
// Custom exception
public class ValidationException extends Exception {
    public ValidationException(String message) {
        super(message);
    }
}

// Penggunaan
try {
    service.ajukanPeminjaman(...);
} catch (ValidationException e) {
    // Tampil pesan validasi ke user
    JOptionPane.showMessageDialog(null, 
        "Validasi gagal: " + e.getMessage(),
        "Input Error", 
        JOptionPane.ERROR_MESSAGE);
} catch (SQLException e) {
    // Log error, tampil generic message
    LogService.catat("DATABASE_ERROR", e.getMessage());
    JOptionPane.showMessageDialog(null,
        "Gagal akses database. Hubungi admin.",
        "Database Error",
        JOptionPane.ERROR_MESSAGE);
}
```

---

## Q6: Bagaimana scalability? Bisa untuk ribuan barang?

**Jawab singkat:**
Ya, dengan beberapa optimization:
- **Pagination**: Jangan load 10000 barang sekaligus, load per 20 items
- **Indexing**: CREATE INDEX pada kolom yang sering di-query (username, kode_barang)
- **Connection Pool**: Reuse connection, jangan create baru tiap kali
- **Async Loading**: SwingWorker untuk UI tidak freeze

Kalau traffic sangat tinggi (ribuan user simultan), mungkin perlu upgrade dari Swing ke web framework (Spring Boot).

---

## Q7: Bagaimana testing dilakukan?

**Jawab singkat:**
Manual testing dengan test cases:

**Happy Path:**
1. Buka aplikasi → LoginView tampil
2. Input username & password valid → Login berhasil
3. Buka BarangView → Lihat list barang
4. Ajukan pinjam barang dengan stok cukup → Masuk ke peminjaman pending
5. Login sebagai admin → Approve peminjaman → Status jadi "disetujui"
6. Cek dashboard → Statistik ter-update

**Error Cases:**
1. Login invalid → Error message
2. Pinjam barang stok habis → Error "Stok tidak cukup"
3. Kembalikan jumlah > pinjam → Error

**Edge Cases:**
1. Register username duplicate → Error "Username sudah ada"
2. Pinjam tanggal kembali di masa lalu → Error "Tanggal invalid"

---

## Q8: Mengapa pakai Swing dan bukan web?

**Jawab singkat:**
Swing dipilih karena:
- Project sederhana, user base kecil (untuk enterprise internal)
- Instant deployment tanpa web server
- Native UI, performance bagus
- Mudah untuk prototype & demo
- Sesuai requirement assignment (desktop app)

Kalau ingin scale ke ribuan user, bisa upgrade ke Spring Boot + React.

---

## Q9: Bagaimana komunikasi antar layer?

**Jawab singkat:**
View → Service → Controller → Database

```
View.btnTambah.onClick()
  ↓
Service.tambahBarang(nama, harga)  // Validasi logic
  ↓
Controller.insert(barang)  // SQL query
  ↓
Database.execute()
  ↓
Response balik ke View
  ↓
View.refreshTable()
```

Setiap layer punya clear responsibility, tidak boleh langsung DB dari View.

---

## Q10: Bagaimana session management & logout?

**Jawab singkat:**
SessionManager adalah singleton yang track user login:

```java
// Login
SessionManager.setSession(username, role);
// User session tersimpan di memory

// Logout
SessionManager.clearSession();
// Session clear, redirect ke LoginView

// Check session
if (SessionManager.getUsername() == null) {
    // Belum login, redirect ke LoginView
}
```

Setiap kali user buka window baru atau restart aplikasi, harus login lagi.

---

## Q11: Bagaimana cara export data?

**Jawab singkat:**
ExportUtil convert JTable data ke CSV file:

```java
// User klik "Export ke CSV"
String filePath = JFileChooser.showSaveDialog(...); // User pilih lokasi
ExportUtil.exportTableToCSV(table, filePath);
// Save sebagai .csv → Bisa dibuka di Excel
```

File CSV bisa dibuka di Excel untuk analisis lebih lanjut.

---

## Q12: Apa kekurangan sistem ini?

**Jawab jujur:**
1. **Scalability**: Hanya cocok untuk internal use (puluhan-ratusan user)
   - Untuk ribuan user simultaneous, perlu upgrade ke web + microservices

2. **Offline only**: Jika network down, hanya bisa akses local
   - Solusi: Implement cloud sync dengan server central

3. **No real-time sync**: Multiple user di device berbeda tidak sync real-time
   - Solusi: Implement observer pattern dengan server push

4. **Authentication simple**: Hanya username-password
   - Solusi: Tambah 2FA, OAuth, LDAP integration

5. **Audit trail basic**: Hanya log aktivitas, bukan change history
   - Solusi: Track field changes (who changed what, when)

---

## Q13: Bagaimana continuous improvement?

**Jawab singkat:**
Roadmap future enhancement:
- Phase 4: Mobile app (Android) dengan sync ke server
- Phase 5: Web interface (Spring Boot + React)
- Phase 6: Analytics & reporting dashboard
- Phase 7: API untuk integrasi sistem lain

---

## TIPS PRESENTASI

1. **Jangan masuk terlalu dalam detail kode** → Fokus pada flow & architecture
2. **Persiapkan live demo** → Run aplikasi, login, buat transaksi, show dashboard
3. **Siapkan slide sederhana** → Diagram, screenshots, bukan wall of text
4. **Anticipate pertanyaan** → Siap jawab dari FAQ di atas
5. **Jangan claim feature yang belum** → Jujur tentang scope & limitations
6. **Highlight best practice** → MVC, validation, error handling, SQL injection prevention
7. **Siapkan database connection** → Pastikan MySQL running sebelum demo
