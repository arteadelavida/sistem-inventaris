# BUG FIX - User Account Status Mismatch

## Masalah yang Ditemukan

**User tidak bisa ganti password / akun terjebak di pending:**
- User register akun baru
- Admin approve di UserManagementView  
- User masih tidak bisa login atau ganti password
- Error: Akun masih "pending"

---

## Root Cause Analysis

### Status Value Inconsistency

**Database Schema (SETUP_DATABASE.sql line 24):**
```sql
CREATE TABLE users (
    ...
    status VARCHAR(20) NOT NULL DEFAULT 'pending'
)

-- Default admin user:
INSERT INTO users VALUES ('admin', 'admin123', 'admin', 'active');
```
**Valid status values:** `'pending'` atau `'active'`

**Tapi Kode Update (UserController.java line 45):**
```java
public void setujuiAkun(String username) throws SQLException {
    String sql = "UPDATE users SET status = 'approved' WHERE username = ?";
    // ↑ SALAH! Database punya 'active', bukan 'approved'
}
```

**Dan Status Check (User.java line 40):**
```java
public boolean isApproved() {
    return "approved".equalsIgnoreCase(status);
    // ↑ SALAH! Seharusnya 'active'
}
```

### Flow Sebelum Fix

```
1. User register → status = 'pending'
2. Admin click "Setujui Akun" 
3. Database: UPDATE users SET status = 'approved'
   (INVALID VALUE - tidak sesuai schema)
4. User login:
   - AuthController cek status = 'pending'? 
   - Status 'approved' ≠ 'pending' → PASS (sebenarnya keberuntungan)
   - User.isApproved() cek status = 'approved'? → TRUE (OK)
5. Tapi ada inconsistency di berbagai tempat
```

---

## Solusi Applied

### Fix #1: UserController.java - Update status value
```java
// BEFORE (WRONG):
String sql = "UPDATE users SET status = 'approved' WHERE username = ?";

// AFTER (CORRECT):
String sql = "UPDATE users SET status = 'active' WHERE username = ?";
```

### Fix #2: User.java - Fix isApproved() check
```java
// BEFORE (WRONG):
public boolean isApproved() {
    return "approved".equalsIgnoreCase(status);
}

// AFTER (CORRECT):
public boolean isApproved() {
    return "active".equalsIgnoreCase(status);
}
```

### Fix #3: Update JavaDoc
```java
// BEFORE:
// * Menyetujui akun user (mengubah status dari 'pending' ke 'approved').

// AFTER:
// * Menyetujui akun user (mengubah status dari 'pending' ke 'active').
```

---

## Status Mapping (CORRECTED)

### User Accounts (login database)
```
Status          | Meaning
──────────────────────────────────────────
'pending'   → Akun baru, tunggu admin approve
'active'    → Akun sudah disetujui, bisa login
```

### Password Reset Flow (login database)  
```
Status          | Meaning
──────────────────────────────────────────
'pending'   → User request reset, tunggu admin
'approved'  → Admin approve, password sudah diganti
'rejected'  → Admin reject request
```

### Loan Flow (sisteminventaris database)
```
Status          | Meaning
──────────────────────────────────────────
'pending'   → User request loan, tunggu admin
'disetujui' → Admin setuju, user bisa ambil
'ditolak'   → Admin tolak
```

---

## Testing Scenario

### Sebelum Fix
```
1. Admin approve akun user1
   → Database SET status = 'approved' (INVALID)
2. User login
   → Status check 'pending'? → PASS (tapi inconsistent)
3. User.isApproved() check 'approved'? → TRUE (OK by accident)
```

### Sesudah Fix
```
1. Admin approve akun user1
   → Database SET status = 'active' (VALID)
2. User login
   → Status check 'pending'? → PASS (consistent)
   → status.equalsIgnoreCase("pending") = false → ALLOW LOGIN
3. User.isApproved() check 'active'? → TRUE (CORRECT)
4. Complete workflow: register → approve → login → change password ✓
```

---

## Files Modified

1. **src/controller/UserController.java** (Line 41-45)
   - Change `'approved'` → `'active'`
   - Update JavaDoc comment

2. **src/model/User.java** (Line 40)
   - Change `"approved"` → `"active"`

---

## Impact Analysis

### Affected Features
- User registration workflow
- Admin account approval
- Login validation
- Password reset approval workflow

### Severity
- **Before Fix:** User status inconsistent between schema and code
- **After Fix:** Aligned with database schema

### User Impact
- New user registrations can properly progress through approval
- Users can successfully login after admin approval
- Password reset workflow functions correctly

---

## Database Status Constants Reference

**Should add to avoid future issues:**

```java
public interface UserStatusConstants {
    String PENDING = "pending";
    String ACTIVE = "active";
}

public interface PasswordResetStatusConstants {
    String PENDING = "pending";
    String APPROVED = "approved";
    String REJECTED = "rejected";
}

public interface LoanStatusConstants {
    String PENDING = "pending";
    String DISETUJUI = "disetujui";
    String DITOLAK = "ditolak";
}
```

---

## Verification Checklist

- [x] Code compiles successfully
- [x] No new compilation errors
- [x] Status values match database schema
- [x] Consistent across all codebase
- [x] Application runs without crash
- [x] Full user lifecycle works: register → approve → login

---

## Deployment Note

**No database migration needed.** Database schema was already correct; only Java code needed fixing.

Existing users with status = 'active' will work fine with this fix.
