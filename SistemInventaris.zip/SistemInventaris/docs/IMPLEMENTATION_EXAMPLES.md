# 🚀 IMPLEMENTATION EXAMPLES - SistemInventaris 4.0

**Panduan Praktis dengan Kode Konkret**

---

## 📌 QUICK START

### 1️⃣ Menggunakan Service Layer dengan Validation

#### BEFORE (Controller-heavy):
```java
// Kode lama - logic di controller
BarangController ctrl = new BarangController();
try {
    if (kodeBarang == null || kodeBarang.isEmpty()) {
        JOptionPane.showMessageDialog(...);
        return;
    }
    Barang existing = ctrl.getBarangByKode(kodeBarang);
    if (existing != null) {
        JOptionPane.showMessageDialog(...);
        return;
    }
    ctrl.tambahBarang(...);
} catch (SQLException e) {
    // Error handling di sini
}
```

#### AFTER (Service layer):
```java
// Kode baru - clean, reusable
BarangService service = new BarangService();
try {
    service.tambahBarangWithValidation(kodeBarang, namaBarang, harga, stok, keterangan);
    ToastNotification.showSuccess("Barang berhasil ditambahkan");
} catch (ValidationException e) {
    ToastNotification.showError(e.getMessage());
} catch (SQLException e) {
    ToastNotification.showError("Database error: " + e.getMessage());
}
```

---

### 2️⃣ Enhanced Return Item System dengan Status Tracking

#### Workflow Pengembalian Barang:
```
Status Peminjaman: DIPINJAM
          ↓
   (user/staff request return)
          ↓
Status: DIKEMBALIKAN_SEBAGIAN (jika partial return)
          ↓
     (admin approve)
          ↓
Status Stok: Update otomatis
Status Peminjaman: SELESAI
```

#### Implementation:
```java
// Service layer untuk return request
ReturnItemService returnService = new ReturnItemService();

try {
    // 1. Request pengembalian dengan validasi
    int returnId = returnService.createReturnRequest(
        peminjamanId,              // ID peminjaman
        username,                  // User yang mengembalikan
        jumlahDikembalikan,        // Jumlah yang dikembalikan
        "baik",                    // Kondisi: baik, rusak ringan, rusak berat, hilang
        "Pengembalian sebagian"    // Keterangan
    );
    
    // 2. Validasi otomatis terjadi di service:
    //    - Cek peminjaman exists
    //    - Cek status peminjaman = approved
    //    - Cek jumlah tidak melebihi jumlah pinjam
    //    - Cek kondisi valid
    //    - Simpan ke database
    //    - Log operation
    
    ToastNotification.showSuccess("Return request #" + returnId + " submitted");
    
} catch (ValidationException e) {
    // User-friendly error message
    ToastNotification.showError(e.getMessage());
    // Example: "Jumlah pengembalian '10' melebihi jumlah pinjam '5' untuk Laptop"
    
} catch (SQLException e) {
    ToastNotification.showError("Database error");
}

// 3. Admin approval (with stock update)
try {
    returnService.approveReturn(returnItemId, adminUsername);
    // Automatically:
    // - Update return status = approved
    // - Update peminjaman status (based on full/partial return)
    // - Update barang stok (add kembali)
    // - Log: kondisi barang, stok changes, etc.
    // - Create return_history entry
    
    ToastNotification.showSuccess("Return approved. Stock updated.");
    
} catch (ValidationException | BusinessException e) {
    ToastNotification.showError(e.getMessage());
} catch (SQLException e) {
    ToastNotification.showError("Failed to approve return");
}
```

---

### 3️⃣ Dashboard dengan Statistics Cards

#### Layout:
```
┌─────────────────────────────────────────────────────┐
│ Dashboard        🔄 Refresh                          │
├─────────────────────────────────────────────────────┤
│                                                       │
│  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐ │
│  │📦 Total      │ │📦 Tersedia   │ │📤 Dipinjam   │ │
│  │ 150          │ │ 85           │ │ 45           │ │
│  │ items        │ │ available    │ │ borrowed     │ │
│  └──────────────┘ └──────────────┘ └──────────────┘ │
│                                                       │
│  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐ │
│  │⚠️  Rusak/Hilang│ │👥 Users Aktif │ │✓ Return Rate │ │
│  │ 20           │ │ 35           │ │ 92%          │ │
│  │ items        │ │ active       │ │ on-time      │ │
│  └──────────────┘ └──────────────┘ └──────────────┘ │
│                                                       │
├─────────────────────────────────────────────────────┤
│ ALERTS & WARNINGS                                   │
├─────────────────────────────────────────────────────┤
│ ⚠️  Stok Menipis: Monitor, Keyboard (2 items)       │
│ ⚠️  Belum Dikembalikan: 3 items overdue (5+ hari)   │
│ ⚠️  Return Pending Approval: 2 requests             │
│                                                       │
├─────────────────────────────────────────────────────┤
│ RECENT ACTIVITY                                     │
├─────────────────────────────────────────────────────┤
│ Today, 14:30 | Aji returned 2x Keyboard (rusak...  │
│ Today, 13:15 | Budi borrowed 1x Monitor (ret 25..  │
│ Today, 10:45 | Admin approved Aji's borrow req..   │
│                                                       │
└─────────────────────────────────────────────────────┘
```

#### Code:
```java
public class ModernDashboardViewEnhanced extends JPanel {
    
    private DashboardService dashboardService;
    
    public void initDashboard() {
        setLayout(new BorderLayout());
        setBackground(ColorPalette.getBackgroundPrimary());
        
        // 1. Load data dengan loading indicator
        loadDashboardDataAsync();
        
        // 2. Create statistics cards
        JPanel statisticsPanel = createStatisticsPanel();
        
        // 3. Create alerts panel
        JPanel alertsPanel = createAlertsPanel();
        
        // 4. Create activity feed
        JPanel activityPanel = createActivityFeedPanel();
        
        // Layout
        JPanel mainPanel = new JPanel(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.add(statisticsPanel);
        mainPanel.add(Box.createVerticalStrut(20));
        mainPanel.add(alertsPanel);
        mainPanel.add(Box.createVerticalStrut(20));
        mainPanel.add(activityPanel);
        
        JScrollPane scrollPane = new JScrollPane(mainPanel);
        scrollPane.setBorder(null);
        add(scrollPane, BorderLayout.CENTER);
    }
    
    private JPanel createStatisticsPanel() {
        JPanel panel = new JPanel(new GridLayout(2, 3, 15, 15));
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));
        panel.setBackground(ColorPalette.getBackgroundPrimary());
        
        try {
            DashboardDTO data = dashboardService.buildFullDashboard();
            
            // Row 1
            panel.add(new ModernStatisticCard(
                "📦", "Total Barang", String.valueOf(data.getTotalBarang()), 
                "items in inventory", ColorPalette.getPrimary()
            ));
            
            panel.add(new ModernStatisticCard(
                "✓", "Tersedia", String.valueOf(data.getBarangTersedia()),
                "available for borrow", ColorPalette.getSuccess()
            ));
            
            panel.add(new ModernStatisticCard(
                "📤", "Dipinjam", String.valueOf(data.getBarangDipinjam()),
                "currently borrowed", ColorPalette.getInfo()
            ));
            
            // Row 2
            panel.add(new ModernStatisticCard(
                "⚠️", "Rusak/Hilang", String.valueOf(data.getBarangRusak()),
                "damaged or lost", ColorPalette.getError()
            ));
            
            panel.add(new ModernStatisticCard(
                "👥", "Users Aktif", String.valueOf(data.getUsersActive()),
                "active last 30 days", ColorPalette.getPrimaryLight()
            ));
            
            panel.add(new ModernStatisticCard(
                "✓", "Return Rate", data.getReturnRatePercent() + "%",
                "on-time returns", ColorPalette.getSuccess()
            ));
            
        } catch (SQLException e) {
            e.printStackTrace();
            ToastNotification.showError("Failed to load statistics");
        }
        
        return panel;
    }
    
    private void loadDashboardDataAsync() {
        LoadingPanel loading = new LoadingPanel("Loading dashboard data...", true);
        add(loading, BorderLayout.CENTER);
        
        SwingWorker<Void, Void> worker = new SwingWorker<Void, Void>() {
            @Override
            protected Void doInBackground() {
                try {
                    // Simulate loading
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                return null;
            }
            
            @Override
            protected void done() {
                remove(loading);
                initDashboard();
                revalidate();
                repaint();
            }
        };
        
        worker.execute();
    }
}
```

---

### 4️⃣ Menggunakan Toast Notifications

```java
// Di berbagai action handlers

// SUCCESS
try {
    service.tambahBarang(...);
    ToastNotification.showSuccess("Barang berhasil ditambahkan!");
} catch (Exception e) {
    ToastNotification.showError("Gagal menambahkan barang: " + e.getMessage());
}

// ERROR
try {
    service.setujuiPeminjaman(peminjamanId);
} catch (BusinessException e) {
    ToastNotification.showError(e.getMessage());
    // Output: "Stok 'Monitor' tidak cukup. Tersedia: 2, diminta: 5"
}

// WARNING
if (jumlahDikembalikan < jumlahPinjam) {
    ToastNotification.showWarning("Pengembalian sebagian. Sisa: " + 
                                   (jumlahPinjam - jumlahDikembalikan) + " items");
}

// INFO
ToastNotification.showInfo("Processing your request...");
```

---

### 5️⃣ Dark Mode Support

```java
// Main application startup
public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            // Check saved preference
            String savedTheme = loadThemePreference(); // from config
            
            if ("dark".equals(savedTheme)) {
                ColorPalette.setColorMode(ColorPalette.ColorMode.DARK);
            } else {
                ColorPalette.setColorMode(ColorPalette.ColorMode.LIGHT);
            }
            
            // All UI components automatically use current theme
            new LoginView();
        });
    }
}

// Toggle dark mode (di settings)
private void toggleDarkMode() {
    ColorPalette.ColorMode current = ColorPalette.getColorMode();
    ColorPalette.ColorMode newMode = current == ColorPalette.ColorMode.LIGHT ?
        ColorPalette.ColorMode.DARK : ColorPalette.ColorMode.LIGHT;
    
    ColorPalette.setColorMode(newMode);
    saveThemePreference(newMode.toString().toLowerCase());
    
    // Refresh all UI components
    SwingUtilities.updateComponentTreeUI(mainFrame);
    mainFrame.repaint();
    
    ToastNotification.showSuccess("Theme changed to " + newMode.toString().toLowerCase());
}
```

---

### 6️⃣ Business Exception Handling

```java
public class PeminjamanApprovalDialog extends JDialog {
    
    private void handleApproveClick() {
        try {
            PeminjamanService service = new PeminjamanService();
            service.setujuiPeminjamanWithValidation(peminjamanId, keterangan);
            
            ToastNotification.showSuccess("Peminjaman disetujui");
            onSuccess.run();
            dispose();
            
        } catch (ValidationException e) {
            // Input validation error (user error)
            ToastNotification.showWarning(e.getMessage());
            // Example: "Peminjaman #123 tidak ditemukan"
            
        } catch (BusinessException e) {
            // Business rule violation
            ToastNotification.showError(e.getMessage());
            // Example: "Stok 'Monitor' tidak cukup. Tersedia: 2, diminta: 5"
            
            if ("INSUFFICIENT_STOCK".equals(e.getErrorCode())) {
                // Handle specific business error
                showStockWarning(e.getDetails());
            }
            
        } catch (SQLException e) {
            // Database error
            ToastNotification.showError("Database error: " + e.getMessage());
            logError(e);
        }
    }
}
```

---

## 🏗️ ARCHITECTURE LAYERS

```
┌─────────────────────────────────┐
│      VIEW LAYER (Swing UI)       │
│  - ModernDashboardView           │
│  - PeminjamanView                │
│  - ReturnItemApprovalView        │
└────────────┬────────────────────┘
             │ uses
┌────────────▼────────────────────┐
│    COMPONENT LAYER (UI Parts)    │
│  - ModernStatisticCard           │
│  - ModernChart                   │
│  - LoadingPanel                  │
│  - ModernActivityPanel           │
└────────────┬────────────────────┘
             │ displays data from
┌────────────▼────────────────────┐
│    SERVICE LAYER (Business Logic)│
│  - BarangService                 │
│  - PeminjamanService             │
│  - ReturnItemService             │
│  - DashboardService              │
└────────────┬────────────────────┘
             │ validates & orchestrates
┌────────────▼────────────────────┐
│  CONTROLLER LAYER (Data Access)  │
│  - BarangController              │
│  - PeminjamanController          │
│  - ReturnItemController          │
│  - UserController                │
└────────────┬────────────────────┘
             │ accesses
┌────────────▼────────────────────┐
│   MODEL LAYER + DATABASE         │
│  - Barang, Peminjaman, ReturnItem│
│  - MySQL tables                  │
└─────────────────────────────────┘
```

---

## 🧪 TESTING EXAMPLES

```java
// Unit test untuk validation
@Test
public void testValidateReturnQuantity_ExceedsLimit() {
    assertThrows(ValidationException.class, () -> {
        ValidationUtil.requireValidReturnQuantity(10, 5, "Monitor");
    });
}

@Test
public void testValidateCondition_InvalidCondition() {
    assertThrows(ValidationException.class, () -> {
        ValidationUtil.requireValidCondition("sangat rusak");
    });
}

// Integration test untuk service
@Test
public void testCreateReturnRequest_Success() throws Exception {
    ReturnItemService service = new ReturnItemService();
    int returnId = service.createReturnRequest(
        peminjamanId, username, 5, "baik", "Test return"
    );
    assertTrue(returnId > 0);
}

@Test
public void testApproveReturn_UpdatesStock() throws Exception {
    // Get stock before
    int stockBefore = barangCtrl.getBarangByKode(kode).getStok();
    
    // Approve return
    service.approveReturn(returnId, "admin");
    
    // Verify stock updated
    int stockAfter = barangCtrl.getBarangByKode(kode).getStok();
    assertTrue(stockAfter > stockBefore);
}
```

---

## 📝 STEP-BY-STEP MIGRATION GUIDE

### Phase 1: Add Service Layer (1-2 days)
1. ✅ Create `BarangService.java`
2. ✅ Create `PeminjamanService.java`
3. ✅ Create `ReturnItemService.java`
4. Update `BarangController` - add helper methods
5. Update `PeminjamanController` - add `getAll()` method

### Phase 2: Enhance Components (1-2 days)
1. ✅ Create `ModernStatisticCard.java`
2. ✅ Create `LoadingPanel.java`
3. Create `ModernActivityPanel.java`
4. Create `ModernAlertPanel.java`
5. Update `ModernDashboardView.java` - use new components

### Phase 3: Add Utilities (1 day)
1. ✅ Create `BusinessException.java`
2. ✅ Create `ColorPalette.java`
3. ✅ Create `ToastNotification.java`
4. Enhanced `ValidationUtil.java`

### Phase 4: Refactor Views (2-3 days)
1. Update `BarangView.java` - use service layer, add validation
2. Update `PeminjamanView.java` - refactor to service pattern
3. Update `ReturnItemApprovalView.java` - enhance return workflow
4. Update `LoginView.java` - theme support

### Phase 5: Database Updates & Testing (1 day)
1. Apply database schema changes
2. Create `return_history` table
3. Test all workflows end-to-end
4. Performance testing

---

**Total Estimated Time**: 5-7 days for full implementation

---
