# 🔧 SistemInventaris - Panduan Refactoring Komprehensif

**Status**: Production-Ready Improvements  
**Versi**: 4.0.0 (Target)  
**Waktu Estimasi**: 3-4 hari (full implementation)

---

## 📋 RINGKASAN PERUBAHAN

### BAGIAN 1: FUNCTIONAL IMPROVEMENTS ✅

#### 1.1 Enhanced Return System
**File**: `src/controller/ReturnItemController.java` + `src/service/ReturnItemService.java`

**Improvements**:
```
✓ Validasi pengembalian (tidak boleh > jumlah pinjam)
✓ Status tracking: Dipinjam → Dikembalikan Sebagian → Selesai
✓ Update stok otomatis saat approve return
✓ Comprehensive logging (tanggal, user, jumlah, kondisi)
✓ Late return detection (opsional notification)
```

**Key Logic**:
- Method: `validateReturnQuantity()` - cek quantity validity
- Method: `updatePeminjamanStatus()` - update status peminjaman
- Method: `updateStokBerdasarkanKondisi()` - smart stock update based on item condition
- Method: `logReturnHistory()` - detailed return tracking

**Database Changes**:
```sql
-- Enhance peminjaman table dengan status extended
ALTER TABLE peminjaman ADD COLUMN status_extended ENUM('dipinjam', 'dikembalikan_sebagian', 'selesai') DEFAULT 'dipinjam';

-- New return_history table untuk detailed logging
CREATE TABLE return_history (
  id INT AUTO_INCREMENT PRIMARY KEY,
  return_item_id INT NOT NULL,
  tanggal_return DATE NOT NULL,
  jumlah INT NOT NULL,
  kondisi_barang VARCHAR(50),
  username VARCHAR(100),
  approved_by VARCHAR(100),
  status VARCHAR(20),
  keterangan TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (return_item_id) REFERENCES return_items(id)
);
```

---

#### 1.2 Dashboard Statistics Enhancement
**File**: `src/service/DashboardService.java` + `src/model/dto/DashboardDTO.java`

**Statistics to Add**:
```
Dashboard Statistics:
├── 📦 Total Barang (count all items)
├── 📦 Barang Tersedia (stok > 0)
├── 📤 Barang Dipinjam (active borrows)
├── ⚠️  Barang Rusak/Hilang (from return logs)
├── 👥 Users Aktif (last 30 days)
└── 📊 Tingkat Pengembalian (%)

Visualizations:
├── 📈 Chart Peminjaman per Bulan (6 months)
├── 🍰 Chart Kategori Barang (by type)
└── 📋 Chart Status Pengembalian (by status)

Activity Feed:
├── Recent Borrows (5 latest)
├── Recent Returns (5 latest)
└── Recent Changes (5 latest)

Alerts:
├── ⚠️  Stok Menipis (<5 items)
├── ⚠️  Barang Belum Dikembalikan (overdue)
└── ⚠️  Return Pending Approval
```

---

#### 1.3 Validation Framework
**File**: `src/util/validation/ValidationUtil.java` (Enhanced)

**Validation Checks**:
```java
// Input validation
✓ requireNotEmpty(value, fieldName)
✓ requirePositive(value, fieldName)
✓ requireValidEmail(email)
✓ requireValidDate(date, format)

// Business logic validation
✓ requireValidReturnQuantity(actual, max, itemName)
✓ requireValidCondition(kondisi)
✓ requireValidStatus(status)
✓ requireValidUsername(username)

// Custom validation
✓ validateBarangAvailability(kodeBarang, quantity)
✓ validatePeminjamanApproval(peminjamanId)
✓ validateReturnApproval(returnItemId)
```

---

### BAGIAN 2: DASHBOARD UI/UX (Modern Design) ✨

#### 2.1 Modern Component Library
**New Files**:
- `src/component/ModernStatisticCard.java`
- `src/component/ModernChart.java`
- `src/component/ModernActivityPanel.java`
- `src/component/ModernAlertPanel.java`
- `src/component/ModernTablePanel.java`

**Design Features**:
```
✓ Gradient backgrounds (soft to vibrant)
✓ Rounded corners (border-radius 12-16px equivalent)
✓ Soft shadows (depth effect)
✓ Smooth animations (color transitions, size changes)
✓ Professional typography (font size scaling)
✓ Responsive layout (FlowLayout, GridBagLayout)
✓ Hover effects (color change, shadow intensify)
✓ Loading states (spinner, skeleton)
```

#### 2.2 Color Palette (Enterprise SaaS Style)
```
Primary:      #0069D6 (Modern Blue)
Primary Light: #00BCD4 (Cyan)
Dark:         #0F2044 (Deep Blue)
Text Main:    #1C2032 (Almost Black)
Text Light:   #787E9B (Gray)
Success:      #4CAF50 (Green)
Warning:      #FFC107 (Amber)
Error:        #F44336 (Red)
Background:   #F8FAFD (Light Gray)
Card:         #FFFFFF (White)
```

#### 2.3 Typography
```
- Font Family: SansSerif (system default) / Custom: "Segoe UI"
- H1 (Title): 28px, Bold
- H2 (Subtitle): 18px, SemiBold
- H3 (Card Title): 16px, SemiBold
- Body: 13px, Regular
- Small: 11px, Regular
- Code: 11px, Monospace
```

---

### BAGIAN 3: CODE STRUCTURE (MVC + Service Layer) 🏗️

#### 3.1 Folder Structure (Enhanced)
```
src/
├── Main.java
├── component/              (UI Components)
│   ├── ModernStatisticCard.java
│   ├── ModernChart.java
│   ├── ModernActivityPanel.java
│   ├── ModernAlertPanel.java
│   ├── ModernTablePanel.java
│   └── ... (existing components)
├── controller/             (API/Business Layer)
│   ├── AuthController.java
│   ├── BarangController.java
│   ├── PeminjamanController.java
│   ├── ReturnItemController.java
│   └── ... (existing)
├── model/                  (Data Models)
│   ├── Barang.java
│   ├── Peminjaman.java
│   ├── ReturnItem.java
│   ├── LogBarang.java
│   ├── User.java
│   └── dto/
│       ├── DashboardDTO.java
│       ├── ReturnItemDTO.java
│       └── ... (other DTOs)
├── service/                (Business Logic Layer)
│   ├── BaseService.java
│   ├── BarangService.java      (NEW - business logic for items)
│   ├── PeminjamanService.java   (NEW - business logic for borrows)
│   ├── ReturnItemService.java
│   ├── DashboardService.java
│   └── NotificationService.java (NEW - for alerts)
├── repository/             (NEW - Data Access Layer - Optional)
│   ├── IRepository.java
│   ├── BarangRepository.java
│   └── PeminjamanRepository.java
├── util/
│   ├── DatabaseUtil.java
│   ├── SessionManager.java
│   ├── LogService.java
│   ├── exception/
│   │   ├── ValidationException.java
│   │   └── BusinessException.java (NEW)
│   ├── validation/
│   │   └── ValidationUtil.java (Enhanced)
│   ├── export/
│   │   ├── ExportUtil.java
│   │   ├── PDFExporter.java    (NEW)
│   │   └── ExcelExporter.java  (NEW)
│   ├── notification/
│   │   ├── NotificationUtil.java
│   │   └── ToastNotification.java (NEW)
│   └── theme/
│       ├── ThemeManager.java    (NEW - Dark mode)
│       └── ColorPalette.java    (NEW)
└── view/                   (UI/Presentation Layer)
    ├── LoginView.java
    ├── ModernDashboardView.java (Enhanced)
    ├── BarangView.java
    ├── PeminjamanView.java
    ├── ReturnItemApprovalView.java (Enhanced)
    └── ... (existing views)
```

#### 3.2 Controller Responsibility (Lean Controllers)
```
❌ BEFORE (Fat Controller):
BarangController
├── CRUD operations
├── Validation logic
├── Business logic
├── Logging
├── Notifications
└── UI updates

✅ AFTER (Lean Controller):
BarangController
└── CRUD operations (data access only)

BarangService (NEW)
├── Validation logic
├── Business logic
├── Workflow orchestration
└── Logging
```

#### 3.3 Service Layer Pattern
```java
// Example: Service calling Controller + Validation
public class PeminjamanService extends BaseService {
    
    private PeminjamanController controller;
    private BarangController barangCtrl;
    private LogService logService;
    
    public void ajukanPeminjamanWithValidation(PeminjamanRequest request) 
            throws ValidationException, SQLException {
        
        // Validate input
        validatePeminjamanRequest(request);
        
        // Check business rules
        checkBarangAvailability(request.getKodeBarang(), request.getJumlah());
        checkUserEligibility(request.getUsername());
        
        // Execute via controller
        controller.ajukanPeminjaman(request.toPeminjamanModel());
        
        // Log operation
        logService.catat("PINJAM_REQUEST", request.getUsername() + "...");
        
        // Notify (optional)
        notificationService.notifyAdmin("New borrow request");
    }
}
```

---

### BAGIAN 4: NILAI TAMBAH (Premium Features) 💎

#### 4.1 Dark Mode
**File**: `src/util/theme/ThemeManager.java`
```
Features:
✓ Toggle dark/light mode
✓ Persistent preference (saved in config)
✓ All components respect theme
✓ Smooth transition
```

#### 4.2 Export Functionality
**Files**:
- `src/util/export/PDFExporter.java` (iText library)
- `src/util/export/ExcelExporter.java` (Apache POI library)

```
Export Options:
✓ Export Barang List → PDF/Excel
✓ Export Peminjaman Report → PDF/Excel
✓ Export Return History → PDF/Excel
✓ Custom date range filtering
```

#### 4.3 Role Management
**Enhanced User Model**:
```
User Roles:
├── ADMIN (full access)
├── STAFF (manage items, approve borrows)
├── USER (borrow, view history)
└── VIEWER (read-only)

Permission Matrix:
┌─────────┬────────┬────────┬────────┐
│ Action  │ ADMIN  │ STAFF  │ USER   │
├─────────┼────────┼────────┼────────┤
│ Add Item│   ✓    │   ✓    │   ✗    │
│ Borrow  │   ✓    │   ✓    │   ✓    │
│ Return  │   ✓    │   ✓    │   ✓    │
│ Approve │   ✓    │   ✓    │   ✗    │
└─────────┴────────┴────────┴────────┘
```

#### 4.4 Toast Notifications
**File**: `src/util/notification/ToastNotification.java`
```
Features:
✓ Non-blocking notifications
✓ Auto-dismiss (3-5 seconds)
✓ Multiple types: success, warning, error, info
✓ Positioned at corner
✓ Smooth animation
```

#### 4.5 Loading States
**File**: `src/component/LoadingPanel.java`
```
Loading Indicators:
✓ Spinner animation
✓ Skeleton placeholders
✓ Progress bar (for long operations)
✓ Loading text
```

---

## 🗂️ FILE CHANGES SUMMARY

### NEW FILES TO CREATE
1. `src/service/BarangService.java`
2. `src/service/PeminjamanService.java`
3. `src/service/NotificationService.java`
4. `src/util/exception/BusinessException.java`
5. `src/util/theme/ThemeManager.java`
6. `src/util/theme/ColorPalette.java`
7. `src/util/export/PDFExporter.java`
8. `src/util/export/ExcelExporter.java`
9. `src/util/notification/ToastNotification.java`
10. `src/component/ModernStatisticCard.java`
11. `src/component/ModernChart.java`
12. `src/component/ModernActivityPanel.java`
13. `src/component/ModernAlertPanel.java`
14. `src/component/LoadingPanel.java`
15. `src/model/request/PeminjamanRequest.java`
16. `src/model/request/ReturnRequest.java`

### FILES TO ENHANCE
1. `src/controller/ReturnItemController.java` (add validation methods)
2. `src/service/ReturnItemService.java` (improve logic)
3. `src/service/DashboardService.java` (add more statistics)
4. `src/util/validation/ValidationUtil.java` (add business rule checks)
5. `src/view/ModernDashboardView.java` (redesign layout)
6. `src/view/ReturnItemApprovalView.java` (improve UX)
7. `src/model/User.java` (add role field)
8. `src/model/dto/DashboardDTO.java` (expand statistics)

### DATABASE SCHEMA UPDATES
```sql
-- Add to peminjaman table
ALTER TABLE peminjaman ADD COLUMN status_extended VARCHAR(50) DEFAULT 'dipinjam';

-- Create return_history for detailed logging
CREATE TABLE return_history (
  id INT AUTO_INCREMENT PRIMARY KEY,
  return_item_id INT,
  tanggal_return DATE,
  jumlah INT,
  kondisi_barang VARCHAR(50),
  username VARCHAR(100),
  approved_by VARCHAR(100),
  status VARCHAR(20),
  keterangan TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create system_config for dark mode, settings
CREATE TABLE system_config (
  id INT AUTO_INCREMENT PRIMARY KEY,
  config_key VARCHAR(100) UNIQUE,
  config_value TEXT,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

---

## 📚 LIBRARY RECOMMENDATIONS

### Required Libraries (add to `lib/` folder)
```
✓ mysql-connector-j-9.0.0.jar (existing)
✓ itext-core-8.0.0.jar (PDF export)
✓ itext-layout-8.0.0.jar (PDF export)
✓ poi-5.2.3.jar (Excel export)
✓ poi-ooxml-5.2.3.jar (Excel export)
```

### Optional Libraries (for enhanced features)
```
• flatlaf-3.2.jar (modern L&F for Swing)
• jfreechart-1.5.3.jar (advanced charting)
• json-20230227.jar (JSON handling)
```

---

## 🎯 IMPLEMENTATION STEPS (Recommended Order)

### Week 1: Foundation
- [ ] Day 1-2: Create Service layer, enhance validation
- [ ] Day 3: Create modern components
- [ ] Day 4: Enhance ReturnItem system with validation
- [ ] Day 5: Update database schema, create migrations

### Week 2: Features
- [ ] Day 6-7: Improve Dashboard with new statistics
- [ ] Day 8: Add Export functionality (PDF/Excel)
- [ ] Day 9: Implement Dark mode
- [ ] Day 10: Add Role management

### Week 3: Polish
- [ ] Day 11: Add Toast notifications
- [ ] Day 12: Implement loading states
- [ ] Day 13: Refactor views with new components
- [ ] Day 14: Testing & documentation

---

## ✅ QUALITY CHECKLIST

Before considering complete:

### Code Quality
- [ ] All methods have JavaDoc comments
- [ ] No duplicate code (DRY principle)
- [ ] Consistent naming conventions
- [ ] Proper exception handling
- [ ] No hardcoded values

### Functionality
- [ ] All validations working
- [ ] Stock updates accurate
- [ ] Return workflow complete
- [ ] Dashboard loads data correctly
- [ ] Export functions work for all data

### UI/UX
- [ ] Components look professional
- [ ] Responsive to window resize
- [ ] Loading states show on long operations
- [ ] Notifications appear and disappear smoothly
- [ ] Hover effects work on all buttons

### Testing
- [ ] Unit tests for service layer
- [ ] Integration tests for workflows
- [ ] Manual testing of all features
- [ ] Edge case testing (invalid inputs, etc)

---

## 📖 NEXT STEPS

1. **Read this document** - Understand overall architecture
2. **Review implementation examples** - See concrete code patterns
3. **Create service layer** - Start with `BarangService.java`
4. **Enhance models** - Add new DTOs and request objects
5. **Update database** - Apply schema changes
6. **Refactor controllers** - Make them lean
7. **Build modern UI** - Create component library
8. **Test thoroughly** - Ensure no regressions

---

**Created**: 2026-05-01  
**Version**: 4.0.0  
**Status**: Production-Ready Blueprint  

