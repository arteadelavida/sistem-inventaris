# BUG FIX - Return Item Status Issue

## Masalah yang Ditemukan

**Fitur kembalikan barang pinjaman gagal dengan error:**
```
"Hanya peminjaman yang approved dapat dikembalikan"
```

Padahal user sudah memiliki peminjaman dengan status "disetujui" (approved).

---

## Root Cause Analysis

### Sebelum Fix (BUGGY)
```java
// ReturnItemService.java - Line 51
if (!peminjaman.getStatus().equalsIgnoreCase("approved")) {
    throw new ValidationException("Hanya peminjaman yang approved dapat dikembalikan");
}
```

**Problem:**
1. Service check untuk status `"approved"`
2. Tapi di database, status yang digunakan adalah `"disetujui"` (Indonesian)
3. Hasil: Validasi SELALU gagal meskipun peminjaman sudah disetujui

**Status Flow di Database:**
- `pending` - User baru ajukan peminjaman
- `disetujui` - Admin sudah approve
- `ditolak` - Admin reject

**Tapi kode mencari:** `"approved"` (English) - TIDAK ADA!

---

## Solusi

### Fix #1: Ubah Status Check ke Bahasa Database
```java
// ReturnItemService.java - Line 51 (FIXED)
if (!peminjaman.getStatus().equalsIgnoreCase("disetujui")) {
    throw new ValidationException("Hanya peminjaman yang sudah disetujui dapat dikembalikan. " +
        "Status saat ini: " + peminjaman.getStatus());
}
```

**Improvement:**
- Sekarang match dengan status di database
- Error message lebih informatif (show actual status)
- User tahu kenapa gagal

---

### Fix #2: Hapus Status "completed" yang Tidak Ada
```java
// ReturnItemService.java - Line 213 (BEFORE)
for (ReturnItem item : returns) {
    if (item.getPeminjamanId() == peminjamanId && 
        (item.getStatus().equalsIgnoreCase("approved") || 
         item.getStatus().equalsIgnoreCase("completed"))) {  // <-- DOESN'T EXIST
        returned += item.getJumlahDikembalikan();
    }
}

// ReturnItemService.java - Line 213 (AFTER)
for (ReturnItem item : returns) {
    if (item.getPeminjamanId() == peminjamanId && 
        item.getStatus().equalsIgnoreCase("approved")) {
        returned += item.getJumlahDikembalikan();
    }
}
```

**Why:**
- return_items table hanya punya status: `pending`, `approved`, `rejected`
- Tidak ada `completed` status
- Logika salah: hanya check `approved` saja

---

## Status Mapping

### Peminjaman Table
```
Status                 | Meaning
─────────────────────────────────────
pending     → User ajukan pinjam, tunggu admin
disetujui   → Admin setuju, user boleh ambil barang
ditolak     → Admin tolak permintaan
```

### Return Items Table  
```
Status                 | Meaning
─────────────────────────────────────
pending     → User request pengembalian, tunggu admin
approved    → Admin approve pengembalian
rejected    → Admin reject pengembalian
```

---

## Testing

### Scenario Sebelum Fix
```
1. User ajukan pinjam barang → Status: pending
2. Admin setujui → Status: disetujui ✓
3. User kembalikan barang → ERROR! "Hanya peminjaman yang approved..." ✗
   (Padahal peminjaman sudah disetujui)
```

### Scenario Sesudah Fix
```
1. User ajukan pinjam barang → Status: pending
2. Admin setujui → Status: disetujui ✓
3. User kembalikan barang → SUCCESS! Return request dibuat ✓
4. Admin approve pengembalian → Stok bertambah otomatis ✓
```

---

## Files Modified

1. **src/service/ReturnItemService.java**
   - Line 51: Ubah `"approved"` → `"disetujui"`
   - Line 52: Update error message agar lebih informatif
   - Line 218: Hapus check untuk status `"completed"` yang tidak ada

---

## Impact Analysis

### Fitur yang Terpengaruh
- Return Item Creation
- Return Item Status Validation
- Return Quantity Calculation

### Severity
- **Before Fix:** Return item feature completely broken
- **After Fix:** Working as expected

### User Impact
- Users dapat mengembalikan barang pinjaman
- Admin dapat approve/reject pengembalian
- Stok terupdate otomatis saat approve

---

## Additional Notes

### Naming Convention Issue
Sistem menggunakan status dalam Bahasa Indonesia di database:
- `disetujui` instead of `approved`
- `ditolak` instead of `rejected`
- `pending` (universal)

Jika ada tempat lain yang hardcode `"approved"`, bisa juga fail. 
Rekomendasi: Gunakan constant atau enum untuk status.

### Better Approach (Recommended for Future)
```java
public enum PeminjamanStatus {
    PENDING("pending"),
    DISETUJUI("disetujui"),
    DITOLAK("ditolak");
    
    private String value;
    PeminjamanStatus(String value) { this.value = value; }
    public String getValue() { return value; }
}

// Usage:
if (!peminjaman.getStatus().equalsIgnoreCase(PeminjamanStatus.DISETUJUI.getValue())) {
    // ...
}
```

---

## Verification Checklist

- [x] Code compiled successfully
- [x] No new compilation errors
- [x] Logic matches database schema
- [x] Error message more informative
- [x] Application runs without crash

---

## Deployment Note

**No database changes required.** Hanya kode service layer yang diupdate. Backward compatible dengan existing data.
