# 🎯 IMPLEMENTASI ROADMAP - SistemInventaris v4.0

**Timeline**: 5-7 hari  
**Status**: Siap untuk dikerjakan  
**Kesulitan**: Medium-Advanced  

---

## 📌 PRE-IMPLEMENTATION CHECKLIST

- [ ] **BACKUP DATABASE** - Critical!
  ```bash
  mysqldump -u root -p inventaris > backup_$(date +%Y%m%d).sql
  ```

- [ ] **Read all documentation**
  - [ ] REFACTORING_GUIDE.md
  - [ ] IMPLEMENTATION_EXAMPLES.md
  - [ ] DATABASE_MIGRATIONS.sql (this file)

- [ ] **Prepare environment**
  - [ ] Visual Studio Code open dengan project
  - [ ] MySQL Server running
  - [ ] Maven/Gradle installed (optional, for dependency management)

- [ ] **Download required libraries** (optional, for advanced features)
  - [ ] itext-core-8.0.0.jar (PDF export)
  - [ ] poi-5.2.3.jar (Excel export)

---

## 🔧 FASE 1: SERVICE LAYER (Hari 1-2)

### 1.1 Create Core Services ✅ (Sebagian sudah dibuat)

- [x] **ValidationUtil.java** - Enhanced validation dengan business rules
  - ✅ Sudah dibuat dan di-enhance
  - Lokasi: `src/util/validation/ValidationUtil.java`
  
- [x] **BusinessException.java** - Exception untuk business logic
  - ✅ Sudah dibuat
  - Lokasi: `src/util/exception/BusinessException.java`

- [x] **BarangService.java** - Service layer untuk items
  - ✅ Sudah dibuat dengan metode lengkap
  - Lokasi: `src/service/BarangService.java`
  - Methods: tambahBarangWithValidation, updateBarang, getBarangLowStock, getBarangStatistics

- [x] **PeminjamanService.java** - Service layer untuk borrowing
  - ✅ Sudah dibuat dengan workflow complete
  - Lokasi: `src/service/PeminjamanService.java`
  - Methods: ajukanPeminjamanWithValidation, setujuiPeminjaman, getOverduePeminjaman

- [ ] **ReturnItemService.java** - Service layer untuk returns (Enhance existing)
  - ⏳ File sudah ada, perlu di-enhance
  - Lokasi: `src/service/ReturnItemService.java`
  - TODO: Add validation, approval workflow, stock update logic

- [ ] **DashboardService.java** - Service untuk dashboard statistics (Enhance)
  - ⏳ File sudah ada, perlu di-expand
  - Lokasi: `src/service/DashboardService.java`
  - TODO: Add more statistics methods, charts data

### 1.2 Update Existing Controllers (Lean Down)

- [ ] **BarangController.java**
  - [ ] Add helper method: `getBarangByStockRange(min, max)`
  - [ ] Add method: `getBarangByCategory(category)` (jika ada kategori)
  - [ ] Keep it LEAN - hanya CRUD, logic ke service

- [ ] **PeminjamanController.java**
  - [ ] Add method: `getAll()`
  - [ ] Add method: `getById(id)`
  - [ ] Ensure transaction handling tetap atomic

- [ ] **ReturnItemController.java**
  - [ ] Add method: `getReturnItemById(id)`
  - [ ] Add method: `updateReturnStatus(returnId, newStatus)`
  - [ ] Keep data access, logic ke service

---

## 🎨 FASE 2: MODERN UI COMPONENTS (Hari 2-3)

### 2.1 Create Component Library ✅ (Sebagian sudah dibuat)

- [x] **ModernStatisticCard.java** - Card untuk statistics
  - ✅ Sudah dibuat dengan design professional
  - Features: Shadow, rounded corners, hover effect

- [x] **LoadingPanel.java** - Loading spinner dengan progress
  - ✅ Sudah dibuat dengan animation
  - Features: Auto-rotating spinner, message, progress bar

- [ ] **ModernActivityPanel.java** - Activity feed panel
  - ⏳ Perlu dibuat
  - Features:
    - List of recent activities (borrows, returns, approvals)
    - Timestamp formatting
    - Color-coded by activity type
    - Scrollable list dengan max items

- [ ] **ModernAlertPanel.java** - Alerts dan warnings panel
  - ⏳ Perlu dibuat
  - Features:
    - Color-coded alerts (warning, error, info)
    - Icon + message
    - Action buttons (dismiss, view details)
    - Different alert types: low stock, overdue items, pending approvals

- [ ] **ModernChart.java** - Simple chart component
  - ⏳ Perlu dibuat (atau gunakan JFreeChart)
  - Features:
    - Bar chart untuk monthly borrowing
    - Pie chart untuk item categories
    - Line chart untuk trends

### 2.2 Create Utility Components

- [x] **ColorPalette.java** - Centralized color management
  - ✅ Sudah dibuat dengan light & dark mode
  - Lokasi: `src/util/theme/ColorPalette.java`

- [x] **ToastNotification.java** - Toast notifications
  - ✅ Sudah dibuat dengan 4 types (success, error, warning, info)
  - Lokasi: `src/util/notification/ToastNotification.java`
  - Features: Auto-dismiss, positioned bottom-right, smooth appearance

- [ ] **ThemeManager.java** - Dark mode manager
  - ⏳ Perlu dibuat
  - Features:
    - Load/save theme preference
    - Apply theme to all components
    - Config storage (ke system_config table)

### 2.3 Enhance Existing Components

- [ ] **ModernDashboardView.java** - Update dengan new components
  - [ ] Use ModernStatisticCard untuk statistics
  - [ ] Add ModernAlertPanel untuk alerts
  - [ ] Add ModernActivityPanel untuk recent activities
  - [ ] Add charts (JFreeChart atau custom ModernChart)
  - [ ] Add refresh button dengan async loading

- [ ] **RoundedButton.java** - Enhance existing
  - [ ] Add hover effect (shadow intensify, color change)
  - [ ] Add disabled state styling
  - [ ] Add loading state (spinner dalam button)

- [ ] **Existing Views** (LoginView, BarangView, etc)
  - [ ] Apply ColorPalette untuk consistency
  - [ ] Add ToastNotification untuk feedback
  - [ ] Implement dark mode support

---

## 📊 FASE 3: DASHBOARD ENHANCEMENT (Hari 3)

### 3.1 Statistics Enhancement

- [ ] **DashboardDTO.java** - Expand data model
  - [ ] Add fields untuk new statistics:
    - `int usersActive` - Users aktif last 30 days
    - `int returnRatePercent` - Percentage pengembalian on-time
    - `int averageBorrowDays` - Rata-rata durasi peminjaman
    - `List<CategoryStats> categoryStats` - Barang by category
  - [ ] Add nested classes untuk charts data

- [ ] **DashboardService.java** - Enhance methods
  - [ ] Expand `buildFullDashboard()` dengan chart data
  - [ ] Add method: `getMonthlyBorrowingData()` - 6 bulan terakhir
  - [ ] Add method: `getCategoryDistribution()` - Barang per kategori
  - [ ] Add method: `getReturnRateAnalysis()` - On-time vs late returns

### 3.2 Alert System

- [ ] **NotificationService.java** (NEW)
  - [ ] Method: `getAlerts()` - Compile all alerts
  - [ ] Method: `checkLowStock()` - Barang dengan stok < threshold
  - [ ] Method: `checkOverdueItems()` - Items belum dikembalikan
  - [ ] Method: `checkPendingApprovals()` - Waiting for admin
  - [ ] Method: `markAlertAsRead(alertId)`

### 3.3 Activity Feed

- [ ] **ActivityFeedService.java** (NEW, optional)
  - [ ] Method: `getRecentActivities(limit)` - Recent borrows/returns
  - [ ] Method: `getActivitiesByUser(username)`
  - [ ] Method: `getActivitiesByDateRange(from, to)`

---

## 🔒 FASE 4: FUNCTIONAL IMPROVEMENTS (Hari 4)

### 4.1 Enhanced Return System

- [ ] **ReturnItemController.java** - Add validation methods
  - [ ] Method: `validateReturnQuantity(jumlahDikembalikan, maxJumlah)`
  - [ ] Method: `validateCondition(kondisi)` - Check valid conditions
  - [ ] Method: `updatePeminjamanStatus(peminjamanId, newStatus)`

- [ ] **ReturnItemService.java** - Enhance logic
  - [ ] Implement full validation dalam `createReturnRequest()`
  - [ ] Implement stock update logic dalam `approveReturn()`
  - [ ] Add method: `getReturnHistory(peminjamanId)` - Get return details
  - [ ] Add method: `calculateDamageValue(returnItem)` - For reporting

### 4.2 Status Management

- [ ] **Update Database**
  - [ ] Run migration: Add `status_extended` ke peminjaman table
  - [ ] Run migration: Create `return_history` table
  - [ ] Update models untuk reflect new columns

- [ ] **Peminjaman Status Flow**
  ```
  pending → approved → (returns) → 
           dikembalikan_sebagian → selesai
              atau
           selesai (jika full return)
  ```

- [ ] **Model Updates**
  - [ ] `Peminjaman.java` - Add `statusExtended` field
  - [ ] `ReturnItem.java` - Add `statusDetail` field
  - [ ] Update getters/setters

### 4.3 Stock Auto-Update

- [ ] **Stock Update Logic** (di ReturnItemService)
  - [ ] If kondisi = "baik": `add 100% back to stok`
  - [ ] If kondisi = "rusak ringan": `add 70% back to stok`
  - [ ] If kondisi = "rusak berat": `add 0% back to stok` (write-off)
  - [ ] If kondisi = "hilang": `add 0% back to stok` (write-off)

### 4.4 Late Return Notifications (Optional)

- [ ] **Check Overdue Logic**
  - [ ] Implement dalam PeminjamanService: `getOverduePeminjaman()`
  - [ ] Integrate dengan NotificationService untuk alerts
  - [ ] Show dalam dashboard alerts panel

---

## 💾 FASE 5: DATABASE UPDATES (Hari 4-5)

- [ ] **Backup Database**
  ```sql
  mysqldump -u root -p inventaris > backup_pre_v4.sql
  ```

- [ ] **Run Migrations** (from DATABASE_MIGRATIONS.sql)
  - [ ] Migration 1: Enhance peminjaman table
  - [ ] Migration 2: Create return_history table
  - [ ] Migration 3: Create return_items enhanced columns
  - [ ] Migration 4: Create system_config table
  - [ ] Migration 5: Enhance user table (role management)
  - [ ] Migration 6: Create notification_log table
  - [ ] Migration 7: Create activity_log table

- [ ] **Verify Migrations**
  ```sql
  DESCRIBE peminjaman;
  SHOW TABLES;
  ANALYZE TABLE peminjaman, return_items, barang, user;
  ```

---

## 🏗️ FASE 6: CODE REFACTORING (Hari 5)

- [ ] **Replace Controller Calls dengan Service Calls**
  - [ ] BarangView → BarangService
  - [ ] PeminjamanView → PeminjamanService
  - [ ] ReturnItemApprovalView → ReturnItemService
  - [ ] All views use error handling dengan ToastNotification

- [ ] **Pattern: Service → Controller → DAO**
  - [ ] Validation di Service
  - [ ] Business logic di Service
  - [ ] CRUD operations di Controller
  - [ ] SQL queries di Controller

- [ ] **Example Refactor: Add Barang Flow**
  ```java
  // OLD
  BarangController.tambahBarang(barang);
  
  // NEW
  try {
      BarangService service = new BarangService();
      service.tambahBarangWithValidation(kode, nama, harga, stok, ket);
      ToastNotification.showSuccess("Barang added");
  } catch (ValidationException e) {
      ToastNotification.showError(e.getMessage());
  }
  ```

---

## 🎯 FASE 7: TESTING (Hari 6)

### 7.1 Unit Testing

- [ ] **ValidationUtil.java** - Test validation methods
  ```java
  @Test
  void testRequireValidReturnQuantity_ExceedsLimit() {
      assertThrows(ValidationException.class, () -> {
          ValidationUtil.requireValidReturnQuantity(10, 5, "Monitor");
      });
  }
  ```

- [ ] **Service Layer** - Test business logic
  ```java
  @Test
  void testCreateReturnRequest_ValidInput() throws Exception {
      // Setup
      // Execute
      int returnId = service.createReturnRequest(...);
      // Verify
      assertTrue(returnId > 0);
  }
  ```

### 7.2 Integration Testing

- [ ] **End-to-End Return Workflow**
  - [ ] Request return (validation passes)
  - [ ] Admin approves return
  - [ ] Stock updates correctly
  - [ ] Peminjaman status updated
  - [ ] History logged

- [ ] **Dashboard Data Loading**
  - [ ] Load statistics correctly
  - [ ] Charts render with data
  - [ ] Alerts calculated accurately
  - [ ] Activity feed populates

### 7.3 Manual Testing

- [ ] **Test all workflows**
  - [ ] Add barang ✓
  - [ ] Borrow item (with validation)
  - [ ] Approve borrow (stock decreases)
  - [ ] Return item (partial/full)
  - [ ] Approve return (stock increases)
  - [ ] View dashboard statistics
  - [ ] Check dark mode toggle
  - [ ] Test all notifications

- [ ] **Edge cases**
  - [ ] Return quantity > borrow quantity (should fail)
  - [ ] Invalid condition (should fail)
  - [ ] Overdue items (should show alert)
  - [ ] Low stock items (should show warning)

---

## 🚀 FASE 8: POLISH & OPTIMIZATION (Hari 7)

- [ ] **Performance Optimization**
  - [ ] Add database indexes (already in migrations)
  - [ ] Implement lazy loading untuk dashboard
  - [ ] Cache frequently accessed data
  - [ ] Profile slow queries

- [ ] **UI Polish**
  - [ ] Consistent spacing & alignment
  - [ ] Hover effects smooth
  - [ ] Loading states show properly
  - [ ] Mobile-responsive (if applicable)

- [ ] **Documentation**
  - [ ] Update README.md with new features
  - [ ] Add usage examples untuk service layer
  - [ ] Document API changes
  - [ ] Add troubleshooting guide

- [ ] **Code Quality**
  - [ ] Run code formatter
  - [ ] Add JavaDoc comments
  - [ ] Remove dead code
  - [ ] Rename variables untuk clarity

---

## 📋 FEATURES CHECKLIST

### Functional Features
- [ ] Enhanced return system with validation
- [ ] Status tracking (dipinjam → dikembalikan_sebagian → selesai)
- [ ] Auto stock update on return
- [ ] Return history logging
- [ ] Late return detection
- [ ] Comprehensive dashboard statistics
- [ ] Activity feed (recent borrows/returns)
- [ ] Alert system (low stock, overdue, pending)
- [ ] Dark mode support
- [ ] Role-based access control (optional)

### UI/UX Features
- [ ] Modern professional design
- [ ] Gradient backgrounds & soft shadows
- [ ] Smooth animations & transitions
- [ ] Toast notifications (success/error/warning/info)
- [ ] Loading states (spinner, skeleton)
- [ ] Responsive layout
- [ ] Consistent color scheme
- [ ] Professional typography
- [ ] Hover effects on buttons

### Code Quality Features
- [ ] Service layer pattern
- [ ] Proper validation framework
- [ ] Exception handling (ValidationException, BusinessException)
- [ ] Lean controllers (CRUD only)
- [ ] Clear separation of concerns
- [ ] Consistent naming conventions
- [ ] JavaDoc comments
- [ ] DRY principle (no duplicate code)

---

## 💾 DELIVERABLES

After completion, you should have:

```
src/
├── component/
│   ├── ModernStatisticCard.java ✅
│   ├── LoadingPanel.java ✅
│   ├── ModernActivityPanel.java (TODO)
│   ├── ModernAlertPanel.java (TODO)
│   ├── ModernChart.java (TODO)
│   └── ... (existing components)
├── controller/
│   ├── BarangController.java (ENHANCED)
│   ├── PeminjamanController.java (ENHANCED)
│   ├── ReturnItemController.java (ENHANCED)
│   └── ... (other controllers)
├── service/
│   ├── BarangService.java ✅
│   ├── PeminjamanService.java ✅
│   ├── ReturnItemService.java (ENHANCED)
│   ├── DashboardService.java (ENHANCED)
│   ├── NotificationService.java (TODO)
│   └── BaseService.java
├── util/
│   ├── validation/ValidationUtil.java ✅
│   ├── exception/BusinessException.java ✅
│   ├── theme/ColorPalette.java ✅
│   ├── theme/ThemeManager.java (TODO)
│   ├── notification/ToastNotification.java ✅
│   └── ... (other utilities)
├── view/
│   ├── ModernDashboardView.java (ENHANCED)
│   ├── ReturnItemApprovalView.java (ENHANCED)
│   └── ... (other views)
├── model/
│   ├── Barang.java
│   ├── Peminjaman.java (ENHANCED)
│   ├── ReturnItem.java (ENHANCED)
│   └── ... (other models)
└── Main.java

docs/
├── REFACTORING_GUIDE.md ✅
├── IMPLEMENTATION_EXAMPLES.md ✅
└── DATABASE_MIGRATIONS.sql ✅
```

---

## ⚠️ IMPORTANT NOTES

1. **Always backup database before migrations**
2. **Test thoroughly in development first**
3. **Keep service layer separate from UI**
4. **Use validation consistently**
5. **Handle exceptions properly**
6. **Don't skip testing**
7. **Commit changes regularly to git**

---

## 🆘 TROUBLESHOOTING

### Issue: Validation Exception during return
**Solution**: Check ReturnItemService.createReturnRequest() - ensure all validations pass

### Issue: Stock not updating after return approval
**Solution**: Verify updateStokBerdasarkanKondisi() logic in ReturnItemService

### Issue: Dashboard loads slowly
**Solution**: Implement lazy loading for charts and activity feeds

### Issue: Dark mode colors don't apply
**Solution**: Ensure ColorPalette.setColorMode() called on app startup

---

## 📞 SUPPORT

For questions or issues:
1. Check IMPLEMENTATION_EXAMPLES.md for code samples
2. Review REFACTORING_GUIDE.md for architecture
3. Check DATABASE_MIGRATIONS.sql for DB issues
4. Review service layer implementations for business logic

---

**Last Updated**: 2026-05-01  
**Version**: 4.0.0  
**Status**: Ready to implement
