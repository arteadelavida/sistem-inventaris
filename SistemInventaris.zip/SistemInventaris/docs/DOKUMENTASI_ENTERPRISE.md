# 📋 DOKUMENTASI SISTEM INVENTARIS ENTERPRISE

## Ringkasan Proyek

**Sistem Inventaris Enterprise** adalah aplikasi Java Swing untuk manajemen peminjaman barang dengan arsitektur berlapis modern, UI/UX enterprise-grade, dan fitur komprehensif untuk tracking, validasi, dan laporan.

**Status:** ✅ Phase 3 - Complete (Service Layer + Dashboard UI)

---

## 📁 Struktur Direktori

```
SistemInventaris/
├── src/
│   ├── Main.java                          # Entry point aplikasi
│   ├── component/                         # Custom UI Components
│   │   ├── RoundedButton.java            # Tombol dengan sudut bulat
│   │   ├── RoundedTextField.java         # Text field dengan sudut bulat
│   │   ├── ModernCard.java               # Card component modern
│   │   ├── StatisticCard.java            # Card untuk statistik
│   │   ├── GradientPanel.java            # Panel dengan gradient
│   │   └── PremiumHeader.java            # Header premium
│   │
│   ├── controller/                        # Data Access Layer (DAO)
│   │   ├── AuthController.java           # Login/Logout
│   │   ├── UserController.java           # User management
│   │   ├── BarangController.java         # Inventory items
│   │   ├── PeminjamanController.java     # Loan management
│   │   ├── ReturnItemController.java     # Item returns
│   │   └── LogBarangController.java      # Activity logging
│   │
│   ├── model/                             # Domain Models
│   │   ├── User.java                     # User model
│   │   ├── Barang.java                   # Item model
│   │   ├── Peminjaman.java               # Loan model
│   │   ├── ReturnItem.java               # Return model
│   │   ├── LogBarang.java                # Activity log
│   │   └── dto/                          # Data Transfer Objects
│   │       ├── ReturnItemDTO.java        # Return with calculations
│   │       └── DashboardDTO.java         # Dashboard statistics
│   │
│   ├── service/                           # Business Logic Layer
│   │   ├── BaseService.java              # Abstract base service
│   │   ├── ReturnItemService.java        # Return item business logic
│   │   └── DashboardService.java         # Dashboard aggregation
│   │
│   ├── util/                              # Utilities
│   │   ├── DatabaseUtil.java             # DB connection management
│   │   ├── SessionManager.java           # User session
│   │   ├── LogService.java               # Activity logging
│   │   ├── notification/
│   │   │   └── NotificationUtil.java     # Consistent notifications
│   │   ├── validation/
│   │   │   ├── ValidationUtil.java       # Input validation
│   │   │   └── exception/
│   │   │       └── ValidationException.java  # Custom exception
│   │   └── export/
│   │       └── ExportUtil.java           # CSV/PDF export
│   │
│   └── view/                              # Presentation Layer (UI)
│       ├── LoginView.java                # Login screen
│       ├── RegisterView.java             # Registration screen
│       ├── ModernDashboardView.java      # Main dashboard (NEW)
│       ├── BarangView.java               # Inventory management
│       ├── PeminjamanView.java           # Loan management
│       ├── ReturnItemApprovalView.java   # Admin return approval
│       ├── UserReturnItemView.java       # User return requests
│       └── ... (other views)
│
├── lib/                                   # External libraries
│   └── mysql-connector-j-8.x.jar         # MySQL JDBC driver
│
├── out/                                   # Compiled output
│   └── (compiled .class files)
│
└── (Database setup scripts & README)
```

---

## 🏗️ Arsitektur Berlapis (Layered Architecture)

```
┌─────────────────────────────────────────────┐
│  Presentation Layer (View)                  │
│  - LoginView, BarangView, ModernDashboardView
└────────────────┬────────────────────────────┘
                 │
┌────────────────▼────────────────────────────┐
│  Business Logic Layer (Service)             │
│  - DashboardService, ReturnItemService      │
│  - Validation, Aggregation, Calculations    │
└────────────────┬────────────────────────────┘
                 │
┌────────────────▼────────────────────────────┐
│  Data Access Layer (Controller/DAO)         │
│  - BarangController, PeminjamanController   │
│  - Direct database operations               │
└────────────────┬────────────────────────────┘
                 │
┌────────────────▼────────────────────────────┐
│  Database Layer                             │
│  - MySQL (sisteminventaris, login schema)  │
└─────────────────────────────────────────────┘
```

---

## 🔧 Komponen Utama

### 1. **Service Layer (Business Logic)**

#### `BaseService.java`
- Abstract base class untuk semua services
- Menyediakan common methods:
  - `logOperation()` - Log setiap operasi
  - `validateNotNull()`, `validateNotEmpty()` - Validasi input
  - `validatePositive()`, `validateNonNegative()` - Validasi nilai numerik

#### `ReturnItemService.java`
- Mengelola logika return item dengan validasi komprehensif
- Key features:
  - Validasi jumlah pengembalian ≤ jumlah pinjam
  - Status return tracking (pending/approved/rejected)
  - Auto-update stok barang berdasarkan kondisi
  - Deteksi keterlambatan pengembalian
  - Query history dan detail pengembalian

#### `DashboardService.java`
- Agregasi data statistik dari semua controllers
- Provides:
  - Basic stats: total items, available, borrowed, damaged/lost
  - Recent activities (loans + returns)
  - Alerts (low stock, late returns, damaged items)
  - 12-month trends

### 2. **Data Transfer Objects (DTOs)**

#### `ReturnItemDTO.java`
- Complete return item information dengan calculated fields
- Fields:
  - Core: id, peminjamanId, username, kodeBarang, namaBarang
  - Quantities: jumlahPinjam, jumlahDikembalikan, jumlahBelumDikembalikan
  - Status: statusPeminjaman, statusPengembalian, kondisiBarang
  - Analysis: terlambat (boolean), hariTerlambat (int)

#### `DashboardDTO.java` + Inner Classes
- **DashboardDTO**: Container untuk semua dashboard data
  - Statistics fields
  - Collections: recentActivities, alerts, peminjamanPerBulan
  
- **Inner Class ActivityDTO**:
  - Represents: user activity (loans, returns)
  - Enum Type: PEMINJAMAN, PENGEMBALIAN, BARANG_BARU, BARANG_UPDATE
  - Auto-generates emoji icons based on activity type
  
- **Inner Class AlertDTO**:
  - Represents: system alerts
  - Enum Severity: INFO, WARNING, ERROR
  - Auto-timestamps when created

### 3. **Validation & Error Handling**

#### `ValidationUtil.java`
- 7 centralized validation methods:
  - `requireNotEmpty(String value, String fieldName)` - String validation
  - `requirePositive(int value, String fieldName)` - Value > 0
  - `requireNonNegative(int value, String fieldName)` - Value >= 0
  - `requireLength(String, int min, int max, String fieldName)` - String length
  - `requireValidEmail(String email)` - Email format
  - `requireSufficientStock(int borrowed, int returned, String fieldName)`
  - `requireValidReturnQuantity(int borrowed, int returned, String fieldName)`

#### `ValidationException.java`
- Custom exception untuk input validation errors
- Throws dari ValidationUtil dan service methods
- Clear, user-friendly error messages

### 4. **Notification System**

#### `NotificationUtil.java`
- 6 consistent notification methods:
  - `showSuccess()` - Green dialog
  - `showError()` - Red dialog
  - `showWarning()` - Yellow dialog
  - `showInfo()` - Blue dialog
  - `showConfirm()` - Yes/No dialog
  - `showInput()` - Input prompt dialog

### 5. **Export Utilities**

#### `ExportUtil.java`
- CSV export functionality
- CSV format untuk universal compatibility
- Methods:
  - `exportTableToCSV(JTable, filePath)` - Export JTable
  - `exportToCSV(List<String[]>, headers, filePath)` - Export generic data
  - `generateDefaultFilename()` - Auto-generate filename dengan timestamp

### 6. **UI Components - ModernDashboardView**

Modern dashboard dengan:
- **Statistics Cards**: Total items, Available, Borrowed, Damaged/Lost
- **Alerts Panel**: Low stock, Late returns, Damaged items
- **Recent Activities**: Recent loans & returns dengan icons
- **Responsive Layout**: Scroll-able, adaptive grid

Enterprise styling:
- Soft shadows & rounded corners
- Color-coded severity (green, yellow, red)
- Smooth typography (SansSerif)
- Professional spacing & padding

---

## 📊 Database Schema

### Databases
- **login**: User authentication & management
- **sisteminventaris**: Inventory, loans, returns, activity logs

### Key Tables

#### `login.users`
```sql
id INT PRIMARY KEY AUTO_INCREMENT
username VARCHAR(50) UNIQUE
password VARCHAR(255)
nama_lengkap VARCHAR(100)
email VARCHAR(100)
role ENUM('admin', 'user')
status ENUM('pending', 'active', 'inactive')
created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
```

#### `sisteminventaris.barang`
```sql
id INT PRIMARY KEY AUTO_INCREMENT
kode_barang VARCHAR(50) UNIQUE
nama_barang VARCHAR(100)
deskripsi TEXT
kategori VARCHAR(50)
stok INT DEFAULT 0
stok_minimal INT DEFAULT 5
lokasi VARCHAR(100)
created_at TIMESTAMP
updated_at TIMESTAMP
```

#### `sisteminventaris.peminjaman`
```sql
id INT PRIMARY KEY AUTO_INCREMENT
username VARCHAR(50)
kode_barang VARCHAR(50)
nama_barang VARCHAR(100)
jumlah INT
tanggal_pinjam DATE
tanggal_kembali DATE
status ENUM('pending', 'approved', 'rejected', 'returned')
status_return ENUM('pending', 'completed', 'belum')
keterangan_admin TEXT
created_at TIMESTAMP
```

#### `sisteminventaris.return_items`
```sql
id INT PRIMARY KEY AUTO_INCREMENT
peminjaman_id INT
username VARCHAR(50)
kode_barang VARCHAR(50)
nama_barang VARCHAR(100)
jumlah_pinjam INT
jumlah_dikembalikan INT
tanggal_pinjam DATE
tanggal_return DATE
kondisi_barang ENUM('baik', 'rusak ringan', 'rusak berat', 'hilang')
status ENUM('pending', 'approved', 'rejected')
created_at TIMESTAMP
```

---

## 🚀 Cara Kompilasi & Menjalankan

### 1. Kompilasi Seluruh Proyek
```powershell
# Windows PowerShell
cd "c:\Users\Farras\Documents\TI SEM 2\SistemInventaris"

# Compile dengan target Java 14
javac --release 14 -cp "lib/*" -d "out" $(Get-ChildItem -Recurse "src" -Filter *.java | % FullName)
```

### 2. Jalankan Aplikasi
```powershell
# Run Main.java
java -cp "out;lib/*" Main
```

### 3. Setup Database
```bash
# Execute SETUP_DATABASE.sql di MySQL
# Akan membuat: login database & sisteminventaris database
```

---

## 🎨 Desain UI/UX

### Warna Enterprise
```
PRIMARY:        #0069 8C (Teal Blue)
PRIMARY_LIGHT:  #00BCD4 (Light Cyan)
DARK:           #0F2044 (Navy)
TEXT_MAIN:      #1C2032 (Dark Gray)
TEXT_LIGHT:     #787B9B (Light Gray)
SUCCESS:        #4CAF50 (Green)
WARNING:        #FFC107 (Amber)
ERROR:          #F44336 (Red)
BG_LIGHT:       #F8FAFD (Off-white)
CARD_BG:        #FFFFFF (White)
```

### Components
- **RoundedButton**: Tombol dengan sudut bulat, modern styling
- **RoundedTextField**: Text input dengan rounded corners
- **ModernCard**: Card container dengan shadow
- **StatisticCard**: Specialized untuk menampilkan metrics
- **GradientPanel**: Background dengan gradient effect

### Features
- Responsive layout
- Smooth animations
- Consistent spacing
- Dark/Light shadow effects
- Professional typography

---

## ✅ Validasi & Error Handling

### Validation Flow
```
Input dari User
    ↓
ValidationUtil.require*() method
    ↓
If Invalid → Throw ValidationException
    ↓
NotificationUtil.showError() → User
    ↓
If Valid → Proceed ke Service Layer
```

### Error Messages
- User-friendly bahasa Indonesia
- Clear field identification
- Actionable guidance
- Consistent formatting

---

## 📝 Fitur Komprehensif

### ✅ Implemented (Phase 3)
- [x] Service layer dengan BaseService
- [x] Validation framework
- [x] Custom exception handling
- [x] DTOs untuk data transfer
- [x] Dashboard service aggregation
- [x] Return item service
- [x] Modern dashboard UI
- [x] Notification system
- [x] Export utilities (CSV)
- [x] Recent activities tracking
- [x] Alerts system

### 🔄 In Progress
- [ ] Refactor views to use services
- [ ] Add dark mode support
- [ ] Advanced table features (search, sort, pagination)
- [ ] PDF export functionality
- [ ] Role-based access control improvements

### 📋 Todo
- [ ] Activity timeline visualization
- [ ] Performance optimization for large datasets
- [ ] Caching strategy
- [ ] Unit & integration tests

---

## 🔐 Keamanan

### Implemented
- ✅ User authentication (login/logout)
- ✅ Role-based access (admin/user)
- ✅ Session management
- ✅ Input validation
- ✅ SQL prepared statements (prevent SQL injection)
- ✅ Password hashing (placeholder - to be improved)

### Recommendations
- [ ] Implement bcrypt for password hashing
- [ ] Add CSRF protection
- [ ] Implement rate limiting
- [ ] Add activity audit trail
- [ ] Encrypt sensitive data

---

## 📈 Performance Considerations

### Database
- Use indexes on frequently queried fields (username, status)
- Implement pagination for large result sets
- Cache dashboard data for 5 minutes

### UI
- Lazy load data using SwingWorker
- Implement virtual scrolling for large lists
- Minimize component creation

### Code
- Service layer caching
- DTO pattern untuk efficient data transfer
- Connection pooling via DatabaseUtil

---

## 🐛 Known Issues & Limitations

### Current
1. Dashboard data loads synchronously (fixed via SwingWorker)
2. No pagination for large datasets
3. Export limited to CSV (PDF requires library)
4. Activity log retention unlimited

### To Address
1. Add database indexes
2. Implement pagination
3. Add PDF library dependency
4. Archive old logs

---

## 📚 Dependencies

- **Java**: JDK 14+
- **Database**: MySQL 5.7+ / MariaDB 10.3+
- **JDBC Driver**: mysql-connector-j-8.x.jar
- **UI Framework**: Java Swing (built-in)

---

## 👥 User Roles

### Admin
- Manage all inventory items
- Approve/reject loans & returns
- View system-wide statistics
- Access activity logs
- Manage users

### User
- Browse available items
- Request loans
- Track personal loans
- Submit returns
- View personal history

---

## 📞 Support & Maintenance

### For Issues
1. Check application logs in LogService
2. Review database connection settings in DatabaseUtil
3. Verify MySQL user permissions
4. Check file permissions for export directory

### For Enhancement
1. Follow existing service layer pattern
2. Add comprehensive javadoc comments
3. Write validation tests
4. Update this documentation

---

**Version**: 3.0 (Enterprise Architecture)  
**Last Updated**: 2024  
**Status**: ✅ Production Ready
