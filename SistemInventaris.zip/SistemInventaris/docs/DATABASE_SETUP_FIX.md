# Database Setup & Java Compatibility Fixes

## Errors Found & Fixed

### ✓ FIXED: Java 8 Compatibility Issue
**Error:** `java.lang.NoSuchMethodError: java.lang.String.isBlank()Z`

**Problem:** `isBlank()` is Java 11+, but project targets Java 8

**Locations Fixed:**
- `PeminjamanController.java` line 98: `isBlank()` → `trim().isEmpty()`
- `PeminjamanController.java` line 144: `isBlank()` → `trim().isEmpty()`
- `BarangView.java` line 393: `isBlank()` → `trim().isEmpty()`
- `BarangView.java` line 965: `isBlank()` → `trim().isEmpty()`

**Status:** ✓ COMPILED SUCCESSFULLY

---

## CRITICAL: Database Setup Required

### ❌ Missing Table: `return_items`
```
Error: Table 'sisteminventaris.return_items' doesn't exist
```

### ❌ Log Table Issue  
```
Error: Unknown column 'username' in 'field list'
```

### Solution: Run Database Setup Script

**Step 1: Open MySQL**
- Start MySQL Workbench or phpMyAdmin
- Or use MySQL terminal: `mysql -u root -p`

**Step 2: Run Setup Script**
```sql
-- Copy content from: docs/SETUP_DATABASE.sql
-- And paste into MySQL
```

**Or via Command Line:**
```bash
mysql -u root -p sisteminventaris < docs/SETUP_DATABASE.sql
mysql -u root -p login < docs/SETUP_DATABASE.sql
```

---

## What SETUP_DATABASE.sql Does

✓ Creates/Updates `login` database with:
- `users` table (id, username, password, role, status)
- `password_reset_requests` table

✓ Creates/Updates `sisteminventaris` database with:
- `barang` table (inventory)
- `peminjaman` table (loans)
- `return_items` table (returns) ← **THIS WAS MISSING**
- `log_aktivitas` table (activity logs)

---

## Step-by-Step Fix

### 1. Read Setup Script
File: `docs/SETUP_DATABASE.sql`

### 2. Open MySQL Connection
```
Host: localhost (or your MySQL host)
User: root (or your MySQL user)
Password: your MySQL password
```

### 3. Execute Script
Copy entire content from SETUP_DATABASE.sql and execute in MySQL

### 4. Verify Tables Created
```sql
USE sisteminventaris;
SHOW TABLES;
```

Should show: `barang`, `log_aktivitas`, `peminjaman`, `return_items`

---

## Testing After Database Fix

Run application again:
```bash
java -cp "out;lib/*" Main
```

**All features should work now:**
- ✓ Login
- ✓ Setujui Peminjaman (Approve Loans)
- ✓ Tolak Peminjaman (Reject Loans)
- ✓ Kembalikan Barang (Return Items)
- ✓ Admin Approval untuk Return

---

## Troubleshooting

### If Still Getting "Table doesn't exist"
1. Verify you ran SETUP_DATABASE.sql in correct database
2. Check `USE sisteminventaris;` before running
3. Check if tables exist: `SHOW TABLES;`

### If Still Getting "Unknown column"
1. Verify log_aktivitas has columns: id, username, role, aksi, detail, waktu
2. Run: `DESCRIBE log_aktivitas;`
3. If missing columns, drop and recreate:
```sql
DROP TABLE log_aktivitas;
-- Then run SETUP_DATABASE.sql again
```

### If "Access Denied"
1. Check MySQL user has permissions for both databases
2. Verify database names in code:
   - `login` database for authentication
   - `sisteminventaris` database for inventory

---

## Java Fixes Summary

**All isBlank() calls replaced with trim().isEmpty() for Java 8 compatibility**

### Before (Java 11+)
```java
if (text.isBlank()) { ... }
```

### After (Java 8)
```java
if (text.trim().isEmpty()) { ... }
```

**Result:** No more NoSuchMethodError
