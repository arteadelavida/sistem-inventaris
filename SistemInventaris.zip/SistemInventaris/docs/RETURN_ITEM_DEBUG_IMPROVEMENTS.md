# Return Item Submit - Debugging & Error Handling Improvements

## Problem Reported

User gets generic error message: "✗ Gagal mengirim request. Silakan coba lagi." without knowing the actual cause.

---

## Root Cause

The return item submission workflow was silently failing without providing detailed error information:

1. **Controller Issue**: `ReturnItemController.createReturnRequest()` catches exceptions and returns -1 without providing details
2. **View Issue**: `UserReturnItemView.submitReturnRequest()` only checks if returnId > 0, doesn't capture actual exceptions

This made debugging difficult because the user couldn't see what was actually going wrong.

---

## Improvements Applied

### Fix #1: Add Exception Handling to View

**File:** `src/view/UserReturnItemView.java`

```java
// BEFORE:
int returnId = controller.createReturnRequest(...);
if (returnId > 0) {
    // success
} else {
    JOptionPane.showMessageDialog(this, "✗ Gagal mengirim request. Silakan coba lagi.", ...);
}

// AFTER:
try {
    int returnId = controller.createReturnRequest(...);
    if (returnId > 0) {
        // success
    } else {
        JOptionPane.showMessageDialog(this, "✗ Gagal mengirim request. Periksa apakah barang sudah dikembalikan sebelumnya.", ...);
    }
} catch (Exception e) {
    e.printStackTrace();
    JOptionPane.showMessageDialog(this, "✗ Error: " + e.getMessage(), "Error", ...);
}
```

**Impact:** Now user sees the actual exception message instead of generic "Gagal mengirim request"

---

### Fix #2: Add Debug Logging to Controller

**File:** `src/controller/ReturnItemController.java`

Added comprehensive debug logging to `createReturnRequest()`:

```java
// Step 1: Query peminjaman
System.out.println("DEBUG: Found peminjaman - kodeBarang=" + kodeBarang + ", namaBarang=" + namaBarang);
System.out.println("DEBUG: No peminjaman found with ID: " + peminjamanId);

// Step 2: Check kodeBarang validity
System.out.println("DEBUG: kodeBarang is null or empty!");

// Step 3: Insert return request
System.out.println("DEBUG: Executing insert return request for peminjaman=" + peminjamanId);
System.out.println("DEBUG: Return request created with ID: " + returnId);

// Step 4: Error logging
System.out.println("DEBUG: Error querying peminjaman: " + e.getMessage());
System.out.println("DEBUG: Error inserting return request: " + e.getMessage());
```

**Impact:** When user submits return request, console output shows exactly which step failed

---

## Debugging Workflow

When user reports "gagal mengirim request" again:

1. **Check Console Output** - Look for DEBUG messages to see which step failed:
   - "No peminjaman found with ID:" → Invalid peminjaman ID
   - "kodeBarang is null or empty!" → Missing data in database
   - "Error querying peminjaman:" → Database connectivity issue
   - "Error inserting return request:" → Database constraint violation

2. **Check UI Error Message** - View now shows actual exception details:
   ```
   ✗ Error: [actual exception message]
   ```

3. **Possible Causes**:
   - Peminjaman record doesn't exist
   - Peminjaman record is missing kode_barang/nama_barang
   - Database connection issue
   - Constraint violation (e.g., duplicate return request)

---

## Testing After Fix

When user tries to submit return request:

**Scenario 1: Success**
```
Console: DEBUG: Return request created with ID: 15
UI: ✓ Request pengembalian telah dikirim!
```

**Scenario 2: Peminjaman Not Found**
```
Console: DEBUG: No peminjaman found with ID: 999
UI: ✗ Gagal mengirim request. Periksa apakah barang sudah dikembalikan sebelumnya.
```

**Scenario 3: Exception Thrown**
```
Console: DEBUG: Error inserting return request: Duplicate entry
UI: ✗ Error: Duplicate entry 'peminjaman_id-username' for key 'return_items.unique_return_request'
   (or actual database error message)
```

---

## Next Steps if User Still Reports Error

1. Have user run app and try to submit return request
2. Check console output for DEBUG messages
3. Check UI error message  
4. Based on the actual error, determine root cause:
   - If "No peminjaman found" → Check if loan with 'disetujui' status exists
   - If database error → Check database schema and constraints
   - If null values → Check if kode_barang/nama_barang are properly populated in peminjaman table

---

## Code Quality Notes

### Added Features
- ✓ Exception handling at view layer
- ✓ Debug logging at controller layer
- ✓ Better error messages to user

### Still Using Return Codes
- Controller returns -1 on failure (could be improved to throw exceptions)
- View checks for > 0 to determine success

### Recommendation for Future Refactoring
Instead of returning -1, make controller throw exceptions:
```java
// FUTURE: Better approach
public int createReturnRequest(...) throws ValidationException, SQLException {
    if (peminjaman == null) {
        throw new ValidationException("Peminjaman not found: " + peminjamanId);
    }
    // ... rest of code
}
```

This would eliminate the need for debug logging and provide cleaner exception handling.
