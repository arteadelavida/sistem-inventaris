# 📚 Penerapan OOP di Proyek SistemInventaris

Dokumen ini menjelaskan bagaimana **4 pilar OOP** diterapkan dalam struktur proyek SistemInventaris Anda.

---

## 📁 Struktur Proyek

```
src/
├── model/              # Model layer - Data entities
│   ├── Barang.java
│   ├── User.java
│   ├── Peminjaman.java
│   ├── ReturnItem.java
│   └── ...
├── controller/         # Controller layer - Data access
│   ├── BarangController.java
│   ├── UserController.java
│   └── ...
├── service/            # Service layer - Business logic
│   ├── BaseService.java (Abstract)
│   ├── BarangService.java
│   ├── UserService.java
│   └── ...
├── view/               # View layer - UI
├── component/          # Custom UI components
└── util/               # Utility classes
```

---

## 1️⃣ INHERITANCE (Pewarisan)

### Contoh: BaseService → BarangService

**BaseService** adalah **parent class (abstract)** yang menyediakan fungsi umum untuk semua service.

```java
// Parent class (Abstract)
public abstract class BaseService {
    protected void logOperation(String action, String detail) {
        LogService.catat(action, detail);
    }
    
    protected void validateNotNull(Object obj, String fieldName) {
        if (obj == null) {
            throw new IllegalArgumentException(fieldName + " tidak boleh null");
        }
    }
    
    protected void validateNotEmpty(String str, String fieldName) {
        if (str == null || str.trim().isEmpty()) {
            throw new IllegalArgumentException(fieldName + " tidak boleh kosong");
        }
    }
}
```

**BarangService** mewarisi dari **BaseService** dan menggunakan method-nya:

```java
// Child class
public class BarangService extends BaseService {
    
    public void tambahBarangWithValidation(String kodeBarang, String namaBarang, 
                                           int harga, int stok, String keterangan) {
        // Menggunakan method dari parent class
        ValidationUtil.requireNotEmpty(kodeBarang, "Kode barang");
        
        Barang barang = new Barang(kodeBarang, namaBarang, harga, stok, keterangan);
        barangCtrl.tambahBarang(barang);
        
        // Menggunakan logOperation() dari BaseService
        logOperation("TAMBAH_BARANG", 
            "Barang baru: " + kodeBarang + " (" + namaBarang + "), stok: " + stok);
    }
}
```

### Keuntungan di Proyek:
✅ **Code Reusability** - Semua service punya akses ke `logOperation()` dan validasi  
✅ **Maintenance** - Jika logic validasi berubah, cukup ubah di BaseService  
✅ **Konsistensi** - Semua service menggunakan cara logging & validasi yang sama

### Service Lain yang Inherit dari BaseService:
- `UserService extends BaseService`
- `PeminjamanService extends BaseService`
- `ReturnItemService extends BaseService`
- `DashboardService extends BaseService`

---

## 2️⃣ ENCAPSULATION (Enkapsulasi)

### Contoh: Barang Model

Class `Barang` menyembunyikan data internal dan menyediakan getter/setter:

```java
public class Barang {
    // Private - hanya bisa diakses dalam class ini
    private String kodeBarang;
    private String namaBarang;
    private int    harga;
    private int    stok;
    private String keterangan;
    
    // Constructor
    public Barang(String kodeBarang, String namaBarang, int harga, int stok, String keterangan) {
        this.kodeBarang  = kodeBarang;
        this.namaBarang  = namaBarang;
        this.harga       = harga;
        this.stok        = stok;
        this.keterangan  = keterangan;
    }
    
    // Getter - Untuk membaca data
    public String getKodeBarang()  { return kodeBarang; }
    public String getNamaBarang()  { return namaBarang; }
    public int    getHarga()       { return harga; }
    public int    getStok()        { return stok; }
    public String getKeterangan()  { return keterangan; }
    
    // Setter - Untuk mengubah data
    public void setKodeBarang(String kodeBarang)  { this.kodeBarang = kodeBarang; }
    public void setNamaBarang(String namaBarang)  { this.namaBarang = namaBarang; }
    public void setHarga(int harga)               { this.harga = harga; }
    public void setStok(int stok)                 { this.stok = stok; }
    public void setKeterangan(String keterangan)  { this.keterangan = keterangan; }
}
```

### Contoh: User Model dengan Validation

```java
public class User {
    private int    id;
    private String username;
    private String password;
    private String role;   // "admin" atau "user"
    private String status; // "pending" atau "approved"
    
    // Getter
    public String getRole() { return role; }
    
    // Method bisnis: Cek apakah user sudah disetujui
    public boolean isApproved() {
        return "active".equalsIgnoreCase(status);
    }
}
```

### Keuntungan di Proyek:
✅ **Data Protection** - Field `stok` tidak bisa langsung diubah sembarangan  
✅ **Validation** - Bisa menambahkan validasi di setter jika diperlukan  
✅ **Flexibility** - Jika butuh validasi stok (misalnya: harus >= 0), cukup ubah setter:

```java
public void setStok(int stok) {
    if (stok < 0) {
        throw new IllegalArgumentException("Stok tidak boleh negatif!");
    }
    this.stok = stok;
}
```

---

## 3️⃣ ABSTRACTION (Abstraksi)

### Contoh: BaseService (Abstract Class)

`BaseService` adalah **abstract class** yang menyembunyikan kompleksitas dan menampilkan hanya interface penting.

```java
public abstract class BaseService {
    // Menyembunyikan cara melakukan logging
    protected void logOperation(String action, String detail) {
        LogService.catat(action, detail);  // Detail implementasi disembunyikan
    }
    
    // Menyembunyikan cara validasi
    protected void validateNotEmpty(String str, String fieldName) {
        if (str == null || str.trim().isEmpty()) {
            throw new IllegalArgumentException(fieldName + " tidak boleh kosong");
        }
    }
}
```

### Keuntungan di Proyek:
✅ **Simplicity** - BarangService tidak perlu tahu **bagaimana cara** LogService bekerja  
✅ **Change-ability** - Jika LogService berubah, BaseService tetap sama  
✅ **Focus on Logic** - Developer bisa fokus pada business logic, bukan implementasi detail

**Tanpa Abstraction** (BURUK):
```java
public void tambahBarang(Barang b) throws SQLException {
    // Harus tahu detail implementasi logging
    String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
    String logEntry = "[" + timestamp + "] TAMBAH_BARANG: " + b.getNamaBarang();
    // ... banyak code untuk write ke file atau database
}
```

**Dengan Abstraction** (BAGUS):
```java
public void tambahBarang(Barang b) throws SQLException {
    barangCtrl.tambahBarang(b);
    logOperation("TAMBAH_BARANG", "Barang: " + b.getNamaBarang());  // Simple!
}
```

---

## 4️⃣ POLYMORPHISM (Polimorfisme)

### Contoh: Berbagai Service dengan Interface Sama

Semua service mewarisi dari `BaseService`, jadi mereka punya interface yang sama:

```java
// Semua service ini punya method serupa
BarangService barangSvc = new BarangService();
UserService userSvc = new UserService();
PeminjamanService peminjamanSvc = new PeminjamanService();

// Tapi cara melakukan logOperation bisa berbeda
barangSvc.logOperation("TAMBAH_BARANG", "Barang baru");
userSvc.logOperation("TAMBAH_USER", "User baru");
peminjamanSvc.logOperation("TAMBAH_PEMINJAMAN", "Peminjaman baru");
```

### Contoh Lebih Konkret: Inner Class untuk Statistik

Dalam `BarangService`, ada inner static class yang merepresentasikan hasil statistik:

```java
public static class BarangStatistics {
    public int totalBarang;
    public int barangTersedia;
    public int barangHabis;
    public int totalNilaiStok;
    
    public BarangStatistics(int total, int tersedia, int habis, int nilaiStok) {
        this.totalBarang = total;
        this.barangTersedia = tersedia;
        this.barangHabis = habis;
        this.totalNilaiStok = nilaiStok;
    }
}

// Penggunaan
public BarangStatistics getBarangStatistics() {
    try {
        List<Barang> all = barangCtrl.getAllBarang();
        int totalBarang = all.size();
        int barangTersedia = 0;
        int barangHabis = 0;
        int totalNilaiStok = 0;
        
        for (Barang b : all) {
            if (b.getStok() > 0) {
                barangTersedia++;
            } else {
                barangHabis++;
            }
            totalNilaiStok += (b.getStok() * b.getHarga());
        }
        
        return new BarangStatistics(totalBarang, barangTersedia, barangHabis, totalNilaiStok);
    } catch (SQLException e) {
        logOperation("GET_BARANG_STATISTICS", e.getMessage());
        return new BarangStatistics(0, 0, 0, 0);
    }
}
```

---

## 5️⃣ LAYERING PATTERN (Architecture)

Proyek menggunakan **3-tier architecture** yang sesuai OOP:

```
┌─────────────────────────────────────┐
│       VIEW LAYER (GUI/Web)          │  BarangView, UserManagementView
├─────────────────────────────────────┤
│     SERVICE LAYER (Business Logic)  │  BarangService, UserService
├─────────────────────────────────────┤
│   CONTROLLER LAYER (Data Access)    │  BarangController, UserController
├─────────────────────────────────────┤
│      MODEL LAYER (Data Entities)    │  Barang, User, Peminjaman
├─────────────────────────────────────┤
│       DATABASE LAYER (Persistence)  │  SQL Database
└─────────────────────────────────────┘
```

### Flow Dari UI ke Database:

```
1. User input di View
   ↓
2. View → Call Service (e.g., barangService.tambahBarangWithValidation())
   ↓
3. Service → Validasi input, call Controller
   ↓
4. Controller → Execute SQL, return Model
   ↓
5. Service → Log operation, return hasil
   ↓
6. View → Display hasil ke user
```

### Contoh Nyata:

```java
// 1. DI VIEW - User klik tombol "Tambah Barang"
// buttonTambah.addActionListener(e -> {
//     String kodeBarang = textKode.getText();
//     String namaBarang = textNama.getText();
//     ...
//     
//     // 2. CALL SERVICE
//     try {
//         barangService.tambahBarangWithValidation(kodeBarang, namaBarang, harga, stok, keterangan);
//         JOptionPane.showMessageDialog(null, "Barang berhasil ditambahkan");
//     } catch (ValidationException ex) {
//         JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
//     }
// });

// 3. DI SERVICE
public void tambahBarangWithValidation(String kodeBarang, String namaBarang, 
                                       int harga, int stok, String keterangan) 
        throws ValidationException, SQLException {
    
    // Validasi input
    ValidationUtil.requireNotEmpty(kodeBarang, "Kode barang");
    ValidationUtil.requireNotEmpty(namaBarang, "Nama barang");
    
    // Cek duplikasi
    Barang existing = barangCtrl.getBarangByKode(kodeBarang);
    if (existing != null) {
        throw new ValidationException("Kode barang '" + kodeBarang + "' sudah terdaftar");
    }
    
    // 4. CALL CONTROLLER
    Barang barang = new Barang(kodeBarang, namaBarang, harga, stok, keterangan);
    barangCtrl.tambahBarang(barang);  // Execute SQL
    
    // 5. LOG OPERATION (dari BaseService)
    logOperation("TAMBAH_BARANG", "Barang baru: " + kodeBarang);
}

// 4. DI CONTROLLER
public void tambahBarang(Barang barang) throws SQLException {
    String sql = "INSERT INTO barang (kode_barang, nama_barang, harga, stok, keterangan) " +
                 "VALUES (?, ?, ?, ?, ?)";
    
    try (Connection conn = DatabaseUtil.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {
        
        ps.setString(1, barang.getKodeBarang());
        ps.setString(2, barang.getNamaBarang());
        ps.setInt(3, barang.getHarga());
        ps.setInt(4, barang.getStok());
        ps.setString(5, barang.getKeterangan());
        ps.executeUpdate();
    }
}
```

---

## 6️⃣ CONTOH PENERAPAN LENGKAP

### Scenario: Menambah barang baru

**Model (Barang.java):**
```java
public class Barang {
    private String kodeBarang;  // Encapsulation: private
    private String namaBarang;
    private int harga;
    private int stok;
    
    public void setStok(int stok) {  // Encapsulation: validation di setter
        if (stok < 0) throw new IllegalArgumentException("Stok tidak boleh negatif");
        this.stok = stok;
    }
}
```

**Service (BarangService.java):**
```java
public class BarangService extends BaseService {  // Inheritance
    public void tambahBarangWithValidation(...) throws ValidationException {
        // Abstraction: Tidak perlu tahu detail cara validasi
        ValidationUtil.requireNotEmpty(kodeBarang, "Kode barang");
        
        // Polymorphism: Semua service punya method ini
        logOperation("TAMBAH_BARANG", ...);  // Dari BaseService
    }
}
```

**Flow:**
```
View → Service.tambahBarangWithValidation() 
    → Validasi (Encapsulation)
    → Controller.tambahBarang()
    → Database INSERT
    → logOperation() (Inheritance dari BaseService)
    → Return hasil
```

---

## 7️⃣ BEST PRACTICES DI PROYEK INI

### ✅ Yang Sudah Diterapkan:

1. **Inheritance** ✅
   - BaseService menyediakan fungsi umum
   - BarangService, UserService extends BaseService

2. **Encapsulation** ✅
   - Model class punya private fields + getter/setter
   - Business logic tersembunyidi service layer

3. **Abstraction** ✅
   - BaseService abstract, menyembunyikan detail implementasi
   - Service layer menyederhanakan complexity

4. **Polymorphism** ✅
   - Semua service punya interface serupa
   - Inner classes untuk return types khusus

5. **Layering** ✅
   - View → Service → Controller → Model → Database
   - Separation of concerns sudah jelas

### 🚀 Saran Improvement:

1. **Tambahkan Interface untuk Service:**
```java
public interface IBarangService {
    void tambahBarangWithValidation(...) throws ValidationException, SQLException;
    List<Barang> getAllBarangSafe();
    BarangStatistics getBarangStatistics();
}

public class BarangService extends BaseService implements IBarangService {
    // implementation
}
```
**Keuntungan:** Lebih mudah untuk unit testing dan dependency injection.

2. **Tambahkan Abstract Method di BaseService untuk Lifecycle Hooks:**
```java
public abstract class BaseService {
    protected abstract String getServiceName();  // Setiap service define nama-nya
    
    protected void logOperation(String action, String detail) {
        LogService.catat("[" + getServiceName() + "] " + action + ": " + detail);
    }
}

public class BarangService extends BaseService {
    @Override
    protected String getServiceName() {
        return "BARANG_SERVICE";
    }
}
```

3. **Gunakan Builder Pattern untuk Barang:**
```java
public class Barang {
    public static class Builder {
        private String kodeBarang;
        private String namaBarang;
        private int harga;
        private int stok;
        
        public Builder kodeBarang(String kode) { this.kodeBarang = kode; return this; }
        public Builder namaBarang(String nama) { this.namaBarang = nama; return this; }
        public Builder harga(int harga) { this.harga = harga; return this; }
        public Builder stok(int stok) { this.stok = stok; return this; }
        
        public Barang build() {
            return new Barang(kodeBarang, namaBarang, harga, stok, "");
        }
    }
}

// Usage
Barang barang = new Barang.Builder()
    .kodeBarang("B001")
    .namaBarang("Kursi")
    .harga(500000)
    .stok(10)
    .build();
```

---

## 📋 Checklist OOP di Proyek

- [x] Inheritance - BaseService → Service classes
- [x] Encapsulation - Private fields + getter/setter di Model
- [x] Abstraction - Abstract BaseService + method visibility
- [x] Polymorphism - Service interface yang sama
- [x] Layering - View → Service → Controller → Model
- [x] Exception handling - Custom exceptions (ValidationException, BusinessException)
- [x] Logging - LogService untuk tracking operations
- [ ] Interface-based design - Bisa ditambahkan (IBarangService, etc)
- [ ] Factory pattern - Bisa ditambahkan untuk object creation
- [ ] Dependency Injection - Bisa ditambahkan untuk loose coupling

---

**Kesimpulan:** Proyek SistemInventaris sudah menerapkan OOP dengan baik. Struktur layering dan inheritance sudah terlihat jelas. Untuk improvement, pertimbangkan menambahkan interface dan design patterns tambahan untuk fleksibilitas lebih.
