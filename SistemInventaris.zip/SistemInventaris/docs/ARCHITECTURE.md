# 🏗️ ARCHITECTURE REFERENCE GUIDE

## System Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                    PRESENTATION LAYER (UI)                       │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐   │
│  │  LoginView   │  │ BarangView   │  │ ModernDashboardView  │   │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────────────┘   │
│         │                 │                  │                    │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐   │
│  │PeminjamanView│  │ReturnItemView│  │UserManagementView    │   │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────────────┘   │
└─────────┼─────────────────┼──────────────────┼──────────────────┘
          │                 │                  │
┌─────────▼─────────────────▼──────────────────▼──────────────────┐
│               BUSINESS LOGIC LAYER (Services)                    │
│  ┌───────────────────┐  ┌────────────────────┐                 │
│  │ ReturnItemService │  │ DashboardService   │                 │
│  │ - Validation      │  │ - Stats Aggregation│                 │
│  │ - Calculations    │  │ - Alerts Generation│                 │
│  │ - Business Rules  │  │ - Trends Analysis  │                 │
│  └────────┬──────────┘  └────────┬───────────┘                 │
│           │                      │                              │
│  ┌────────▼──────────────────────▼──────────────────────────┐   │
│  │             Utilities & Validation                       │   │
│  │  - ValidationUtil: Input validation                      │   │
│  │  - NotificationUtil: Consistent UI feedback             │   │
│  │  - ExportUtil: CSV export functionality                 │   │
│  │  - BaseService: Common service methods                  │   │
│  └────────────────────┬─────────────────────────────────────┘   │
└─────────────────────────┼──────────────────────────────────────┘
                          │
┌─────────────────────────▼──────────────────────────────────────┐
│            DATA ACCESS LAYER (Controllers/DAO)                  │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │  BarangController     PeminjamanController              │   │
│  │  - CRUD operations    - Loan management                 │   │
│  │  - Query items        - Status tracking                 │   │
│  │                                                          │   │
│  │  ReturnItemController UserController                    │   │
│  │  - Return operations  - User management                 │   │
│  │  - Query returns      - Authentication                  │   │
│  │                                                          │   │
│  │  LogBarangController  AuthController                    │   │
│  │  - Activity logging   - Login/Logout                    │   │
│  └─────────────────────────────────────────────────────────┘   │
└─────────────────────────┬──────────────────────────────────────┘
                          │
┌─────────────────────────▼──────────────────────────────────────┐
│              DATABASE LAYER (MySQL)                             │
│  ┌──────────────┐  ┌────────────────────────────────────────┐ │
│  │ login DB     │  │  sisteminventaris DB                   │ │
│  │ - users      │  │  - barang                              │ │
│  └──────────────┘  │  - peminjaman                          │ │
│                    │  - return_items                        │ │
│                    │  - logs                                │ │
│                    └────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────┘
```

---

## Data Flow Examples

### 1️⃣ Dashboard Loading Flow

```
ModernDashboardView
        ↓
   (async)
   SwingWorker.doInBackground()
        ↓
DashboardService.buildFullDashboard()
        ↓
   ┌────────────────────────────┐
   │ populateBasicStats()       │
   │ - BarangController         │
   │ - PeminjamanController     │
   │ - ReturnItemController     │
   ├────────────────────────────┤
   │ populateRecentActivities() │
   │ - Get recent loans/returns │
   │ - Create ActivityDTO items │
   ├────────────────────────────┤
   │ populateAlerts()           │
   │ - Low stock check          │
   │ - Late return check        │
   │ - Damaged items check      │
   ├────────────────────────────┤
   │ populateCharts()           │
   │ - 12-month trends          │
   └────────────────────────────┘
        ↓
   DashboardDTO returned
        ↓
   SwingWorker.done()
        ↓
   ModernDashboardView.refreshUI()
        ↓
   Display on screen
```

### 2️⃣ Return Item Approval Flow

```
UserReturnItemView
  (User submits return form)
        ↓
ReturnItemService.createReturnRequest()
        ├─ ValidationUtil.requireNotEmpty()     → Throws if invalid
        ├─ ValidationUtil.requirePositive()     → Throws if invalid
        ├─ ValidationUtil.requireValidReturnQuantity() → Throws if invalid
        ├─ ReturnItemController.createReturnRequest()
        │  ├─ Update return_items table
        │  └─ Set status = 'pending'
        └─ logOperation() → Log activity
        ↓
ReturnItemApprovalView
  (Admin reviews pending returns)
        ↓
ReturnItemService.approveReturn()
        ├─ ReturnItemController.approveReturn()
        │  ├─ Update return_items status = 'approved'
        │  └─ Update peminjaman status_return
        ├─ If condition == 'baik':
        │  └─ BarangController.tambahMasukBarang()
        │     └─ Increment stok
        ├─ Else (rusak/hilang):
        │  └─ Just log (stok stays same)
        └─ logOperation() → Log approval
        ↓
NotificationUtil.showSuccess()
        ↓
Admin sees success confirmation
```

### 3️⃣ Item Loan Flow with Validation

```
PeminjamanView
  (User requests loan)
        ↓
ValidationUtil.requireSufficientStock()
        ├─ Check: requested_qty <= current_stok ✓
        └─ If not: Throw ValidationException
        ↓
PeminjamanController.tambahPeminjaman()
        ├─ Insert into peminjaman table
        ├─ Set status = 'pending'
        └─ Set status_return = 'belum'
        ↓
LogService.catat()
        ├─ Record activity
        └─ Store in logs table
        ↓
NotificationUtil.showSuccess()
        ↓
Admin review in PeminjamanView
        ├─ Click "Setujui"
        ├─ PeminjamanController.setujui()
        ├─ BarangController.updateBarang() (reduce stok)
        └─ Status = 'approved'
```

---

## Component Interactions

### Service ↔ Controller Pattern

```
ReturnItemService
    ├─ Calls: PeminjamanController.getById()
    ├─ Calls: BarangController.getAllBarang()
    ├─ Calls: ReturnItemController.createReturnRequest()
    ├─ Calls: ValidationUtil.requireNotEmpty()
    ├─ Calls: LogService.catat()
    └─ Throws: ValidationException

DashboardService
    ├─ Calls: BarangController.getAllBarang()
    ├─ Calls: PeminjamanController.getPending()
    ├─ Calls: ReturnItemController.getPendingReturnRequests()
    ├─ Calls: UserController.getPendingUsers()
    └─ Calls: LogBarangController.getRecentLogs()
```

### View ↔ Service Pattern

```
ModernDashboardView
    ├─ Creates: DashboardService
    ├─ Calls: dashboardService.buildFullDashboard()
    ├─ Receives: DashboardDTO
    │   ├─ Accesses: dashboardData.getTotalBarang()
    │   ├─ Accesses: dashboardData.getAlerts()
    │   ├─ Accesses: dashboardData.getRecentActivities()
    │   └─ Accesses: dashboardData.getPeminjamanPerBulan()
    └─ Displays: Statistics, Alerts, Activities

ReturnItemApprovalView
    ├─ Creates: ReturnItemService
    ├─ Calls: returnItemService.getPendingReturnsWithDetails()
    ├─ Receives: List<ReturnItemDTO>
    ├─ User selects return & clicks "Setujui"
    ├─ Calls: returnItemService.approveReturn(id, notes)
    └─ Catches: ValidationException (display error)
```

---

## Data Transfer Objects (DTOs) Usage

### ReturnItemDTO

```java
// Example: Building a ReturnItemDTO
ReturnItemDTO dto = new ReturnItemDTO();
dto.setId(1);
dto.setPeminjamanId(5);
dto.setUsername("john_user");
dto.setKodeBarang("BRG001");
dto.setNamaBarang("Laptop");
dto.setJumlahPinjam(1);
dto.setJumlahDikembalikan(1);
// Auto-calculates: jumlahBelumDikembalikan = 0

// Usage in ReturnItemService
List<ReturnItemDTO> pending = returnItemService.getPendingReturnsWithDetails();
for (ReturnItemDTO item : pending) {
    if (item.isTerlambat()) {
        // Show alert for late returns
    }
}
```

### DashboardDTO with Inner Classes

```java
// Building DashboardDTO
DashboardDTO dashboard = new DashboardDTO();
dashboard.setTotalBarang(100);
dashboard.setBarangTersedia(85);
dashboard.setPeminjamanPending(3);

// Adding activities
ActivityDTO activity = new ActivityDTO(
    "john_user",
    ActivityDTO.Type.PEMINJAMAN,
    "Meminjam Laptop (1x)",
    LocalDate.now()
);
// Auto-generated icon: "📤" based on type
dashboard.getRecentActivities().add(activity);

// Adding alerts
AlertDTO alert = new AlertDTO(
    "Stok Menipis",
    "Monitor memiliki stok < 5 unit",
    AlertDTO.Severity.WARNING
);
// Auto-timestamp: LocalDate.now()
dashboard.getAlerts().add(alert);
```

---

## Validation Flow

```
User Input
    ↓
ValidationUtil.requireNotEmpty(value, fieldName)
    ├─ Check: value != null && !value.isBlank()
    ├─ If invalid:
    │   ├─ Create: "fieldName is required"
    │   └─ Throw: new ValidationException(message)
    └─ If valid: Continue
    ↓
ValidationUtil.requirePositive(value, fieldName)
    ├─ Check: value > 0
    ├─ If invalid:
    │   ├─ Create: "fieldName must be positive"
    │   └─ Throw: new ValidationException(message)
    └─ If valid: Continue
    ↓
Service Layer Business Logic
    ├─ Perform calculations
    ├─ Update database
    └─ Return success/error
    ↓
View Layer catches ValidationException
    ├─ NotificationUtil.showError(exception.getMessage())
    └─ Display error to user
```

---

## Notification System Flow

```
Notification Request
    ↓
NotificationUtil.showSuccess/Error/Warning/Info/Confirm/Input()
    ├─ Set color based on type
    ├─ Create JOptionPane with styled message
    ├─ Get parent JFrame reference
    └─ Display dialog
    ↓
User interacts (OK, Cancel, Input)
    ↓
Return result/value to caller
    ↓
Caller handles response
    ├─ If success: Update data/UI
    └─ If error: Retry or cancel
```

---

## Async Data Loading Pattern

```
ModernDashboardView.loadDashboardData()
    ↓
Create: SwingWorker<DashboardDTO, Void>
    ├─ doInBackground():
    │   ├─ On: EDT (Event Dispatch Thread) ✗
    │   ├─ On: Background thread ✓
    │   ├─ Calls: dashboardService.buildFullDashboard()
    │   └─ Returns: DashboardDTO
    │
    └─ done():
        ├─ get(): Retrieve result from doInBackground()
        ├─ On: EDT (Event Dispatch Thread) ✓
        ├─ Calls: refreshUI()
        └─ Handles: Exception if error
    ↓
UI updates only on EDT (thread-safe)
```

---

## Service Layer Hierarchy

```
BaseService (Abstract)
├─ logOperation(action, description)
├─ validateNotNull(value, fieldName)
├─ validateNotEmpty(value, fieldName)
├─ validatePositive(value, fieldName)
└─ validateNonNegative(value, fieldName)
    ↓
├─ ReturnItemService extends BaseService
│   ├─ Uses: All BaseService methods
│   ├─ Calls: ReturnItemController, BarangController, etc.
│   └─ Throws: ValidationException
│
└─ DashboardService extends BaseService
    ├─ Uses: All BaseService methods
    ├─ Calls: All controllers
    └─ Returns: DashboardDTO
```

---

## Error Handling Strategy

```
Three-Layer Error Handling:

1. Validation Layer (ValidationUtil)
   ├─ Catch: Invalid input
   ├─ Throw: ValidationException with clear message
   └─ Example: "Jumlah peminjaman harus positif"

2. Service Layer (ReturnItemService, DashboardService)
   ├─ Catch: ValidationException
   ├─ Propagate: to View
   └─ Log: via LogService

3. View Layer (ModernDashboardView, etc.)
   ├─ Catch: ValidationException, SQLException
   ├─ Display: via NotificationUtil.showError()
   └─ Retry: Allow user to correct input
```

---

## Performance Optimization Areas

### Current
- ✓ Async loading with SwingWorker
- ✓ DTOs minimize data transfer
- ✓ Service layer caching potential

### Future Improvements
- [ ] Database query optimization (indexes)
- [ ] Result set pagination
- [ ] In-memory caching with TTL
- [ ] Lazy loading for large lists
- [ ] Virtual scrolling in tables

---

## Security Architecture

```
Database Layer (Lowest Risk)
├─ Use: Prepared statements ✓
├─ Prevent: SQL injection ✓
└─ Issue: Password hashing (bcrypt needed)

Service Layer (Medium Risk)
├─ Use: ValidationUtil ✓
├─ Prevent: Invalid input ✓
└─ Issue: Business logic authorization

Presentation Layer (Highest Risk)
├─ Use: SessionManager ✓
├─ Prevent: Unauthorized access ✓
└─ Issue: CSRF protection (potential)
```

---

## Extension Points

### Adding New Service

```java
public class InventoryService extends BaseService {
    private BarangController barangCtrl;
    
    public InventoryService() {
        this.barangCtrl = new BarangController();
    }
    
    public void doSomething() throws SQLException {
        // Use BaseService methods
        validateNotEmpty(value, "fieldName");
        logOperation("ACTION", "description");
        
        // Use controller
        barangCtrl.getAllBarang();
        
        // Throw validation exception if needed
        throw new ValidationException("Error message");
    }
}
```

### Adding New Notification Type

```java
// In NotificationUtil.java
public static void showCustom(JFrame parent, String title, String message, Color color) {
    // Create dialog with custom color
    JOptionPane.showMessageDialog(parent, message, title, 
        JOptionPane.INFORMATION_MESSAGE);
    // Apply custom styling
}
```

---

## Testing Strategy

### Unit Tests (Recommended)
- ValidationUtil methods
- DTO builders & calculations
- Service business logic
- Exception handling

### Integration Tests (Recommended)
- End-to-end loan request flow
- Return approval with stock update
- Dashboard aggregation accuracy
- Database consistency

### UI Tests (Manual)
- ModernDashboardView rendering
- Async data loading
- Notification display
- User interactions

---

**Architecture Version**: 3.0 (Enterprise Layered)  
**Last Updated**: 2024  
**Status**: ✅ Production Ready
