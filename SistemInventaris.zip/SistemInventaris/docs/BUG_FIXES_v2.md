# Bug Fixes & Improvements — Sistem Inventaris v2

## Summary

Semua bug pada **dashboard** dan **password reset** telah diperbaiki. Kode yang tidak berguna telah dihapus.

---

## 🔴 Bug Dashboard (6 Bugs Fixed)

### 1. Dashboard Data — Barang Dipinjam Selalu 0
**File:** `DashboardService.java` → `populateBasicStats()`  
**Root Cause:** Menggunakan `getPending()` (hanya status "pending") lalu mencari "approved" → tidak ketemu  
**Fix:** Tambah `getDisetujui()` di `PeminjamanController` untuk hitung barang "disetujui"

### 2. Dashboard Alert — Peminjaman Terlambat Tidak Muncul
**File:** `DashboardService.java` → `populateAlerts()`  
**Root Cause:** Cari peminjaman "approved" di list "pending" → tidak ketemu  
**Fix:** Gunakan `getDisetujui()` untuk deteksi overdue

### 3. Dashboard Activity — Recent Activity Hanya Pending
**File:** `DashboardService.java` → `populateRecentActivities()`  
**Root Cause:** Pakai `getPending()` → activity "disetujui/ditolak" tidak tampil  
**Fix:** Gunakan `getAllPeminjaman()` untuk semua aktivitas terbaru

### 4. Dashboard Chart — Data Bulan Salah
**File:** `DashboardService.java` → `populateCharts()`  
**Root Cause:** Pakai `getPending()` → chart hanya show pending  
**Fix:** Gunakan `getAllPeminjaman()`

### 5. Dashboard UI — 2 Kartu Statistik Hilang
**File:** `ModernDashboardView.java` → `buatStatsRow()`  
**Root Cause:** Grid 2×2 (4 kartu), missing "Peminjaman Pending" & "Pengembalian Pending"  
**Fix:** Ubah ke 2×3 (6 kartu), tambah 2 kartu baru

### 6. Dashboard Cards — Nilai Tidak Pernah Update
**File:** `BarangView.java` → `buatStatsRow()` & `muatDataTabel()`  
**Root Cause:** Update dummy `JLabel` yang tidak terhubung ke `StatisticCard` → kartu selalu "0"  
**Fix:** 
- Tambah `setValue()` method ke `StatisticCard`
- Simpan referensi kartu di `BarangView` 
- Update via `setValue()` saat data dimuat

**Bonus Fix:** Tambah click handler untuk Dashboard nav item → buka `ModernDashboardView` di jendela baru

---

## 🔴 Bug Password Reset (3 Bugs Fixed)

### 1. Password Reset — Username Tidak Divalidasi
**File:** `PasswordResetController.java` → `requestPasswordReset()`  
**Root Cause:** Insert ke DB tanpa cek username ada atau tidak  
**Fix:** Tambah method `userExists()` untuk validasi username ada di tabel `users`

### 2. Password Reset — Email Tidak Diverifikasi
**File:** `PasswordResetController.java` → `requestPasswordReset()`  
**Root Cause:** Tidak cek apakah email cocok dengan username  
**Fix:** Tambah method `emailMatchesUsername()` untuk validasi email sesuai username

### 3. Password Reset — Error Message Tidak Jelas
**File:** `ForgotPasswordDialog.java` → `submitRequest()`  
**Root Cause:** Generic error message "Username mungkin tidak terdaftar"  
**Fix:** Pesan lebih spesifik: "Username atau email tidak terdaftar / tidak cocok!" + lock form setelah sukses

---

## 🗑️ Removed Unused Classes

6 class yang tidak digunakan telah dihapus untuk mengurangi bloat:

1. **`BackgroundPanel.java`** — 0 usage, hanya template UI
2. **`ModernGradientPanel.java`** — 0 usage, redundan dengan `GradientPanel`
3. **`ModernDivider.java`** — 0 usage, tidak dipakai di UI apapun
4. **`PremiumHeader.java`** — 0 usage, tidak diintegrasikan
5. **`ModernTableStyle.java`** — 0 usage, styling dilakukan inline
6. **`ExportUtil.java`** — 0 usage, fitur export belum diimplementasikan

---

## ✅ Improvements Made

### PeminjamanController
**Added Methods:**
```java
// Dapatkan semua peminjaman (untuk chart & statistik)
public List<Peminjaman> getAllPeminjaman() throws SQLException

// Dapatkan hanya peminjaman yang disetujui (untuk hitung barang dipinjam)
public List<Peminjaman> getDisetujui() throws SQLException
```

### StatisticCard
**Added Methods:**
```java
// Update nilai kartu setelah konstruksi
public void setValue(String newValue)
public void setSubtitle(String newSubtitle)
```

### PasswordResetController
**Added Methods:**
```java
// Private validators
private boolean userExists(String username)
private boolean emailMatchesUsername(String username, String email)
```

---

## 📊 Testing Checklist

- [x] Dashboard menampilkan 6 kartu statistik (bukan 4)
- [x] "Barang Dipinjam" dan "Req. Peminjaman" menampilkan nilai benar
- [x] Recent Activity menampilkan semua status (bukan hanya pending)
- [x] Alerts "Peminjaman Terlambat" muncul dengan benar
- [x] Chart peminjaman per bulan akurat
- [x] Dashboard nav item bisa diklik → buka view baru
- [x] Password reset validasi username & email
- [x] Error message jelas saat username/email salah
- [x] Stat cards di BarangView update saat data dimuat
- [x] Form password reset lock setelah submit sukses

---

## 🔧 How to Compile & Run

```bash
# Windows (PowerShell)
cd "C:\path\to\SistemInventaris"
javac --release 14 -cp "lib/*" -d "out" $(Get-ChildItem -Recurse "src" -Filter *.java | % FullName)
java -cp "out;lib/*" Main

# Linux/Mac
cd /path/to/SistemInventaris
javac --release 14 -cp "lib/*" -d out $(find src -name "*.java")
java -cp "out:lib/*" Main
```

---

## 📝 Notes

- Semua bug dashboard berkaitan dengan penggunaan `getPending()` di tempat yang seharusnya gunakan `getAllPeminjaman()` atau `getDisetujui()`
- Password reset sekarang fully validated — username, email harus terdaftar dan cocok
- UI component yang unused dihapus untuk menjaga project tetap clean & maintainable
- Database schema tetap sama — tidak perlu migrasi

---

**Generated:** 2026-05-03  
**Version:** v2.0 (Bug Fixes)  
**Status:** ✅ All Issues Resolved
