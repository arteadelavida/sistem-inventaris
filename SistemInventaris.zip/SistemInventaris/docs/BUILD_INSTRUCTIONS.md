# 🔨 Build Instructions - Sistem Inventaris

## Prerequisites

- **Java**: JDK 14 or higher (JDK 25 recommended)
  - Available at: `C:\Program Files\Java\jdk-25\bin\java.exe`
- **Database**: MySQL 5.7+ or MariaDB 10.3+
- **JDBC Driver**: `mysql-connector-j-*.jar` (place in `lib/` folder)

## Quick Start

### 1. Compile Project

**Windows (PowerShell):**
```powershell
cd "C:\Users\Farras\Documents\TI SEM 2\SistemInventaris"
javac --release 14 -cp "lib/*" -d "out" $(Get-ChildItem -Recurse "src" -Filter *.java | % FullName)
```

**Linux/Mac:**
```bash
cd "SistemInventaris"
javac --release 14 -cp "lib/*" -d "out" $(find src -name "*.java")
```

### 2. Run Project

**Using Java 25:**
```cmd
java -cp "out;lib/*" Main
```

### 3. Database Setup

Run `SETUP_DATABASE.sql` in MySQL:
```sql
mysql -u root -p < SETUP_DATABASE.sql
```

Or manually:
1. Create databases: `login` and `sisteminventaris`
2. Import the SQL schema from `SETUP_DATABASE.sql`
3. Ensure user `root` with password `` (empty) can connect

## Important Notes

- **Java Version**: The code uses Java 14+ features (switch expressions), so JDK 14+ is required
- **Database Passwords**: Edit `DatabaseUtil.java` if your MySQL has a password
- **Timezone**: Database is configured for `Asia/Jakarta` timezone

## Troubleshooting

| Issue | Solution |
|-------|----------|
| `UnsupportedClassVersionError` | Use Java 14+, not Java 8 |
| `ClassNotFoundException: com.mysql.cj.jdbc.Driver` | Add `mysql-connector-j-*.jar` to `lib/` |
| `SQLException: Access denied` | Check MySQL credentials in `DatabaseUtil.java` |
| `ClassNotFoundException` after compile | Ensure all `.class` files are in `out/` folder |

## Project Structure

```
SistemInventaris/
├── src/
│   ├── Main.java                    # Entry point
│   ├── view/                        # UI components (LoginView, BarangView, etc.)
│   ├── controller/                  # Business logic (AuthController, BarangController, etc.)
│   ├── model/                       # Data models (User, Barang, Peminjaman, etc.)
│   ├── component/                   # Reusable UI components (RoundedButton, ModernCard, etc.)
│   └── util/                        # Utilities (DatabaseUtil, SessionManager, LogService)
├── lib/                             # External libraries (MySQL JDBC driver)
├── out/                             # Compiled Java classes
├── SETUP_DATABASE.sql               # Database schema
└── BUILD_INSTRUCTIONS.md            # This file
```

## Features

✅ User Authentication (Login/Register)
✅ Password Reset with Admin Approval
✅ Inventory Management (CRUD Operations)
✅ Loan Management (Peminjaman)
✅ Return Item Management
✅ Admin Dashboard
✅ Audit Logs
✅ Modern Enterprise UI

## Default Credentials

- **Username**: `admin`
- **Password**: `admin123`
- **Role**: Administrator

