-- ================================================================
-- SETUP DATABASE SISTEM INVENTARIS
-- Jalankan file ini di MySQL Workbench / phpMyAdmin / terminal MySQL
-- ================================================================

-- 1. Pastikan database sudah ada (sesuaikan nama jika beda)
CREATE DATABASE IF NOT EXISTS sisteminventaris CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE DATABASE IF NOT EXISTS login             CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- ================================================================
-- DATABASE: login  (autentikasi user)
-- ================================================================
USE login;

CREATE TABLE IF NOT EXISTS users (
    id       INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role     VARCHAR(20)  NOT NULL DEFAULT 'user',
    status   VARCHAR(20)  NOT NULL DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Akun admin default (password: admin123)
INSERT IGNORE INTO users (username, password, role, status)
VALUES ('admin', 'admin123', 'admin', 'active');

-- Tabel untuk password reset requests (FITUR BARU)
CREATE TABLE IF NOT EXISTS password_reset_requests (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    username        VARCHAR(100) NOT NULL,
    email           VARCHAR(100),
    token           VARCHAR(255) UNIQUE NOT NULL,
    reason          TEXT,
    status          VARCHAR(20)  DEFAULT 'pending',
    approved_by     VARCHAR(100),
    approved_at     DATETIME,
    rejected_at     DATETIME,
    created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (username) REFERENCES users(username) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ================================================================
-- DATABASE: sisteminventaris  (data barang & peminjaman)
-- ================================================================
USE sisteminventaris;

CREATE TABLE IF NOT EXISTS barang (
    kode_barang VARCHAR(50)  NOT NULL PRIMARY KEY,
    nama_barang VARCHAR(150) NOT NULL,
    harga       INT          NOT NULL DEFAULT 0,
    stok        INT          NOT NULL DEFAULT 0,
    keterangan  TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabel peminjaman (jika sudah ada struktur lama, drop dulu)
DROP TABLE IF EXISTS peminjaman;

CREATE TABLE peminjaman (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    username        VARCHAR(100) NOT NULL,
    kode_barang     VARCHAR(50)  NOT NULL,
    nama_barang     VARCHAR(150),
    jumlah          INT          NOT NULL DEFAULT 1,
    tanggal_pinjam  DATE         NOT NULL,
    tanggal_kembali DATE         NOT NULL,
    status          VARCHAR(20)  NOT NULL DEFAULT 'pending',
    status_return   VARCHAR(20)  DEFAULT 'belum_dikembalikan',
    tanggal_kembali_aktual DATE,
    keterangan_admin VARCHAR(255),
    diterima_oleh   VARCHAR(100),
    tanggal_diterima DATETIME
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabel return items (FITUR BARU) - untuk tracking pengembalian barang
DROP TABLE IF EXISTS return_items;

CREATE TABLE return_items (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    peminjaman_id   INT          NOT NULL,
    username        VARCHAR(100) NOT NULL,
    kode_barang     VARCHAR(50)  NOT NULL,
    nama_barang     VARCHAR(150),
    jumlah_dikembalikan INT       NOT NULL,
    tanggal_return  DATE         NOT NULL,
    kondisi_barang  VARCHAR(50)  DEFAULT 'baik',
    keterangan      TEXT,
    status          VARCHAR(20)  DEFAULT 'pending',
    disetujui_oleh  VARCHAR(100),
    tanggal_disetujui DATETIME,
    created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (peminjaman_id) REFERENCES peminjaman(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabel log aktivitas
CREATE TABLE IF NOT EXISTS log_aktivitas (
    id        INT AUTO_INCREMENT PRIMARY KEY,
    username  VARCHAR(100) NOT NULL,
    role      VARCHAR(20)  NOT NULL,
    aktivitas TEXT,
    tanggal   DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ================================================================
-- SELESAI
-- ================================================================
SELECT 'Setup database berhasil!' AS Info;
