# 📚 Panduan Lengkap Java OOP (Object-Oriented Programming)

## Daftar Isi
1. [Inheritance (Pewarisan)](#1-inheritance-pewarisan)
2. [Encapsulation (Enkapsulasi)](#2-encapsulation-enkapsulasi)
3. [Abstraction (Abstraksi)](#3-abstraction-abstraksi)
4. [Polymorphism (Polimorfisme)](#4-polymorphism-polimorfisme)
5. [Konsep Penting Lainnya](#5-konsep-penting-lainnya)
6. [Ringkasan 4 Pilar OOP](#ringkasan-4-pilar-oop)

---

## 1. Inheritance (Pewarisan)

Memungkinkan class mewarisi properties dan methods dari class lain.

### Konsep Dasar
- **Parent class (Superclass)**: Class yang diwariskan
- **Child class (Subclass)**: Class yang mewarisi

### Contoh Implementasi

```java
// Parent class (Superclass)
public class Kendaraan {
    protected String merek;
    protected String warna;
    
    public Kendaraan(String merek, String warna) {
        this.merek = merek;
        this.warna = warna;
    }
    
    public void info() {
        System.out.println("Merek: " + merek + ", Warna: " + warna);
    }
}

// Child class (Subclass)
public class Mobil extends Kendaraan {
    private int jumlahPintu;
    
    public Mobil(String merek, String warna, int jumlahPintu) {
        super(merek, warna);  // Panggil constructor parent
        this.jumlahPintu = jumlahPintu;
    }
    
    public void info() {
        super.info();  // Panggil method parent
        System.out.println("Jumlah Pintu: " + jumlahPintu);
    }
}

// Penggunaan
Mobil mobil = new Mobil("Toyota", "Merah", 4);
mobil.info();
```

### Keuntungan Inheritance
- ✅ **Reusability code** - Tidak perlu menulis ulang kode yang sama
- ✅ **Relationships & hierarchy** - Menunjukkan hubungan antar class
- ✅ **Mengurangi duplikasi** - DRY principle (Don't Repeat Yourself)
- ✅ **Maintenance lebih mudah** - Perubahan di parent otomatis terpengaruh child

---

## 2. Encapsulation (Enkapsulasi)

Menyembunyikan detail internal & mengontrol akses via public methods (getter/setter).

### Konsep Dasar
Encapsulation melindungi data dengan membatasi akses langsung dan menyediakan cara tertentu untuk mengakses/mengubah data.

### Contoh Implementasi

```java
public class Akun {
    // Private - hanya bisa diakses dalam class ini
    private String nomorAkun;
    private double saldo;
    
    // Constructor
    public Akun(String nomorAkun, double saldoAwal) {
        this.nomorAkun = nomorAkun;
        this.saldo = saldoAwal;
    }
    
    // Getter
    public double getSaldo() {
        return saldo;
    }
    
    // Setter dengan validasi
    public void setSaldo(double jumlah) {
        if (jumlah >= 0) {
            this.saldo = jumlah;
        } else {
            System.out.println("Saldo tidak boleh negatif!");
        }
    }
    
    // Method untuk transaksi
    public void setor(double jumlah) {
        if (jumlah > 0) {
            saldo += jumlah;
            System.out.println("Setor: Rp" + jumlah);
        }
    }
    
    public void tarik(double jumlah) {
        if (jumlah > 0 && jumlah <= saldo) {
            saldo -= jumlah;
            System.out.println("Tarik: Rp" + jumlah);
        }
    }
}

// Penggunaan
Akun akun = new Akun("123456", 1000000);
akun.setor(500000);    // Output: Setor: Rp500000.0
akun.tarik(200000);    // Output: Tarik: Rp200000.0
System.out.println("Saldo: " + akun.getSaldo());  // Output: Saldo: 1300000.0
```

### Access Modifiers

| Modifier | Class | Package | Subclass | World |
|----------|-------|---------|----------|-------|
| `private` | ✅ | ❌ | ❌ | ❌ |
| default (package-private) | ✅ | ✅ | ❌ | ❌ |
| `protected` | ✅ | ✅ | ✅ | ❌ |
| `public` | ✅ | ✅ | ✅ | ✅ |

### Keuntungan Encapsulation
- ✅ **Data Protection** - Data tidak bisa dimodifikasi sembarangan
- ✅ **Validation** - Bisa menambahkan validasi di setter
- ✅ **Flexibility** - Bisa mengubah internal logic tanpa mengubah interface
- ✅ **Maintainability** - Lebih mudah track perubahan data

---

## 3. Abstraction (Abstraksi)

Menyembunyikan kompleksitas & menampilkan hanya fitur penting. Menggunakan **abstract class** atau **interface**.

### A. Menggunakan Abstract Class

```java
public abstract class Hewan {
    private String nama;
    
    public Hewan(String nama) {
        this.nama = nama;
    }
    
    // Method abstrak - WAJIB diimplementasi subclass
    public abstract void bersuara();
    
    public abstract void bergerak();
    
    // Method konkret (OPSIONAL dioverride)
    public void tidur() {
        System.out.println(nama + " sedang tidur...");
    }
    
    public String getNama() {
        return nama;
    }
}

public class Anjing extends Hewan {
    public Anjing(String nama) {
        super(nama);
    }
    
    @Override
    public void bersuara() {
        System.out.println("Guk guk!");
    }
    
    @Override
    public void bergerak() {
        System.out.println("Berlari dengan 4 kaki");
    }
}

public class Burung extends Hewan {
    @Override
    public void bersuara() {
        System.out.println("Kicau kicau!");
    }
    
    @Override
    public void bergerak() {
        System.out.println("Terbang dengan sayap");
    }
}

// Penggunaan
Hewan anjing = new Anjing("Rex");
anjing.bersuara();  // Output: Guk guk!
anjing.bergerak();  // Output: Berlari dengan 4 kaki
anjing.tidur();     // Output: Rex sedang tidur...

Hewan burung = new Burung("Kiki");
burung.bersuara();  // Output: Kicau kicau!
burung.bergerak();  // Output: Terbang dengan sayap
```

### B. Menggunakan Interface

```java
public interface Transportasi {
    void mulai();
    void berhenti();
    void mempercepat(int kecepatan);
}

public class Motor implements Transportasi {
    private String merek;
    private int kecepatanAktual;
    
    public Motor(String merek) {
        this.merek = merek;
        this.kecepatanAktual = 0;
    }
    
    @Override
    public void mulai() {
        System.out.println(merek + " dinyalakan");
    }
    
    @Override
    public void berhenti() {
        System.out.println(merek + " berhenti");
        this.kecepatanAktual = 0;
    }
    
    @Override
    public void mempercepat(int kecepatan) {
        this.kecepatanAktual = kecepatan;
        System.out.println(merek + " melaju " + kecepatan + " km/h");
    }
}

public class Mobil implements Transportasi {
    private String merek;
    private int kecepatanAktual;
    
    public Mobil(String merek) {
        this.merek = merek;
        this.kecepatanAktual = 0;
    }
    
    @Override
    public void mulai() {
        System.out.println(merek + " mesin dinyalakan");
    }
    
    @Override
    public void berhenti() {
        System.out.println(merek + " rem ditarik");
        this.kecepatanAktual = 0;
    }
    
    @Override
    public void mempercepat(int kecepatan) {
        this.kecepatanAktual = kecepatan;
        System.out.println(merek + " melaju " + kecepatan + " km/h");
    }
}

// Penggunaan
Transportasi motor = new Motor("Honda");
motor.mulai();           // Output: Honda dinyalakan
motor.mempercepat(60);   // Output: Honda melaju 60 km/h
motor.berhenti();        // Output: Honda berhenti

Transportasi mobil = new Mobil("Toyota");
mobil.mulai();           // Output: Toyota mesin dinyalakan
mobil.mempercepat(80);   // Output: Toyota melaju 80 km/h
mobil.berhenti();        // Output: Toyota rem ditarik
```

### Abstract Class vs Interface

| Aspek | Abstract Class | Interface |
|-------|---|---|
| **Inheritance** | Hanya 1 parent | Multiple parents |
| **Access Modifier** | Bisa private, protected, public | Semua public |
| **Constructor** | Boleh punya constructor | Tidak boleh |
| **Variables** | Bisa non-final | Semua final & static |
| **Methods** | Bisa concrete & abstract | Hanya abstract (Java 8+: default methods) |

### Keuntungan Abstraction
- ✅ **Hide Complexity** - User hanya perlu tahu interface
- ✅ **Flexibility** - Bisa ganti implementasi tanpa mengubah code lain
- ✅ **Contract** - Interface memberikan kontrak yang harus diimplementasi
- ✅ **Code Clarity** - Lebih mudah dipahami

---

## 4. Polymorphism (Polimorfisme)

Satu interface, banyak implementasi. Memungkinkan object bertindak dalam berbagai cara.

### A. Method Overriding (Runtime Polymorphism)

Subclass mengoverride method dari parent class.

```java
public class Pegawai {
    protected String nama;
    
    public Pegawai(String nama) {
        this.nama = nama;
    }
    
    public void bekerja() {
        System.out.println("Pegawai " + nama + " bekerja");
    }
    
    public double hitungGaji() {
        return 5000000;  // Gaji default
    }
}

public class Developer extends Pegawai {
    public Developer(String nama) {
        super(nama);
    }
    
    @Override
    public void bekerja() {
        System.out.println("Developer " + nama + " sedang coding");
    }
    
    @Override
    public double hitungGaji() {
        return 8000000;  // Gaji developer
    }
}

public class Manager extends Pegawai {
    public Manager(String nama) {
        super(nama);
    }
    
    @Override
    public void bekerja() {
        System.out.println("Manager " + nama + " mengadakan meeting");
    }
    
    @Override
    public double hitungGaji() {
        return 12000000;  // Gaji manager
    }
}

// Penggunaan - Polymorphism in action!
public static void main(String[] args) {
    Pegawai p1 = new Developer("Budi");
    Pegawai p2 = new Manager("Siti");
    Pegawai p3 = new Pegawai("Ahmad");
    
    // Sama-sama tipe Pegawai, tapi bersikap berbeda
    p1.bekerja();  // Output: Developer Budi sedang coding
    p2.bekerja();  // Output: Manager Siti mengadakan meeting
    p3.bekerja();  // Output: Pegawai Ahmad bekerja
    
    System.out.println("Gaji p1: " + p1.hitungGaji());  // 8000000
    System.out.println("Gaji p2: " + p2.hitungGaji());  // 12000000
    System.out.println("Gaji p3: " + p3.hitungGaji());  // 5000000
}
```

### B. Method Overloading (Compile-time Polymorphism)

Satu method name, berbeda parameter.

```java
public class Kalkulator {
    // Overload dengan tipe parameter berbeda
    public int tambah(int a, int b) {
        return a + b;
    }
    
    public double tambah(double a, double b) {
        return a + b;
    }
    
    public String tambah(String a, String b) {
        return a + b;
    }
    
    // Overload dengan jumlah parameter berbeda
    public int tambah(int a, int b, int c) {
        return a + b + c;
    }
    
    // Overload dengan urutan parameter berbeda
    public void display(int a, String b) {
        System.out.println("int: " + a + ", String: " + b);
    }
    
    public void display(String a, int b) {
        System.out.println("String: " + a + ", int: " + b);
    }
}

// Penggunaan
Kalkulator calc = new Kalkulator();
System.out.println(calc.tambah(5, 10));              // Output: 15
System.out.println(calc.tambah(5.5, 10.5));         // Output: 16.0
System.out.println(calc.tambah("Hello", " World")); // Output: Hello World
System.out.println(calc.tambah(5, 10, 15));         // Output: 30

calc.display(5, "test");      // Output: int: 5, String: test
calc.display("test", 5);      // Output: String: test, int: 5
```

### Key Points Polymorphism
- ✅ **Runtime Polymorphism** - Method mana yang dipanggil ditentukan saat runtime
- ✅ **Compile-time Polymorphism** - Method mana yang dipanggil ditentukan saat compile
- ✅ **Flexibility** - Code menjadi lebih flexible dan reusable
- ✅ **Maintainability** - Mudah menambah behavior baru tanpa mengubah existing code

---

## 5. Konsep Penting Lainnya

### A. Association (Asosiasi)

Hubungan antara dua class yang saling independent.

```java
public class Siswa {
    private String nama;
    private String nimSiswa;
    private Sekolah sekolah;  // Siswa "associated with" Sekolah
    
    public Siswa(String nama, String nimSiswa, Sekolah sekolah) {
        this.nama = nama;
        this.nimSiswa = nimSiswa;
        this.sekolah = sekolah;
    }
    
    public void sekolah() {
        System.out.println(nama + " bersekolah di " + sekolah.getNama());
    }
}

public class Sekolah {
    private String nama;
    private String alamat;
    
    public Sekolah(String nama, String alamat) {
        this.nama = nama;
        this.alamat = alamat;
    }
    
    public String getNama() {
        return nama;
    }
}

// Penggunaan
Sekolah sma = new Sekolah("SMA Negeri 1", "Jakarta");
Siswa siswa = new Siswa("Rudi", "001", sma);
siswa.sekolah();  // Output: Rudi bersekolah di SMA Negeri 1
```

### B. Composition (Komposisi)

"Has-a" relationship - Part tidak bisa exist tanpa Whole.

```java
public class Mesin {
    private String tipe;
    private int daya;
    
    public Mesin(String tipe, int daya) {
        this.tipe = tipe;
        this.daya = daya;
    }
    
    public void nyalakan() {
        System.out.println("Mesin " + tipe + " dinyalakan");
    }
}

public class Mobil {
    private String merek;
    private Mesin mesin;  // Mobil "has-a" Mesin
    
    public Mobil(String merek, String tipeMenun, int dayaMesin) {
        this.merek = merek;
        this.mesin = new Mesin(tipeMenun, dayaMesin);  // Dibuat bersamaan
    }
    
    public void mulai() {
        System.out.println("Mobil " + merek + " mulai...");
        mesin.nyalakan();
    }
}

// Penggunaan
Mobil mobil = new Mobil("Honda", "Bensin", 1500);
mobil.mulai();  // Output: Mobil Honda mulai...
                // Output: Mesin Bensin dinyalakan
```

### C. Aggregation

"Part-of" relationship - Part bisa exist tanpa Whole.

```java
public class Pegawai {
    private String nama;
    private String jabatan;
    
    public Pegawai(String nama, String jabatan) {
        this.nama = nama;
        this.jabatan = jabatan;
    }
    
    public String getInfo() {
        return nama + " (" + jabatan + ")";
    }
}

public class Perusahaan {
    private String nama;
    private List<Pegawai> pegawaiList;  // Pegawai bisa exist tanpa Perusahaan
    
    public Perusahaan(String nama) {
        this.nama = nama;
        this.pegawaiList = new ArrayList<>();
    }
    
    public void tambahPegawai(Pegawai pegawai) {
        pegawaiList.add(pegawai);
    }
    
    public void tampilkanPegawai() {
        System.out.println("Pegawai " + nama + ":");
        for (Pegawai p : pegawaiList) {
            System.out.println("  - " + p.getInfo());
        }
    }
}

// Penggunaan
Pegawai p1 = new Pegawai("Andi", "Developer");
Pegawai p2 = new Pegawai("Budi", "Manager");

Perusahaan pt = new Perusahaan("PT Maju Jaya");
pt.tambahPegawai(p1);
pt.tambahPegawai(p2);
pt.tampilkanPegawai();
// Output: Pegawai PT Maju Jaya:
//           - Andi (Developer)
//           - Budi (Manager)
```

---

## Ringkasan 4 Pilar OOP

| Konsep | Tujuan | Implementasi | Contoh |
|--------|--------|--------------|---------|
| **Inheritance** | Reusability, hierarchy | `extends` class | Mobil extends Kendaraan |
| **Encapsulation** | Data security, control | `private`, getter/setter | Akun dengan saldo private |
| **Abstraction** | Hide complexity | `abstract` class, `interface` | Hewan abstract, bersuara() |
| **Polymorphism** | Flexibility, override | Method overriding/overloading | Dev & Manager override bekerja() |

---

## Tips Implementasi OOP

### ✅ DO
- ✅ Gunakan inheritance untuk merepresentasikan "is-a" relationship
- ✅ Gunakan composition untuk merepresentasikan "has-a" relationship
- ✅ Buatkan interface untuk kontrak behavior
- ✅ Gunakan abstract class untuk code reusability dengan state
- ✅ Hide implementation detail dengan encapsulation
- ✅ Gunakan meaningful names untuk class, method, dan variable

### ❌ DON'T
- ❌ Jangan buat deep inheritance hierarchy (lebih dari 3-4 level)
- ❌ Jangan expose internal state secara langsung
- ❌ Jangan mix responsibility dalam satu class (Single Responsibility Principle)
- ❌ Jangan gunakan inheritance hanya untuk code reuse
- ❌ Jangan buat abstract class dengan hanya method abstract

---

## Referensi SOLID Principles

OOP yang baik mengikuti SOLID:
- **S**ingle Responsibility Principle - Satu class satu tanggung jawab
- **O**pen/Closed Principle - Open for extension, closed for modification
- **L**iskov Substitution Principle - Subclass bisa menggantikan parent class
- **I**nterface Segregation Principle - Interface spesifik lebih baik dari general
- **D**ependency Inversion Principle - Depend on abstraction, not concrete

---

**Dokumen ini dibuat sebagai panduan pembelajaran Java OOP. Untuk pertanyaan lebih lanjut, silakan referensi ke resource Java official documentation.**
